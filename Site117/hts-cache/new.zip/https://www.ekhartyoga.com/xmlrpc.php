<!doctype html>
<html data-n-head-ssr lang="en" data-n-head="%7B%22lang%22:%7B%22ssr%22:%22en%22%7D%7D">
<head>
<title>404 Page not found | Ekhart Yoga</title><meta data-n-head="ssr" data-hid="charset" charset="utf-8"><meta data-n-head="ssr" data-hid="viewport" name="viewport" content="width=device-width, initial-scale=1"><meta data-n-head="ssr" data-hid="mobile-web-app-capable" name="mobile-web-app-capable" content="yes"><meta data-n-head="ssr" data-hid="apple-mobile-web-app-title" name="apple-mobile-web-app-title" content="ekhartyoga-nuxt-web"><meta data-n-head="ssr" data-hid="author" name="author" content="EkhartYoga"><meta data-n-head="ssr" data-hid="og:site_name" name="og:site_name" property="og:site_name" content="ekhartyoga-nuxt-web"><meta data-n-head="ssr" charset="utf-8"><meta data-n-head="ssr" name="viewport" content="width=device-width, initial-scale=1"><meta data-n-head="ssr" data-hid="description" name="description" content="Browse through all our yoga and meditation classes, select your favourite styles and teachers."><meta data-n-head="ssr" name="fb:app_id" content="231475686922508"><meta data-n-head="ssr" data-hid="og:title" property="og:title" content="Online yoga classes, meditation and talks | Ekhart Yoga"><meta data-n-head="ssr" data-hid="og:description" property="og:description" content="Browse through all our yoga and meditation classes, select your favourite styles and teachers."><meta data-n-head="ssr" data-hid="og:url" property="og:url" content="https://blobs.ekhartyoga.com"><meta data-n-head="ssr" data-hid="og:image" property="og:image" content="https://www.ekhartyoga.com/img/default_share.jpg"><meta data-n-head="ssr" data-hid="og:image:width" property="og:image:width" content="1280"><meta data-n-head="ssr" data-hid="og:image:height" property="og:image:height" content="854"><meta data-n-head="ssr" data-hid="og:type" property="og:type" content="article"><meta data-n-head="ssr" name="google-site-verification" content="CJkG6lisAUZ09Z7K6mlSUkDAgB1Olfaupp4Lf-Cuj1I"><meta data-n-head="ssr" name="msapplication-TileColor" content="#da532c"><meta data-n-head="ssr" name="msapplication-config" content="https://blobs.ekhartyoga.com/img/favicon/browserconfig.xml"><link data-n-head="ssr" rel="manifest" href="/_nuxt/manifest.e0111a95.json" data-hid="manifest"><link data-n-head="ssr" rel="icon" type="image/x-icon" href="https://blobs.ekhartyoga.com/web-static/img/favicon.ico"><link data-n-head="ssr" rel="apple-touch-icon" sizes="180x180" href="https://blobs.ekhartyoga.com/web-static/img/apple-touch-icon.png"><link data-n-head="ssr" data-hid="icon-1" rel="icon" sizes="32x32" href="https://blobs.ekhartyoga.com/web-static/img/favicon-32x32.png"><link data-n-head="ssr" data-hid="icon-2" rel="icon" sizes="16x16" href="https://blobs.ekhartyoga.com/web-static/img/favicon-16x16.png"><link data-n-head="ssr" rel="manifest" href="https://blobs.ekhartyoga.com/web-static/img/site.webmanifest" crossorigin="use-credentials"><link data-n-head="ssr" rel="mask-icon" href="https://blobs.ekhartyoga.com/web-static/img/safari-pinned-tab.svg"><link data-n-head="ssr" rel="shortcut icon" href="https://blobs.ekhartyoga.com/web-static/img/favicon.ico"><script data-n-head="ssr" data-hid="gtm-script">if(!window._gtm_init){window._gtm_init=1;(function(w,n,d,m,e,p){w[d]=(w[d]==1||n[d]=='yes'||n[d]==1||n[m]==1||(w[e]&&w[e][p]&&w[e][p]()))?1:0})(window,navigator,'doNotTrack','msDoNotTrack','external','msTrackingProtectionEnabled');(function(w,d,s,l,x,y){w[x]={};w._gtm_inject=function(i){if(w.doNotTrack||w[x][i])return;w[x][i]=1;w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s);j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i;f.parentNode.insertBefore(j,f);};w[y]('GTM-T9S2ST')})(window,document,'script','dataLayer','_gtm_ids','_gtm_inject')}</script><script data-n-head="ssr" src="https://277d3551b526436ab511a6b897615f2a.js.ubembed.com" async></script><script data-n-head="ssr" data-hid="gtm" type="text/javascript">window.dataLayer = window.dataLayer || [];</script><style data-vue-ssr-id="d706d280:0 2ec07acc:0 2ec07acc:1 39a09554:0 e9bc2ade:0 12a40c0e:0 2d0b9eb8:0 361c0aae:0 71b13260:0 6da5b4ba:0 1def628f:0">/*! tailwindcss v2.2.19 | MIT License | https://tailwindcss.com*/

/*! modern-normalize v1.1.0 | MIT License | https://github.com/sindresorhus/modern-normalize */

/*
Document
========
*/

/**
Use a better box model (opinionated).
*/

*,
::before,
::after {
  box-sizing: border-box;
}

/**
Use a more readable tab size (opinionated).
*/

html {
  -moz-tab-size: 4;
  -o-tab-size: 4;
     tab-size: 4;
}

/**
1. Correct the line height in all browsers.
2. Prevent adjustments of font size after orientation changes in iOS.
*/

html {
  line-height: 1.15; /* 1 */
  -webkit-text-size-adjust: 100%; /* 2 */
}

/*
Sections
========
*/

/**
Remove the margin in all browsers.
*/

body {
  margin: 0;
}

/**
Improve consistency of default fonts in all browsers. (https://github.com/sindresorhus/modern-normalize/issues/3)
*/

body {
  font-family:
		system-ui,
		-apple-system, /* Firefox supports this but not yet `system-ui` */
		'Segoe UI',
		Roboto,
		Helvetica,
		Arial,
		sans-serif,
		'Apple Color Emoji',
		'Segoe UI Emoji';
}

/*
Grouping content
================
*/

/**
1. Add the correct height in Firefox.
2. Correct the inheritance of border color in Firefox. (https://bugzilla.mozilla.org/show_bug.cgi?id=190655)
*/

hr {
  height: 0; /* 1 */
  color: inherit; /* 2 */
}

/*
Text-level semantics
====================
*/

/**
Add the correct text decoration in Chrome, Edge, and Safari.
*/

abbr[title] {
  -webkit-text-decoration: underline dotted;
          text-decoration: underline dotted;
}

/**
Add the correct font weight in Edge and Safari.
*/

b,
strong {
  font-weight: bolder;
}

/**
1. Improve consistency of default fonts in all browsers. (https://github.com/sindresorhus/modern-normalize/issues/3)
2. Correct the odd 'em' font sizing in all browsers.
*/

code,
kbd,
samp,
pre {
  font-family:
		ui-monospace,
		SFMono-Regular,
		Consolas,
		'Liberation Mono',
		Menlo,
		monospace; /* 1 */
  font-size: 1em; /* 2 */
}

/**
Add the correct font size in all browsers.
*/

small {
  font-size: 80%;
}

/**
Prevent 'sub' and 'sup' elements from affecting the line height in all browsers.
*/

sub,
sup {
  font-size: 75%;
  line-height: 0;
  position: relative;
  vertical-align: baseline;
}

sub {
  bottom: -0.25em;
}

sup {
  top: -0.5em;
}

/*
Tabular data
============
*/

/**
1. Remove text indentation from table contents in Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=999088, https://bugs.webkit.org/show_bug.cgi?id=201297)
2. Correct table border color inheritance in all Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=935729, https://bugs.webkit.org/show_bug.cgi?id=195016)
*/

table {
  text-indent: 0; /* 1 */
  border-color: inherit; /* 2 */
}

/*
Forms
=====
*/

/**
1. Change the font styles in all browsers.
2. Remove the margin in Firefox and Safari.
*/

button,
input,
optgroup,
select,
textarea {
  font-family: inherit; /* 1 */
  font-size: 100%; /* 1 */
  line-height: 1.15; /* 1 */
  margin: 0; /* 2 */
}

/**
Remove the inheritance of text transform in Edge and Firefox.
1. Remove the inheritance of text transform in Firefox.
*/

button,
select { /* 1 */
  text-transform: none;
}

/**
Correct the inability to style clickable types in iOS and Safari.
*/

button,
[type='button'],
[type='reset'],
[type='submit'] {
  -webkit-appearance: button;
}

/**
Remove the inner border and padding in Firefox.
*/

::-moz-focus-inner {
  border-style: none;
  padding: 0;
}

/**
Restore the focus styles unset by the previous rule.
*/

/**
Remove the additional ':invalid' styles in Firefox.
See: https://github.com/mozilla/gecko-dev/blob/2f9eacd9d3d995c937b4251a5557d95d494c9be1/layout/style/res/forms.css#L728-L737
*/

/**
Remove the padding so developers are not caught out when they zero out 'fieldset' elements in all browsers.
*/

legend {
  padding: 0;
}

/**
Add the correct vertical alignment in Chrome and Firefox.
*/

progress {
  vertical-align: baseline;
}

/**
Correct the cursor style of increment and decrement buttons in Safari.
*/

::-webkit-inner-spin-button,
::-webkit-outer-spin-button {
  height: auto;
}

/**
1. Correct the odd appearance in Chrome and Safari.
2. Correct the outline style in Safari.
*/

[type='search'] {
  -webkit-appearance: textfield; /* 1 */
  outline-offset: -2px; /* 2 */
}

/**
Remove the inner padding in Chrome and Safari on macOS.
*/

::-webkit-search-decoration {
  -webkit-appearance: none;
}

/**
1. Correct the inability to style clickable types in iOS and Safari.
2. Change font properties to 'inherit' in Safari.
*/

::-webkit-file-upload-button {
  -webkit-appearance: button; /* 1 */
  font: inherit; /* 2 */
}

/*
Interactive
===========
*/

/*
Add the correct display in Chrome and Safari.
*/

summary {
  display: list-item;
}

/**
 * Manually forked from SUIT CSS Base: https://github.com/suitcss/base
 * A thin layer on top of normalize.css that provides a starting point more
 * suitable for web applications.
 */

/**
 * Removes the default spacing and border for appropriate elements.
 */

blockquote,
dl,
dd,
h1,
h2,
h3,
h4,
h5,
h6,
hr,
figure,
p,
pre {
  margin: 0;
}

button {
  background-color: transparent;
  background-image: none;
}

fieldset {
  margin: 0;
  padding: 0;
}

ol,
ul {
  list-style: none;
  margin: 0;
  padding: 0;
}

/**
 * Tailwind custom reset styles
 */

/**
 * 1. Use the user's configured `sans` font-family (with Tailwind's default
 *    sans-serif font stack as a fallback) as a sane default.
 * 2. Use Tailwind's default "normal" line-height so the user isn't forced
 *    to override it to ensure consistency even when using the default theme.
 */

html {
  font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"; /* 1 */
  line-height: 1.5; /* 2 */
}

/**
 * Inherit font-family and line-height from `html` so users can set them as
 * a class directly on the `html` element.
 */

body {
  font-family: inherit;
  line-height: inherit;
}

/**
 * 1. Prevent padding and border from affecting element width.
 *
 *    We used to set this in the html element and inherit from
 *    the parent element for everything else. This caused issues
 *    in shadow-dom-enhanced elements like <details> where the content
 *    is wrapped by a div with box-sizing set to `content-box`.
 *
 *    https://github.com/mozdevs/cssremedy/issues/4
 *
 *
 * 2. Allow adding a border to an element by just adding a border-width.
 *
 *    By default, the way the browser specifies that an element should have no
 *    border is by setting it's border-style to `none` in the user-agent
 *    stylesheet.
 *
 *    In order to easily add borders to elements by just setting the `border-width`
 *    property, we change the default border-style for all elements to `solid`, and
 *    use border-width to hide them instead. This way our `border` utilities only
 *    need to set the `border-width` property instead of the entire `border`
 *    shorthand, making our border utilities much more straightforward to compose.
 *
 *    https://github.com/tailwindcss/tailwindcss/pull/116
 */

*,
::before,
::after {
  box-sizing: border-box; /* 1 */
  border-width: 0; /* 2 */
  border-style: solid; /* 2 */
  border-color: currentColor; /* 2 */
}

/*
 * Ensure horizontal rules are visible by default
 */

hr {
  border-top-width: 1px;
}

/**
 * Undo the `border-style: none` reset that Normalize applies to images so that
 * our `border-{width}` utilities have the expected effect.
 *
 * The Normalize reset is unnecessary for us since we default the border-width
 * to 0 on all elements.
 *
 * https://github.com/tailwindcss/tailwindcss/issues/362
 */

img {
  border-style: solid;
}

textarea {
  resize: vertical;
}

input::-moz-placeholder, textarea::-moz-placeholder {
  opacity: 1;
  color: #9ca3af;
}

input:-ms-input-placeholder, textarea:-ms-input-placeholder {
  opacity: 1;
  color: #9ca3af;
}

input::placeholder,
textarea::placeholder {
  opacity: 1;
  color: #9ca3af;
}

button,
[role="button"] {
  cursor: pointer;
}

/**
 * Override legacy focus reset from Normalize with modern Firefox focus styles.
 *
 * This is actually an improvement over the new defaults in Firefox in our testing,
 * as it triggers the better focus styles even for links, which still use a dotted
 * outline in Firefox by default.
 */

table {
  border-collapse: collapse;
}

h1,
h2,
h3,
h4,
h5,
h6 {
  font-size: inherit;
  font-weight: inherit;
}

/**
 * Reset links to optimize for opt-in styling instead of
 * opt-out.
 */

a {
  color: inherit;
  text-decoration: inherit;
}

/**
 * Reset form element properties that are easy to forget to
 * style explicitly so you don't inadvertently introduce
 * styles that deviate from your design system. These styles
 * supplement a partial reset that is already applied by
 * normalize.css.
 */

button,
input,
optgroup,
select,
textarea {
  padding: 0;
  line-height: inherit;
  color: inherit;
}

/**
 * Use the configured 'mono' font family for elements that
 * are expected to be rendered with a monospace font, falling
 * back to the system monospace stack if there is no configured
 * 'mono' font family.
 */

pre,
code,
kbd,
samp {
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
}

/**
 * 1. Make replaced elements `display: block` by default as that's
 *    the behavior you want almost all of the time. Inspired by
 *    CSS Remedy, with `svg` added as well.
 *
 *    https://github.com/mozdevs/cssremedy/issues/14
 * 
 * 2. Add `vertical-align: middle` to align replaced elements more
 *    sensibly by default when overriding `display` by adding a
 *    utility like `inline`.
 *
 *    This can trigger a poorly considered linting error in some
 *    tools but is included by design.
 * 
 *    https://github.com/jensimmons/cssremedy/issues/14#issuecomment-634934210
 */

img,
svg,
video,
canvas,
audio,
iframe,
embed,
object {
  display: block; /* 1 */
  vertical-align: middle; /* 2 */
}

/**
 * Constrain images and videos to the parent width and preserve
 * their intrinsic aspect ratio.
 *
 * https://github.com/mozdevs/cssremedy/issues/14
 */

img,
video {
  max-width: 100%;
  height: auto;
}

/**
 * Ensure the default browser behavior of the `hidden` attribute.
 */

[hidden] {
  display: none;
}

*, ::before, ::after{
  --tw-border-opacity:1;
  border-color:rgba(229, 231, 235, var(--tw-border-opacity));
}

html{
  --tw-text-opacity:1;
  color:rgba(52, 61, 60, var(--tw-text-opacity))
}

body, h1, h2, h3, h4, h5, h6{
  font-family:sofia-pro, sans-serif;
}

body,h1,h2,h3,h4,h5,h6{
  font-display:swap;
}

p{
  font-family:pt-serif, serif;
  font-display:swap
}

::-moz-focus-inner,[type=button],[type=reset],[type=search],[type=submit]{
  outline:none!important
}

button:focus{
  outline:none!important
}

button::-moz-focus-inner{
  border:0!important
}

input[type=search]::-ms-clear,input[type=search]::-ms-reveal{
  display:none;
  width:0;
  height:0
}

input[type=search]::-webkit-search-cancel-button,input[type=search]::-webkit-search-decoration,input[type=search]::-webkit-search-results-button,input[type=search]::-webkit-search-results-decoration{
  display:none
}

:active,a,button{
  -webkit-tap-highlight-color:transparent;
  -webkit-touch-callout:none
}

:focus{
  position:relative;
  outline:none!important
}

[tabindex], a, button, input{
  position:relative;
}

a{
  cursor:pointer
}

[tabindex]:after, a:after, button:after{
  --tw-border-opacity:1;
  border-color:rgba(214, 229, 227, var(--tw-border-opacity));
}

[tabindex]:after, a:after, button:after{
  border-radius:0.5rem;
}

[tabindex]:after,a:after,button:after{
  border-width:3px;
  content:"";
  position:absolute;
  top:-3px;
  bottom:-3px;
  left:-3px;
  right:-3px;
  transition:all .1s ease-in-out;
  transform:scale(.99);
  opacity:0;
  pointer-events:none;
}

:focus:after{
  opacity:1;
  transform:scale(1)
}

.container{
  width:100%;
}

@media (min-width: 360px){
  .container{
    max-width:360px;
  }
}

@media (min-width: 600px){
  .container{
    max-width:600px;
  }
}

@media (min-width: 800px){
  .container{
    max-width:800px;
  }
}

@media (min-width: 1024px){
  .container{
    max-width:1024px;
  }
}

@media (min-width: 1366px){
  .container{
    max-width:1366px;
  }
}

@media (min-width: 1448px){
  .container{
    max-width:1448px;
  }
}

@media (min-width: 1920px){
  .container{
    max-width:1920px;
  }
}

.sr-only{
  position:absolute;
  width:1px;
  height:1px;
  padding:0;
  margin:-1px;
  overflow:hidden;
  clip:rect(0, 0, 0, 0);
  white-space:nowrap;
  border-width:0;
}

.not-sr-only{
  position:static;
  width:auto;
  height:auto;
  padding:0;
  margin:0;
  overflow:visible;
  clip:auto;
  white-space:normal;
}

.pointer-events-none{
  pointer-events:none;
}

.pointer-events-auto{
  pointer-events:auto;
}

.visible{
  visibility:visible;
}

.invisible{
  visibility:hidden;
}

.static{
  position:static;
}

.fixed{
  position:fixed;
}

.absolute{
  position:absolute;
}

.relative{
  position:relative;
}

.sticky{
  position:sticky;
}

.inset-0{
  top:0px;
  right:0px;
  bottom:0px;
  left:0px;
}

.inset-1{
  top:0.25rem;
  right:0.25rem;
  bottom:0.25rem;
  left:0.25rem;
}

.inset-2{
  top:0.5rem;
  right:0.5rem;
  bottom:0.5rem;
  left:0.5rem;
}

.inset-3{
  top:0.75rem;
  right:0.75rem;
  bottom:0.75rem;
  left:0.75rem;
}

.inset-4{
  top:1rem;
  right:1rem;
  bottom:1rem;
  left:1rem;
}

.inset-5{
  top:1.25rem;
  right:1.25rem;
  bottom:1.25rem;
  left:1.25rem;
}

.inset-6{
  top:1.5rem;
  right:1.5rem;
  bottom:1.5rem;
  left:1.5rem;
}

.inset-7{
  top:1.75rem;
  right:1.75rem;
  bottom:1.75rem;
  left:1.75rem;
}

.inset-8{
  top:2rem;
  right:2rem;
  bottom:2rem;
  left:2rem;
}

.inset-9{
  top:2.25rem;
  right:2.25rem;
  bottom:2.25rem;
  left:2.25rem;
}

.inset-10{
  top:2.5rem;
  right:2.5rem;
  bottom:2.5rem;
  left:2.5rem;
}

.inset-11{
  top:2.75rem;
  right:2.75rem;
  bottom:2.75rem;
  left:2.75rem;
}

.inset-12{
  top:3rem;
  right:3rem;
  bottom:3rem;
  left:3rem;
}

.inset-14{
  top:3.5rem;
  right:3.5rem;
  bottom:3.5rem;
  left:3.5rem;
}

.inset-16{
  top:4rem;
  right:4rem;
  bottom:4rem;
  left:4rem;
}

.inset-20{
  top:5rem;
  right:5rem;
  bottom:5rem;
  left:5rem;
}

.inset-24{
  top:6rem;
  right:6rem;
  bottom:6rem;
  left:6rem;
}

.inset-28{
  top:7rem;
  right:7rem;
  bottom:7rem;
  left:7rem;
}

.inset-32{
  top:8rem;
  right:8rem;
  bottom:8rem;
  left:8rem;
}

.inset-36{
  top:9rem;
  right:9rem;
  bottom:9rem;
  left:9rem;
}

.inset-40{
  top:10rem;
  right:10rem;
  bottom:10rem;
  left:10rem;
}

.inset-44{
  top:11rem;
  right:11rem;
  bottom:11rem;
  left:11rem;
}

.inset-48{
  top:12rem;
  right:12rem;
  bottom:12rem;
  left:12rem;
}

.inset-52{
  top:13rem;
  right:13rem;
  bottom:13rem;
  left:13rem;
}

.inset-56{
  top:14rem;
  right:14rem;
  bottom:14rem;
  left:14rem;
}

.inset-60{
  top:15rem;
  right:15rem;
  bottom:15rem;
  left:15rem;
}

.inset-64{
  top:16rem;
  right:16rem;
  bottom:16rem;
  left:16rem;
}

.inset-72{
  top:18rem;
  right:18rem;
  bottom:18rem;
  left:18rem;
}

.inset-80{
  top:20rem;
  right:20rem;
  bottom:20rem;
  left:20rem;
}

.inset-96{
  top:24rem;
  right:24rem;
  bottom:24rem;
  left:24rem;
}

.inset-auto{
  top:auto;
  right:auto;
  bottom:auto;
  left:auto;
}

.inset-px{
  top:1px;
  right:1px;
  bottom:1px;
  left:1px;
}

.-inset-0{
  top:0px;
  right:0px;
  bottom:0px;
  left:0px;
}

.-inset-1{
  top:-0.25rem;
  right:-0.25rem;
  bottom:-0.25rem;
  left:-0.25rem;
}

.-inset-2{
  top:-0.5rem;
  right:-0.5rem;
  bottom:-0.5rem;
  left:-0.5rem;
}

.-inset-3{
  top:-0.75rem;
  right:-0.75rem;
  bottom:-0.75rem;
  left:-0.75rem;
}

.-inset-4{
  top:-1rem;
  right:-1rem;
  bottom:-1rem;
  left:-1rem;
}

.-inset-5{
  top:-1.25rem;
  right:-1.25rem;
  bottom:-1.25rem;
  left:-1.25rem;
}

.-inset-6{
  top:-1.5rem;
  right:-1.5rem;
  bottom:-1.5rem;
  left:-1.5rem;
}

.-inset-7{
  top:-1.75rem;
  right:-1.75rem;
  bottom:-1.75rem;
  left:-1.75rem;
}

.-inset-8{
  top:-2rem;
  right:-2rem;
  bottom:-2rem;
  left:-2rem;
}

.-inset-9{
  top:-2.25rem;
  right:-2.25rem;
  bottom:-2.25rem;
  left:-2.25rem;
}

.-inset-10{
  top:-2.5rem;
  right:-2.5rem;
  bottom:-2.5rem;
  left:-2.5rem;
}

.-inset-11{
  top:-2.75rem;
  right:-2.75rem;
  bottom:-2.75rem;
  left:-2.75rem;
}

.-inset-12{
  top:-3rem;
  right:-3rem;
  bottom:-3rem;
  left:-3rem;
}

.-inset-14{
  top:-3.5rem;
  right:-3.5rem;
  bottom:-3.5rem;
  left:-3.5rem;
}

.-inset-16{
  top:-4rem;
  right:-4rem;
  bottom:-4rem;
  left:-4rem;
}

.-inset-20{
  top:-5rem;
  right:-5rem;
  bottom:-5rem;
  left:-5rem;
}

.-inset-24{
  top:-6rem;
  right:-6rem;
  bottom:-6rem;
  left:-6rem;
}

.-inset-28{
  top:-7rem;
  right:-7rem;
  bottom:-7rem;
  left:-7rem;
}

.-inset-32{
  top:-8rem;
  right:-8rem;
  bottom:-8rem;
  left:-8rem;
}

.-inset-36{
  top:-9rem;
  right:-9rem;
  bottom:-9rem;
  left:-9rem;
}

.-inset-40{
  top:-10rem;
  right:-10rem;
  bottom:-10rem;
  left:-10rem;
}

.-inset-44{
  top:-11rem;
  right:-11rem;
  bottom:-11rem;
  left:-11rem;
}

.-inset-48{
  top:-12rem;
  right:-12rem;
  bottom:-12rem;
  left:-12rem;
}

.-inset-52{
  top:-13rem;
  right:-13rem;
  bottom:-13rem;
  left:-13rem;
}

.-inset-56{
  top:-14rem;
  right:-14rem;
  bottom:-14rem;
  left:-14rem;
}

.-inset-60{
  top:-15rem;
  right:-15rem;
  bottom:-15rem;
  left:-15rem;
}

.-inset-64{
  top:-16rem;
  right:-16rem;
  bottom:-16rem;
  left:-16rem;
}

.-inset-72{
  top:-18rem;
  right:-18rem;
  bottom:-18rem;
  left:-18rem;
}

.-inset-80{
  top:-20rem;
  right:-20rem;
  bottom:-20rem;
  left:-20rem;
}

.-inset-96{
  top:-24rem;
  right:-24rem;
  bottom:-24rem;
  left:-24rem;
}

.-inset-px{
  top:-1px;
  right:-1px;
  bottom:-1px;
  left:-1px;
}

.inset-full{
  top:100%;
  right:100%;
  bottom:100%;
  left:100%;
}

.-inset-full{
  top:-100%;
  right:-100%;
  bottom:-100%;
  left:-100%;
}

.inset-x-0{
  left:0px;
  right:0px;
}

.inset-x-1{
  left:0.25rem;
  right:0.25rem;
}

.inset-x-2{
  left:0.5rem;
  right:0.5rem;
}

.inset-x-3{
  left:0.75rem;
  right:0.75rem;
}

.inset-x-4{
  left:1rem;
  right:1rem;
}

.inset-x-5{
  left:1.25rem;
  right:1.25rem;
}

.inset-x-6{
  left:1.5rem;
  right:1.5rem;
}

.inset-x-7{
  left:1.75rem;
  right:1.75rem;
}

.inset-x-8{
  left:2rem;
  right:2rem;
}

.inset-x-9{
  left:2.25rem;
  right:2.25rem;
}

.inset-x-10{
  left:2.5rem;
  right:2.5rem;
}

.inset-x-11{
  left:2.75rem;
  right:2.75rem;
}

.inset-x-12{
  left:3rem;
  right:3rem;
}

.inset-x-14{
  left:3.5rem;
  right:3.5rem;
}

.inset-x-16{
  left:4rem;
  right:4rem;
}

.inset-x-20{
  left:5rem;
  right:5rem;
}

.inset-x-24{
  left:6rem;
  right:6rem;
}

.inset-x-28{
  left:7rem;
  right:7rem;
}

.inset-x-32{
  left:8rem;
  right:8rem;
}

.inset-x-36{
  left:9rem;
  right:9rem;
}

.inset-x-40{
  left:10rem;
  right:10rem;
}

.inset-x-44{
  left:11rem;
  right:11rem;
}

.inset-x-48{
  left:12rem;
  right:12rem;
}

.inset-x-52{
  left:13rem;
  right:13rem;
}

.inset-x-56{
  left:14rem;
  right:14rem;
}

.inset-x-60{
  left:15rem;
  right:15rem;
}

.inset-x-64{
  left:16rem;
  right:16rem;
}

.inset-x-72{
  left:18rem;
  right:18rem;
}

.inset-x-80{
  left:20rem;
  right:20rem;
}

.inset-x-96{
  left:24rem;
  right:24rem;
}

.inset-x-auto{
  left:auto;
  right:auto;
}

.inset-x-px{
  left:1px;
  right:1px;
}

.-inset-x-0{
  left:0px;
  right:0px;
}

.-inset-x-1{
  left:-0.25rem;
  right:-0.25rem;
}

.-inset-x-2{
  left:-0.5rem;
  right:-0.5rem;
}

.-inset-x-3{
  left:-0.75rem;
  right:-0.75rem;
}

.-inset-x-4{
  left:-1rem;
  right:-1rem;
}

.-inset-x-5{
  left:-1.25rem;
  right:-1.25rem;
}

.-inset-x-6{
  left:-1.5rem;
  right:-1.5rem;
}

.-inset-x-7{
  left:-1.75rem;
  right:-1.75rem;
}

.-inset-x-8{
  left:-2rem;
  right:-2rem;
}

.-inset-x-9{
  left:-2.25rem;
  right:-2.25rem;
}

.-inset-x-10{
  left:-2.5rem;
  right:-2.5rem;
}

.-inset-x-11{
  left:-2.75rem;
  right:-2.75rem;
}

.-inset-x-12{
  left:-3rem;
  right:-3rem;
}

.-inset-x-14{
  left:-3.5rem;
  right:-3.5rem;
}

.-inset-x-16{
  left:-4rem;
  right:-4rem;
}

.-inset-x-20{
  left:-5rem;
  right:-5rem;
}

.-inset-x-24{
  left:-6rem;
  right:-6rem;
}

.-inset-x-28{
  left:-7rem;
  right:-7rem;
}

.-inset-x-32{
  left:-8rem;
  right:-8rem;
}

.-inset-x-36{
  left:-9rem;
  right:-9rem;
}

.-inset-x-40{
  left:-10rem;
  right:-10rem;
}

.-inset-x-44{
  left:-11rem;
  right:-11rem;
}

.-inset-x-48{
  left:-12rem;
  right:-12rem;
}

.-inset-x-52{
  left:-13rem;
  right:-13rem;
}

.-inset-x-56{
  left:-14rem;
  right:-14rem;
}

.-inset-x-60{
  left:-15rem;
  right:-15rem;
}

.-inset-x-64{
  left:-16rem;
  right:-16rem;
}

.-inset-x-72{
  left:-18rem;
  right:-18rem;
}

.-inset-x-80{
  left:-20rem;
  right:-20rem;
}

.-inset-x-96{
  left:-24rem;
  right:-24rem;
}

.-inset-x-px{
  left:-1px;
  right:-1px;
}

.inset-x-full{
  left:100%;
  right:100%;
}

.-inset-x-full{
  left:-100%;
  right:-100%;
}

.inset-y-0{
  top:0px;
  bottom:0px;
}

.inset-y-1{
  top:0.25rem;
  bottom:0.25rem;
}

.inset-y-2{
  top:0.5rem;
  bottom:0.5rem;
}

.inset-y-3{
  top:0.75rem;
  bottom:0.75rem;
}

.inset-y-4{
  top:1rem;
  bottom:1rem;
}

.inset-y-5{
  top:1.25rem;
  bottom:1.25rem;
}

.inset-y-6{
  top:1.5rem;
  bottom:1.5rem;
}

.inset-y-7{
  top:1.75rem;
  bottom:1.75rem;
}

.inset-y-8{
  top:2rem;
  bottom:2rem;
}

.inset-y-9{
  top:2.25rem;
  bottom:2.25rem;
}

.inset-y-10{
  top:2.5rem;
  bottom:2.5rem;
}

.inset-y-11{
  top:2.75rem;
  bottom:2.75rem;
}

.inset-y-12{
  top:3rem;
  bottom:3rem;
}

.inset-y-14{
  top:3.5rem;
  bottom:3.5rem;
}

.inset-y-16{
  top:4rem;
  bottom:4rem;
}

.inset-y-20{
  top:5rem;
  bottom:5rem;
}

.inset-y-24{
  top:6rem;
  bottom:6rem;
}

.inset-y-28{
  top:7rem;
  bottom:7rem;
}

.inset-y-32{
  top:8rem;
  bottom:8rem;
}

.inset-y-36{
  top:9rem;
  bottom:9rem;
}

.inset-y-40{
  top:10rem;
  bottom:10rem;
}

.inset-y-44{
  top:11rem;
  bottom:11rem;
}

.inset-y-48{
  top:12rem;
  bottom:12rem;
}

.inset-y-52{
  top:13rem;
  bottom:13rem;
}

.inset-y-56{
  top:14rem;
  bottom:14rem;
}

.inset-y-60{
  top:15rem;
  bottom:15rem;
}

.inset-y-64{
  top:16rem;
  bottom:16rem;
}

.inset-y-72{
  top:18rem;
  bottom:18rem;
}

.inset-y-80{
  top:20rem;
  bottom:20rem;
}

.inset-y-96{
  top:24rem;
  bottom:24rem;
}

.inset-y-auto{
  top:auto;
  bottom:auto;
}

.inset-y-px{
  top:1px;
  bottom:1px;
}

.-inset-y-0{
  top:0px;
  bottom:0px;
}

.-inset-y-1{
  top:-0.25rem;
  bottom:-0.25rem;
}

.-inset-y-2{
  top:-0.5rem;
  bottom:-0.5rem;
}

.-inset-y-3{
  top:-0.75rem;
  bottom:-0.75rem;
}

.-inset-y-4{
  top:-1rem;
  bottom:-1rem;
}

.-inset-y-5{
  top:-1.25rem;
  bottom:-1.25rem;
}

.-inset-y-6{
  top:-1.5rem;
  bottom:-1.5rem;
}

.-inset-y-7{
  top:-1.75rem;
  bottom:-1.75rem;
}

.-inset-y-8{
  top:-2rem;
  bottom:-2rem;
}

.-inset-y-9{
  top:-2.25rem;
  bottom:-2.25rem;
}

.-inset-y-10{
  top:-2.5rem;
  bottom:-2.5rem;
}

.-inset-y-11{
  top:-2.75rem;
  bottom:-2.75rem;
}

.-inset-y-12{
  top:-3rem;
  bottom:-3rem;
}

.-inset-y-14{
  top:-3.5rem;
  bottom:-3.5rem;
}

.-inset-y-16{
  top:-4rem;
  bottom:-4rem;
}

.-inset-y-20{
  top:-5rem;
  bottom:-5rem;
}

.-inset-y-24{
  top:-6rem;
  bottom:-6rem;
}

.-inset-y-28{
  top:-7rem;
  bottom:-7rem;
}

.-inset-y-32{
  top:-8rem;
  bottom:-8rem;
}

.-inset-y-36{
  top:-9rem;
  bottom:-9rem;
}

.-inset-y-40{
  top:-10rem;
  bottom:-10rem;
}

.-inset-y-44{
  top:-11rem;
  bottom:-11rem;
}

.-inset-y-48{
  top:-12rem;
  bottom:-12rem;
}

.-inset-y-52{
  top:-13rem;
  bottom:-13rem;
}

.-inset-y-56{
  top:-14rem;
  bottom:-14rem;
}

.-inset-y-60{
  top:-15rem;
  bottom:-15rem;
}

.-inset-y-64{
  top:-16rem;
  bottom:-16rem;
}

.-inset-y-72{
  top:-18rem;
  bottom:-18rem;
}

.-inset-y-80{
  top:-20rem;
  bottom:-20rem;
}

.-inset-y-96{
  top:-24rem;
  bottom:-24rem;
}

.-inset-y-px{
  top:-1px;
  bottom:-1px;
}

.inset-y-full{
  top:100%;
  bottom:100%;
}

.-inset-y-full{
  top:-100%;
  bottom:-100%;
}

.top-0{
  top:0px;
}

.top-1{
  top:0.25rem;
}

.top-2{
  top:0.5rem;
}

.top-3{
  top:0.75rem;
}

.top-4{
  top:1rem;
}

.top-5{
  top:1.25rem;
}

.top-6{
  top:1.5rem;
}

.top-7{
  top:1.75rem;
}

.top-8{
  top:2rem;
}

.top-9{
  top:2.25rem;
}

.top-10{
  top:2.5rem;
}

.top-11{
  top:2.75rem;
}

.top-12{
  top:3rem;
}

.top-14{
  top:3.5rem;
}

.top-16{
  top:4rem;
}

.top-20{
  top:5rem;
}

.top-24{
  top:6rem;
}

.top-28{
  top:7rem;
}

.top-32{
  top:8rem;
}

.top-36{
  top:9rem;
}

.top-40{
  top:10rem;
}

.top-44{
  top:11rem;
}

.top-48{
  top:12rem;
}

.top-52{
  top:13rem;
}

.top-56{
  top:14rem;
}

.top-60{
  top:15rem;
}

.top-64{
  top:16rem;
}

.top-72{
  top:18rem;
}

.top-80{
  top:20rem;
}

.top-96{
  top:24rem;
}

.top-auto{
  top:auto;
}

.top-px{
  top:1px;
}

.-top-0{
  top:0px;
}

.-top-1{
  top:-0.25rem;
}

.-top-2{
  top:-0.5rem;
}

.-top-3{
  top:-0.75rem;
}

.-top-4{
  top:-1rem;
}

.-top-5{
  top:-1.25rem;
}

.-top-6{
  top:-1.5rem;
}

.-top-7{
  top:-1.75rem;
}

.-top-8{
  top:-2rem;
}

.-top-9{
  top:-2.25rem;
}

.-top-10{
  top:-2.5rem;
}

.-top-11{
  top:-2.75rem;
}

.-top-12{
  top:-3rem;
}

.-top-14{
  top:-3.5rem;
}

.-top-16{
  top:-4rem;
}

.-top-20{
  top:-5rem;
}

.-top-24{
  top:-6rem;
}

.-top-28{
  top:-7rem;
}

.-top-32{
  top:-8rem;
}

.-top-36{
  top:-9rem;
}

.-top-40{
  top:-10rem;
}

.-top-44{
  top:-11rem;
}

.-top-48{
  top:-12rem;
}

.-top-52{
  top:-13rem;
}

.-top-56{
  top:-14rem;
}

.-top-60{
  top:-15rem;
}

.-top-64{
  top:-16rem;
}

.-top-72{
  top:-18rem;
}

.-top-80{
  top:-20rem;
}

.-top-96{
  top:-24rem;
}

.-top-px{
  top:-1px;
}

.top-full{
  top:100%;
}

.-top-full{
  top:-100%;
}

.right-0{
  right:0px;
}

.right-1{
  right:0.25rem;
}

.right-2{
  right:0.5rem;
}

.right-3{
  right:0.75rem;
}

.right-4{
  right:1rem;
}

.right-5{
  right:1.25rem;
}

.right-6{
  right:1.5rem;
}

.right-7{
  right:1.75rem;
}

.right-8{
  right:2rem;
}

.right-9{
  right:2.25rem;
}

.right-10{
  right:2.5rem;
}

.right-11{
  right:2.75rem;
}

.right-12{
  right:3rem;
}

.right-14{
  right:3.5rem;
}

.right-16{
  right:4rem;
}

.right-20{
  right:5rem;
}

.right-24{
  right:6rem;
}

.right-28{
  right:7rem;
}

.right-32{
  right:8rem;
}

.right-36{
  right:9rem;
}

.right-40{
  right:10rem;
}

.right-44{
  right:11rem;
}

.right-48{
  right:12rem;
}

.right-52{
  right:13rem;
}

.right-56{
  right:14rem;
}

.right-60{
  right:15rem;
}

.right-64{
  right:16rem;
}

.right-72{
  right:18rem;
}

.right-80{
  right:20rem;
}

.right-96{
  right:24rem;
}

.right-auto{
  right:auto;
}

.right-px{
  right:1px;
}

.-right-0{
  right:0px;
}

.-right-1{
  right:-0.25rem;
}

.-right-2{
  right:-0.5rem;
}

.-right-3{
  right:-0.75rem;
}

.-right-4{
  right:-1rem;
}

.-right-5{
  right:-1.25rem;
}

.-right-6{
  right:-1.5rem;
}

.-right-7{
  right:-1.75rem;
}

.-right-8{
  right:-2rem;
}

.-right-9{
  right:-2.25rem;
}

.-right-10{
  right:-2.5rem;
}

.-right-11{
  right:-2.75rem;
}

.-right-12{
  right:-3rem;
}

.-right-14{
  right:-3.5rem;
}

.-right-16{
  right:-4rem;
}

.-right-20{
  right:-5rem;
}

.-right-24{
  right:-6rem;
}

.-right-28{
  right:-7rem;
}

.-right-32{
  right:-8rem;
}

.-right-36{
  right:-9rem;
}

.-right-40{
  right:-10rem;
}

.-right-44{
  right:-11rem;
}

.-right-48{
  right:-12rem;
}

.-right-52{
  right:-13rem;
}

.-right-56{
  right:-14rem;
}

.-right-60{
  right:-15rem;
}

.-right-64{
  right:-16rem;
}

.-right-72{
  right:-18rem;
}

.-right-80{
  right:-20rem;
}

.-right-96{
  right:-24rem;
}

.-right-px{
  right:-1px;
}

.right-full{
  right:100%;
}

.-right-full{
  right:-100%;
}

.bottom-0{
  bottom:0px;
}

.bottom-1{
  bottom:0.25rem;
}

.bottom-2{
  bottom:0.5rem;
}

.bottom-3{
  bottom:0.75rem;
}

.bottom-4{
  bottom:1rem;
}

.bottom-5{
  bottom:1.25rem;
}

.bottom-6{
  bottom:1.5rem;
}

.bottom-7{
  bottom:1.75rem;
}

.bottom-8{
  bottom:2rem;
}

.bottom-9{
  bottom:2.25rem;
}

.bottom-10{
  bottom:2.5rem;
}

.bottom-11{
  bottom:2.75rem;
}

.bottom-12{
  bottom:3rem;
}

.bottom-14{
  bottom:3.5rem;
}

.bottom-16{
  bottom:4rem;
}

.bottom-20{
  bottom:5rem;
}

.bottom-24{
  bottom:6rem;
}

.bottom-26{
  bottom:6.5rem;
}

.bottom-28{
  bottom:7rem;
}

.bottom-32{
  bottom:8rem;
}

.bottom-36{
  bottom:9rem;
}

.bottom-40{
  bottom:10rem;
}

.bottom-44{
  bottom:11rem;
}

.bottom-48{
  bottom:12rem;
}

.bottom-52{
  bottom:13rem;
}

.bottom-56{
  bottom:14rem;
}

.bottom-60{
  bottom:15rem;
}

.bottom-64{
  bottom:16rem;
}

.bottom-72{
  bottom:18rem;
}

.bottom-80{
  bottom:20rem;
}

.bottom-96{
  bottom:24rem;
}

.bottom-auto{
  bottom:auto;
}

.bottom-px{
  bottom:1px;
}

.-bottom-0{
  bottom:0px;
}

.-bottom-1{
  bottom:-0.25rem;
}

.-bottom-2{
  bottom:-0.5rem;
}

.-bottom-3{
  bottom:-0.75rem;
}

.-bottom-4{
  bottom:-1rem;
}

.-bottom-5{
  bottom:-1.25rem;
}

.-bottom-6{
  bottom:-1.5rem;
}

.-bottom-7{
  bottom:-1.75rem;
}

.-bottom-8{
  bottom:-2rem;
}

.-bottom-9{
  bottom:-2.25rem;
}

.-bottom-10{
  bottom:-2.5rem;
}

.-bottom-11{
  bottom:-2.75rem;
}

.-bottom-12{
  bottom:-3rem;
}

.-bottom-14{
  bottom:-3.5rem;
}

.-bottom-16{
  bottom:-4rem;
}

.-bottom-20{
  bottom:-5rem;
}

.-bottom-24{
  bottom:-6rem;
}

.-bottom-28{
  bottom:-7rem;
}

.-bottom-32{
  bottom:-8rem;
}

.-bottom-36{
  bottom:-9rem;
}

.-bottom-40{
  bottom:-10rem;
}

.-bottom-44{
  bottom:-11rem;
}

.-bottom-48{
  bottom:-12rem;
}

.-bottom-52{
  bottom:-13rem;
}

.-bottom-56{
  bottom:-14rem;
}

.-bottom-60{
  bottom:-15rem;
}

.-bottom-64{
  bottom:-16rem;
}

.-bottom-72{
  bottom:-18rem;
}

.-bottom-80{
  bottom:-20rem;
}

.-bottom-96{
  bottom:-24rem;
}

.-bottom-px{
  bottom:-1px;
}

.bottom-full{
  bottom:100%;
}

.-bottom-full{
  bottom:-100%;
}

.left-0{
  left:0px;
}

.left-1{
  left:0.25rem;
}

.left-2{
  left:0.5rem;
}

.left-3{
  left:0.75rem;
}

.left-4{
  left:1rem;
}

.left-5{
  left:1.25rem;
}

.left-6{
  left:1.5rem;
}

.left-7{
  left:1.75rem;
}

.left-8{
  left:2rem;
}

.left-9{
  left:2.25rem;
}

.left-10{
  left:2.5rem;
}

.left-11{
  left:2.75rem;
}

.left-12{
  left:3rem;
}

.left-14{
  left:3.5rem;
}

.left-16{
  left:4rem;
}

.left-20{
  left:5rem;
}

.left-24{
  left:6rem;
}

.left-28{
  left:7rem;
}

.left-32{
  left:8rem;
}

.left-36{
  left:9rem;
}

.left-40{
  left:10rem;
}

.left-44{
  left:11rem;
}

.left-48{
  left:12rem;
}

.left-52{
  left:13rem;
}

.left-56{
  left:14rem;
}

.left-60{
  left:15rem;
}

.left-64{
  left:16rem;
}

.left-72{
  left:18rem;
}

.left-80{
  left:20rem;
}

.left-96{
  left:24rem;
}

.left-auto{
  left:auto;
}

.left-px{
  left:1px;
}

.-left-0{
  left:0px;
}

.-left-1{
  left:-0.25rem;
}

.-left-2{
  left:-0.5rem;
}

.-left-3{
  left:-0.75rem;
}

.-left-4{
  left:-1rem;
}

.-left-5{
  left:-1.25rem;
}

.-left-6{
  left:-1.5rem;
}

.-left-7{
  left:-1.75rem;
}

.-left-8{
  left:-2rem;
}

.-left-9{
  left:-2.25rem;
}

.-left-10{
  left:-2.5rem;
}

.-left-11{
  left:-2.75rem;
}

.-left-12{
  left:-3rem;
}

.-left-14{
  left:-3.5rem;
}

.-left-16{
  left:-4rem;
}

.-left-20{
  left:-5rem;
}

.-left-24{
  left:-6rem;
}

.-left-28{
  left:-7rem;
}

.-left-32{
  left:-8rem;
}

.-left-36{
  left:-9rem;
}

.-left-40{
  left:-10rem;
}

.-left-44{
  left:-11rem;
}

.-left-48{
  left:-12rem;
}

.-left-52{
  left:-13rem;
}

.-left-56{
  left:-14rem;
}

.-left-60{
  left:-15rem;
}

.-left-64{
  left:-16rem;
}

.-left-72{
  left:-18rem;
}

.-left-80{
  left:-20rem;
}

.-left-96{
  left:-24rem;
}

.-left-px{
  left:-1px;
}

.left-full{
  left:100%;
}

.-left-full{
  left:-100%;
}

.isolate{
  isolation:isolate;
}

.isolation-auto{
  isolation:auto;
}

.z-0{
  z-index:0;
}

.z-10{
  z-index:10;
}

.z-20{
  z-index:20;
}

.z-30{
  z-index:30;
}

.z-40{
  z-index:40;
}

.z-50{
  z-index:50;
}

.z-auto{
  z-index:auto;
}

.order-1{
  order:1;
}

.order-2{
  order:2;
}

.order-3{
  order:3;
}

.order-4{
  order:4;
}

.order-5{
  order:5;
}

.order-6{
  order:6;
}

.order-7{
  order:7;
}

.order-8{
  order:8;
}

.order-9{
  order:9;
}

.order-10{
  order:10;
}

.order-11{
  order:11;
}

.order-12{
  order:12;
}

.order-first{
  order:-9999;
}

.order-last{
  order:9999;
}

.order-none{
  order:0;
}

.col-auto{
  grid-column:auto;
}

.col-span-1{
  grid-column:span 1 / span 1;
}

.col-span-2{
  grid-column:span 2 / span 2;
}

.col-span-3{
  grid-column:span 3 / span 3;
}

.col-span-4{
  grid-column:span 4 / span 4;
}

.col-span-5{
  grid-column:span 5 / span 5;
}

.col-span-6{
  grid-column:span 6 / span 6;
}

.col-span-7{
  grid-column:span 7 / span 7;
}

.col-span-8{
  grid-column:span 8 / span 8;
}

.col-span-9{
  grid-column:span 9 / span 9;
}

.col-span-10{
  grid-column:span 10 / span 10;
}

.col-span-11{
  grid-column:span 11 / span 11;
}

.col-span-12{
  grid-column:span 12 / span 12;
}

.col-span-full{
  grid-column:1 / -1;
}

.col-start-1{
  grid-column-start:1;
}

.col-start-2{
  grid-column-start:2;
}

.col-start-3{
  grid-column-start:3;
}

.col-start-4{
  grid-column-start:4;
}

.col-start-5{
  grid-column-start:5;
}

.col-start-6{
  grid-column-start:6;
}

.col-start-7{
  grid-column-start:7;
}

.col-start-8{
  grid-column-start:8;
}

.col-start-9{
  grid-column-start:9;
}

.col-start-10{
  grid-column-start:10;
}

.col-start-11{
  grid-column-start:11;
}

.col-start-12{
  grid-column-start:12;
}

.col-start-13{
  grid-column-start:13;
}

.col-start-auto{
  grid-column-start:auto;
}

.col-end-1{
  grid-column-end:1;
}

.col-end-2{
  grid-column-end:2;
}

.col-end-3{
  grid-column-end:3;
}

.col-end-4{
  grid-column-end:4;
}

.col-end-5{
  grid-column-end:5;
}

.col-end-6{
  grid-column-end:6;
}

.col-end-7{
  grid-column-end:7;
}

.col-end-8{
  grid-column-end:8;
}

.col-end-9{
  grid-column-end:9;
}

.col-end-10{
  grid-column-end:10;
}

.col-end-11{
  grid-column-end:11;
}

.col-end-12{
  grid-column-end:12;
}

.col-end-13{
  grid-column-end:13;
}

.col-end-auto{
  grid-column-end:auto;
}

.row-auto{
  grid-row:auto;
}

.row-span-1{
  grid-row:span 1 / span 1;
}

.row-span-2{
  grid-row:span 2 / span 2;
}

.row-span-3{
  grid-row:span 3 / span 3;
}

.row-span-4{
  grid-row:span 4 / span 4;
}

.row-span-5{
  grid-row:span 5 / span 5;
}

.row-span-6{
  grid-row:span 6 / span 6;
}

.row-span-full{
  grid-row:1 / -1;
}

.row-start-1{
  grid-row-start:1;
}

.row-start-2{
  grid-row-start:2;
}

.row-start-3{
  grid-row-start:3;
}

.row-start-4{
  grid-row-start:4;
}

.row-start-5{
  grid-row-start:5;
}

.row-start-6{
  grid-row-start:6;
}

.row-start-7{
  grid-row-start:7;
}

.row-start-auto{
  grid-row-start:auto;
}

.row-end-1{
  grid-row-end:1;
}

.row-end-2{
  grid-row-end:2;
}

.row-end-3{
  grid-row-end:3;
}

.row-end-4{
  grid-row-end:4;
}

.row-end-5{
  grid-row-end:5;
}

.row-end-6{
  grid-row-end:6;
}

.row-end-7{
  grid-row-end:7;
}

.row-end-auto{
  grid-row-end:auto;
}

.float-right{
  float:right;
}

.float-left{
  float:left;
}

.float-none{
  float:none;
}

.clear-left{
  clear:left;
}

.clear-right{
  clear:right;
}

.clear-both{
  clear:both;
}

.clear-none{
  clear:none;
}

.m-0{
  margin:0px;
}

.m-1{
  margin:0.25rem;
}

.m-2{
  margin:0.5rem;
}

.m-3{
  margin:0.75rem;
}

.m-4{
  margin:1rem;
}

.m-5{
  margin:1.25rem;
}

.m-6{
  margin:1.5rem;
}

.m-7{
  margin:1.75rem;
}

.m-8{
  margin:2rem;
}

.m-9{
  margin:2.25rem;
}

.m-10{
  margin:2.5rem;
}

.m-11{
  margin:2.75rem;
}

.m-12{
  margin:3rem;
}

.m-14{
  margin:3.5rem;
}

.m-16{
  margin:4rem;
}

.m-20{
  margin:5rem;
}

.m-24{
  margin:6rem;
}

.m-28{
  margin:7rem;
}

.m-32{
  margin:8rem;
}

.m-36{
  margin:9rem;
}

.m-40{
  margin:10rem;
}

.m-44{
  margin:11rem;
}

.m-48{
  margin:12rem;
}

.m-52{
  margin:13rem;
}

.m-56{
  margin:14rem;
}

.m-60{
  margin:15rem;
}

.m-64{
  margin:16rem;
}

.m-72{
  margin:18rem;
}

.m-80{
  margin:20rem;
}

.m-96{
  margin:24rem;
}

.m-auto{
  margin:auto;
}

.m-px{
  margin:1px;
}

.-m-0{
  margin:0px;
}

.-m-1{
  margin:-0.25rem;
}

.-m-2{
  margin:-0.5rem;
}

.-m-3{
  margin:-0.75rem;
}

.-m-4{
  margin:-1rem;
}

.-m-5{
  margin:-1.25rem;
}

.-m-6{
  margin:-1.5rem;
}

.-m-7{
  margin:-1.75rem;
}

.-m-8{
  margin:-2rem;
}

.-m-9{
  margin:-2.25rem;
}

.-m-10{
  margin:-2.5rem;
}

.-m-11{
  margin:-2.75rem;
}

.-m-12{
  margin:-3rem;
}

.-m-14{
  margin:-3.5rem;
}

.-m-16{
  margin:-4rem;
}

.-m-20{
  margin:-5rem;
}

.-m-24{
  margin:-6rem;
}

.-m-28{
  margin:-7rem;
}

.-m-32{
  margin:-8rem;
}

.-m-36{
  margin:-9rem;
}

.-m-40{
  margin:-10rem;
}

.-m-44{
  margin:-11rem;
}

.-m-48{
  margin:-12rem;
}

.-m-52{
  margin:-13rem;
}

.-m-56{
  margin:-14rem;
}

.-m-60{
  margin:-15rem;
}

.-m-64{
  margin:-16rem;
}

.-m-72{
  margin:-18rem;
}

.-m-80{
  margin:-20rem;
}

.-m-96{
  margin:-24rem;
}

.-m-px{
  margin:-1px;
}

.mx-0{
  margin-left:0px;
  margin-right:0px;
}

.mx-1{
  margin-left:0.25rem;
  margin-right:0.25rem;
}

.mx-2{
  margin-left:0.5rem;
  margin-right:0.5rem;
}

.mx-3{
  margin-left:0.75rem;
  margin-right:0.75rem;
}

.mx-4{
  margin-left:1rem;
  margin-right:1rem;
}

.mx-5{
  margin-left:1.25rem;
  margin-right:1.25rem;
}

.mx-6{
  margin-left:1.5rem;
  margin-right:1.5rem;
}

.mx-7{
  margin-left:1.75rem;
  margin-right:1.75rem;
}

.mx-8{
  margin-left:2rem;
  margin-right:2rem;
}

.mx-9{
  margin-left:2.25rem;
  margin-right:2.25rem;
}

.mx-10{
  margin-left:2.5rem;
  margin-right:2.5rem;
}

.mx-11{
  margin-left:2.75rem;
  margin-right:2.75rem;
}

.mx-12{
  margin-left:3rem;
  margin-right:3rem;
}

.mx-14{
  margin-left:3.5rem;
  margin-right:3.5rem;
}

.mx-16{
  margin-left:4rem;
  margin-right:4rem;
}

.mx-20{
  margin-left:5rem;
  margin-right:5rem;
}

.mx-24{
  margin-left:6rem;
  margin-right:6rem;
}

.mx-28{
  margin-left:7rem;
  margin-right:7rem;
}

.mx-32{
  margin-left:8rem;
  margin-right:8rem;
}

.mx-36{
  margin-left:9rem;
  margin-right:9rem;
}

.mx-40{
  margin-left:10rem;
  margin-right:10rem;
}

.mx-44{
  margin-left:11rem;
  margin-right:11rem;
}

.mx-48{
  margin-left:12rem;
  margin-right:12rem;
}

.mx-52{
  margin-left:13rem;
  margin-right:13rem;
}

.mx-56{
  margin-left:14rem;
  margin-right:14rem;
}

.mx-60{
  margin-left:15rem;
  margin-right:15rem;
}

.mx-64{
  margin-left:16rem;
  margin-right:16rem;
}

.mx-72{
  margin-left:18rem;
  margin-right:18rem;
}

.mx-80{
  margin-left:20rem;
  margin-right:20rem;
}

.mx-96{
  margin-left:24rem;
  margin-right:24rem;
}

.mx-auto{
  margin-left:auto;
  margin-right:auto;
}

.mx-px{
  margin-left:1px;
  margin-right:1px;
}

.mx-n4{
  margin-left:-1rem;
  margin-right:-1rem;
}

.-mx-0{
  margin-left:0px;
  margin-right:0px;
}

.-mx-1{
  margin-left:-0.25rem;
  margin-right:-0.25rem;
}

.-mx-2{
  margin-left:-0.5rem;
  margin-right:-0.5rem;
}

.-mx-3{
  margin-left:-0.75rem;
  margin-right:-0.75rem;
}

.-mx-4{
  margin-left:-1rem;
  margin-right:-1rem;
}

.-mx-5{
  margin-left:-1.25rem;
  margin-right:-1.25rem;
}

.-mx-6{
  margin-left:-1.5rem;
  margin-right:-1.5rem;
}

.-mx-7{
  margin-left:-1.75rem;
  margin-right:-1.75rem;
}

.-mx-8{
  margin-left:-2rem;
  margin-right:-2rem;
}

.-mx-9{
  margin-left:-2.25rem;
  margin-right:-2.25rem;
}

.-mx-10{
  margin-left:-2.5rem;
  margin-right:-2.5rem;
}

.-mx-11{
  margin-left:-2.75rem;
  margin-right:-2.75rem;
}

.-mx-12{
  margin-left:-3rem;
  margin-right:-3rem;
}

.-mx-14{
  margin-left:-3.5rem;
  margin-right:-3.5rem;
}

.-mx-16{
  margin-left:-4rem;
  margin-right:-4rem;
}

.-mx-20{
  margin-left:-5rem;
  margin-right:-5rem;
}

.-mx-24{
  margin-left:-6rem;
  margin-right:-6rem;
}

.-mx-28{
  margin-left:-7rem;
  margin-right:-7rem;
}

.-mx-32{
  margin-left:-8rem;
  margin-right:-8rem;
}

.-mx-36{
  margin-left:-9rem;
  margin-right:-9rem;
}

.-mx-40{
  margin-left:-10rem;
  margin-right:-10rem;
}

.-mx-44{
  margin-left:-11rem;
  margin-right:-11rem;
}

.-mx-48{
  margin-left:-12rem;
  margin-right:-12rem;
}

.-mx-52{
  margin-left:-13rem;
  margin-right:-13rem;
}

.-mx-56{
  margin-left:-14rem;
  margin-right:-14rem;
}

.-mx-60{
  margin-left:-15rem;
  margin-right:-15rem;
}

.-mx-64{
  margin-left:-16rem;
  margin-right:-16rem;
}

.-mx-72{
  margin-left:-18rem;
  margin-right:-18rem;
}

.-mx-80{
  margin-left:-20rem;
  margin-right:-20rem;
}

.-mx-96{
  margin-left:-24rem;
  margin-right:-24rem;
}

.-mx-px{
  margin-left:-1px;
  margin-right:-1px;
}

.my-0{
  margin-top:0px;
  margin-bottom:0px;
}

.my-1{
  margin-top:0.25rem;
  margin-bottom:0.25rem;
}

.my-2{
  margin-top:0.5rem;
  margin-bottom:0.5rem;
}

.my-3{
  margin-top:0.75rem;
  margin-bottom:0.75rem;
}

.my-4{
  margin-top:1rem;
  margin-bottom:1rem;
}

.my-5{
  margin-top:1.25rem;
  margin-bottom:1.25rem;
}

.my-6{
  margin-top:1.5rem;
  margin-bottom:1.5rem;
}

.my-7{
  margin-top:1.75rem;
  margin-bottom:1.75rem;
}

.my-8{
  margin-top:2rem;
  margin-bottom:2rem;
}

.my-9{
  margin-top:2.25rem;
  margin-bottom:2.25rem;
}

.my-10{
  margin-top:2.5rem;
  margin-bottom:2.5rem;
}

.my-11{
  margin-top:2.75rem;
  margin-bottom:2.75rem;
}

.my-12{
  margin-top:3rem;
  margin-bottom:3rem;
}

.my-14{
  margin-top:3.5rem;
  margin-bottom:3.5rem;
}

.my-16{
  margin-top:4rem;
  margin-bottom:4rem;
}

.my-20{
  margin-top:5rem;
  margin-bottom:5rem;
}

.my-24{
  margin-top:6rem;
  margin-bottom:6rem;
}

.my-28{
  margin-top:7rem;
  margin-bottom:7rem;
}

.my-32{
  margin-top:8rem;
  margin-bottom:8rem;
}

.my-36{
  margin-top:9rem;
  margin-bottom:9rem;
}

.my-40{
  margin-top:10rem;
  margin-bottom:10rem;
}

.my-44{
  margin-top:11rem;
  margin-bottom:11rem;
}

.my-48{
  margin-top:12rem;
  margin-bottom:12rem;
}

.my-52{
  margin-top:13rem;
  margin-bottom:13rem;
}

.my-56{
  margin-top:14rem;
  margin-bottom:14rem;
}

.my-60{
  margin-top:15rem;
  margin-bottom:15rem;
}

.my-64{
  margin-top:16rem;
  margin-bottom:16rem;
}

.my-72{
  margin-top:18rem;
  margin-bottom:18rem;
}

.my-80{
  margin-top:20rem;
  margin-bottom:20rem;
}

.my-96{
  margin-top:24rem;
  margin-bottom:24rem;
}

.my-auto{
  margin-top:auto;
  margin-bottom:auto;
}

.my-px{
  margin-top:1px;
  margin-bottom:1px;
}

.-my-0{
  margin-top:0px;
  margin-bottom:0px;
}

.-my-1{
  margin-top:-0.25rem;
  margin-bottom:-0.25rem;
}

.-my-2{
  margin-top:-0.5rem;
  margin-bottom:-0.5rem;
}

.-my-3{
  margin-top:-0.75rem;
  margin-bottom:-0.75rem;
}

.-my-4{
  margin-top:-1rem;
  margin-bottom:-1rem;
}

.-my-5{
  margin-top:-1.25rem;
  margin-bottom:-1.25rem;
}

.-my-6{
  margin-top:-1.5rem;
  margin-bottom:-1.5rem;
}

.-my-7{
  margin-top:-1.75rem;
  margin-bottom:-1.75rem;
}

.-my-8{
  margin-top:-2rem;
  margin-bottom:-2rem;
}

.-my-9{
  margin-top:-2.25rem;
  margin-bottom:-2.25rem;
}

.-my-10{
  margin-top:-2.5rem;
  margin-bottom:-2.5rem;
}

.-my-11{
  margin-top:-2.75rem;
  margin-bottom:-2.75rem;
}

.-my-12{
  margin-top:-3rem;
  margin-bottom:-3rem;
}

.-my-14{
  margin-top:-3.5rem;
  margin-bottom:-3.5rem;
}

.-my-16{
  margin-top:-4rem;
  margin-bottom:-4rem;
}

.-my-20{
  margin-top:-5rem;
  margin-bottom:-5rem;
}

.-my-24{
  margin-top:-6rem;
  margin-bottom:-6rem;
}

.-my-28{
  margin-top:-7rem;
  margin-bottom:-7rem;
}

.-my-32{
  margin-top:-8rem;
  margin-bottom:-8rem;
}

.-my-36{
  margin-top:-9rem;
  margin-bottom:-9rem;
}

.-my-40{
  margin-top:-10rem;
  margin-bottom:-10rem;
}

.-my-44{
  margin-top:-11rem;
  margin-bottom:-11rem;
}

.-my-48{
  margin-top:-12rem;
  margin-bottom:-12rem;
}

.-my-52{
  margin-top:-13rem;
  margin-bottom:-13rem;
}

.-my-56{
  margin-top:-14rem;
  margin-bottom:-14rem;
}

.-my-60{
  margin-top:-15rem;
  margin-bottom:-15rem;
}

.-my-64{
  margin-top:-16rem;
  margin-bottom:-16rem;
}

.-my-72{
  margin-top:-18rem;
  margin-bottom:-18rem;
}

.-my-80{
  margin-top:-20rem;
  margin-bottom:-20rem;
}

.-my-96{
  margin-top:-24rem;
  margin-bottom:-24rem;
}

.-my-px{
  margin-top:-1px;
  margin-bottom:-1px;
}

.mt-0{
  margin-top:0px;
}

.mt-1{
  margin-top:0.25rem;
}

.mt-2{
  margin-top:0.5rem;
}

.mt-3{
  margin-top:0.75rem;
}

.mt-4{
  margin-top:1rem;
}

.mt-5{
  margin-top:1.25rem;
}

.mt-6{
  margin-top:1.5rem;
}

.mt-7{
  margin-top:1.75rem;
}

.mt-8{
  margin-top:2rem;
}

.mt-9{
  margin-top:2.25rem;
}

.mt-10{
  margin-top:2.5rem;
}

.mt-11{
  margin-top:2.75rem;
}

.mt-12{
  margin-top:3rem;
}

.mt-14{
  margin-top:3.5rem;
}

.mt-16{
  margin-top:4rem;
}

.mt-20{
  margin-top:5rem;
}

.mt-24{
  margin-top:6rem;
}

.mt-28{
  margin-top:7rem;
}

.mt-32{
  margin-top:8rem;
}

.mt-36{
  margin-top:9rem;
}

.mt-40{
  margin-top:10rem;
}

.mt-44{
  margin-top:11rem;
}

.mt-48{
  margin-top:12rem;
}

.mt-52{
  margin-top:13rem;
}

.mt-56{
  margin-top:14rem;
}

.mt-60{
  margin-top:15rem;
}

.mt-64{
  margin-top:16rem;
}

.mt-72{
  margin-top:18rem;
}

.mt-80{
  margin-top:20rem;
}

.mt-96{
  margin-top:24rem;
}

.mt-auto{
  margin-top:auto;
}

.mt-px{
  margin-top:1px;
}

.-mt-0{
  margin-top:0px;
}

.-mt-1{
  margin-top:-0.25rem;
}

.-mt-2{
  margin-top:-0.5rem;
}

.-mt-3{
  margin-top:-0.75rem;
}

.-mt-4{
  margin-top:-1rem;
}

.-mt-5{
  margin-top:-1.25rem;
}

.-mt-6{
  margin-top:-1.5rem;
}

.-mt-7{
  margin-top:-1.75rem;
}

.-mt-8{
  margin-top:-2rem;
}

.-mt-9{
  margin-top:-2.25rem;
}

.-mt-10{
  margin-top:-2.5rem;
}

.-mt-11{
  margin-top:-2.75rem;
}

.-mt-12{
  margin-top:-3rem;
}

.-mt-14{
  margin-top:-3.5rem;
}

.-mt-16{
  margin-top:-4rem;
}

.-mt-20{
  margin-top:-5rem;
}

.-mt-24{
  margin-top:-6rem;
}

.-mt-28{
  margin-top:-7rem;
}

.-mt-32{
  margin-top:-8rem;
}

.-mt-36{
  margin-top:-9rem;
}

.-mt-40{
  margin-top:-10rem;
}

.-mt-44{
  margin-top:-11rem;
}

.-mt-48{
  margin-top:-12rem;
}

.-mt-52{
  margin-top:-13rem;
}

.-mt-56{
  margin-top:-14rem;
}

.-mt-60{
  margin-top:-15rem;
}

.-mt-64{
  margin-top:-16rem;
}

.-mt-72{
  margin-top:-18rem;
}

.-mt-80{
  margin-top:-20rem;
}

.-mt-96{
  margin-top:-24rem;
}

.-mt-px{
  margin-top:-1px;
}

.mr-0{
  margin-right:0px;
}

.mr-1{
  margin-right:0.25rem;
}

.mr-2{
  margin-right:0.5rem;
}

.mr-3{
  margin-right:0.75rem;
}

.mr-4{
  margin-right:1rem;
}

.mr-5{
  margin-right:1.25rem;
}

.mr-6{
  margin-right:1.5rem;
}

.mr-7{
  margin-right:1.75rem;
}

.mr-8{
  margin-right:2rem;
}

.mr-9{
  margin-right:2.25rem;
}

.mr-10{
  margin-right:2.5rem;
}

.mr-11{
  margin-right:2.75rem;
}

.mr-12{
  margin-right:3rem;
}

.mr-14{
  margin-right:3.5rem;
}

.mr-16{
  margin-right:4rem;
}

.mr-20{
  margin-right:5rem;
}

.mr-24{
  margin-right:6rem;
}

.mr-28{
  margin-right:7rem;
}

.mr-32{
  margin-right:8rem;
}

.mr-36{
  margin-right:9rem;
}

.mr-40{
  margin-right:10rem;
}

.mr-44{
  margin-right:11rem;
}

.mr-48{
  margin-right:12rem;
}

.mr-52{
  margin-right:13rem;
}

.mr-56{
  margin-right:14rem;
}

.mr-60{
  margin-right:15rem;
}

.mr-64{
  margin-right:16rem;
}

.mr-72{
  margin-right:18rem;
}

.mr-80{
  margin-right:20rem;
}

.mr-96{
  margin-right:24rem;
}

.mr-auto{
  margin-right:auto;
}

.mr-px{
  margin-right:1px;
}

.-mr-0{
  margin-right:0px;
}

.-mr-1{
  margin-right:-0.25rem;
}

.-mr-2{
  margin-right:-0.5rem;
}

.-mr-3{
  margin-right:-0.75rem;
}

.-mr-4{
  margin-right:-1rem;
}

.-mr-5{
  margin-right:-1.25rem;
}

.-mr-6{
  margin-right:-1.5rem;
}

.-mr-7{
  margin-right:-1.75rem;
}

.-mr-8{
  margin-right:-2rem;
}

.-mr-9{
  margin-right:-2.25rem;
}

.-mr-10{
  margin-right:-2.5rem;
}

.-mr-11{
  margin-right:-2.75rem;
}

.-mr-12{
  margin-right:-3rem;
}

.-mr-14{
  margin-right:-3.5rem;
}

.-mr-16{
  margin-right:-4rem;
}

.-mr-20{
  margin-right:-5rem;
}

.-mr-24{
  margin-right:-6rem;
}

.-mr-28{
  margin-right:-7rem;
}

.-mr-32{
  margin-right:-8rem;
}

.-mr-36{
  margin-right:-9rem;
}

.-mr-40{
  margin-right:-10rem;
}

.-mr-44{
  margin-right:-11rem;
}

.-mr-48{
  margin-right:-12rem;
}

.-mr-52{
  margin-right:-13rem;
}

.-mr-56{
  margin-right:-14rem;
}

.-mr-60{
  margin-right:-15rem;
}

.-mr-64{
  margin-right:-16rem;
}

.-mr-72{
  margin-right:-18rem;
}

.-mr-80{
  margin-right:-20rem;
}

.-mr-96{
  margin-right:-24rem;
}

.-mr-px{
  margin-right:-1px;
}

.mb-0{
  margin-bottom:0px;
}

.mb-1{
  margin-bottom:0.25rem;
}

.mb-2{
  margin-bottom:0.5rem;
}

.mb-3{
  margin-bottom:0.75rem;
}

.mb-4{
  margin-bottom:1rem;
}

.mb-5{
  margin-bottom:1.25rem;
}

.mb-6{
  margin-bottom:1.5rem;
}

.mb-7{
  margin-bottom:1.75rem;
}

.mb-8{
  margin-bottom:2rem;
}

.mb-9{
  margin-bottom:2.25rem;
}

.mb-10{
  margin-bottom:2.5rem;
}

.mb-11{
  margin-bottom:2.75rem;
}

.mb-12{
  margin-bottom:3rem;
}

.mb-14{
  margin-bottom:3.5rem;
}

.mb-16{
  margin-bottom:4rem;
}

.mb-18{
  margin-bottom:4.5rem;
}

.mb-20{
  margin-bottom:5rem;
}

.mb-24{
  margin-bottom:6rem;
}

.mb-28{
  margin-bottom:7rem;
}

.mb-32{
  margin-bottom:8rem;
}

.mb-36{
  margin-bottom:9rem;
}

.mb-40{
  margin-bottom:10rem;
}

.mb-44{
  margin-bottom:11rem;
}

.mb-48{
  margin-bottom:12rem;
}

.mb-52{
  margin-bottom:13rem;
}

.mb-56{
  margin-bottom:14rem;
}

.mb-60{
  margin-bottom:15rem;
}

.mb-64{
  margin-bottom:16rem;
}

.mb-72{
  margin-bottom:18rem;
}

.mb-80{
  margin-bottom:20rem;
}

.mb-96{
  margin-bottom:24rem;
}

.mb-auto{
  margin-bottom:auto;
}

.mb-px{
  margin-bottom:1px;
}

.-mb-0{
  margin-bottom:0px;
}

.-mb-1{
  margin-bottom:-0.25rem;
}

.-mb-2{
  margin-bottom:-0.5rem;
}

.-mb-3{
  margin-bottom:-0.75rem;
}

.-mb-4{
  margin-bottom:-1rem;
}

.-mb-5{
  margin-bottom:-1.25rem;
}

.-mb-6{
  margin-bottom:-1.5rem;
}

.-mb-7{
  margin-bottom:-1.75rem;
}

.-mb-8{
  margin-bottom:-2rem;
}

.-mb-9{
  margin-bottom:-2.25rem;
}

.-mb-10{
  margin-bottom:-2.5rem;
}

.-mb-11{
  margin-bottom:-2.75rem;
}

.-mb-12{
  margin-bottom:-3rem;
}

.-mb-14{
  margin-bottom:-3.5rem;
}

.-mb-16{
  margin-bottom:-4rem;
}

.-mb-20{
  margin-bottom:-5rem;
}

.-mb-24{
  margin-bottom:-6rem;
}

.-mb-28{
  margin-bottom:-7rem;
}

.-mb-32{
  margin-bottom:-8rem;
}

.-mb-36{
  margin-bottom:-9rem;
}

.-mb-40{
  margin-bottom:-10rem;
}

.-mb-44{
  margin-bottom:-11rem;
}

.-mb-48{
  margin-bottom:-12rem;
}

.-mb-52{
  margin-bottom:-13rem;
}

.-mb-56{
  margin-bottom:-14rem;
}

.-mb-60{
  margin-bottom:-15rem;
}

.-mb-64{
  margin-bottom:-16rem;
}

.-mb-72{
  margin-bottom:-18rem;
}

.-mb-80{
  margin-bottom:-20rem;
}

.-mb-96{
  margin-bottom:-24rem;
}

.-mb-px{
  margin-bottom:-1px;
}

.ml-0{
  margin-left:0px;
}

.ml-1{
  margin-left:0.25rem;
}

.ml-2{
  margin-left:0.5rem;
}

.ml-3{
  margin-left:0.75rem;
}

.ml-4{
  margin-left:1rem;
}

.ml-5{
  margin-left:1.25rem;
}

.ml-6{
  margin-left:1.5rem;
}

.ml-7{
  margin-left:1.75rem;
}

.ml-8{
  margin-left:2rem;
}

.ml-9{
  margin-left:2.25rem;
}

.ml-10{
  margin-left:2.5rem;
}

.ml-11{
  margin-left:2.75rem;
}

.ml-12{
  margin-left:3rem;
}

.ml-14{
  margin-left:3.5rem;
}

.ml-16{
  margin-left:4rem;
}

.ml-20{
  margin-left:5rem;
}

.ml-24{
  margin-left:6rem;
}

.ml-28{
  margin-left:7rem;
}

.ml-32{
  margin-left:8rem;
}

.ml-36{
  margin-left:9rem;
}

.ml-40{
  margin-left:10rem;
}

.ml-44{
  margin-left:11rem;
}

.ml-48{
  margin-left:12rem;
}

.ml-52{
  margin-left:13rem;
}

.ml-56{
  margin-left:14rem;
}

.ml-60{
  margin-left:15rem;
}

.ml-64{
  margin-left:16rem;
}

.ml-72{
  margin-left:18rem;
}

.ml-80{
  margin-left:20rem;
}

.ml-96{
  margin-left:24rem;
}

.ml-auto{
  margin-left:auto;
}

.ml-px{
  margin-left:1px;
}

.ml-n2{
  margin-left:-0.5rem;
}

.-ml-0{
  margin-left:0px;
}

.-ml-1{
  margin-left:-0.25rem;
}

.-ml-2{
  margin-left:-0.5rem;
}

.-ml-3{
  margin-left:-0.75rem;
}

.-ml-4{
  margin-left:-1rem;
}

.-ml-5{
  margin-left:-1.25rem;
}

.-ml-6{
  margin-left:-1.5rem;
}

.-ml-7{
  margin-left:-1.75rem;
}

.-ml-8{
  margin-left:-2rem;
}

.-ml-9{
  margin-left:-2.25rem;
}

.-ml-10{
  margin-left:-2.5rem;
}

.-ml-11{
  margin-left:-2.75rem;
}

.-ml-12{
  margin-left:-3rem;
}

.-ml-14{
  margin-left:-3.5rem;
}

.-ml-16{
  margin-left:-4rem;
}

.-ml-20{
  margin-left:-5rem;
}

.-ml-24{
  margin-left:-6rem;
}

.-ml-28{
  margin-left:-7rem;
}

.-ml-32{
  margin-left:-8rem;
}

.-ml-36{
  margin-left:-9rem;
}

.-ml-40{
  margin-left:-10rem;
}

.-ml-44{
  margin-left:-11rem;
}

.-ml-48{
  margin-left:-12rem;
}

.-ml-52{
  margin-left:-13rem;
}

.-ml-56{
  margin-left:-14rem;
}

.-ml-60{
  margin-left:-15rem;
}

.-ml-64{
  margin-left:-16rem;
}

.-ml-72{
  margin-left:-18rem;
}

.-ml-80{
  margin-left:-20rem;
}

.-ml-96{
  margin-left:-24rem;
}

.-ml-px{
  margin-left:-1px;
}

.box-border{
  box-sizing:border-box;
}

.box-content{
  box-sizing:content-box;
}

.block{
  display:block;
}

.inline-block{
  display:inline-block;
}

.inline{
  display:inline;
}

.flex{
  display:flex;
}

.inline-flex{
  display:inline-flex;
}

.table{
  display:table;
}

.inline-table{
  display:inline-table;
}

.table-caption{
  display:table-caption;
}

.table-cell{
  display:table-cell;
}

.table-column{
  display:table-column;
}

.table-column-group{
  display:table-column-group;
}

.table-footer-group{
  display:table-footer-group;
}

.table-header-group{
  display:table-header-group;
}

.table-row-group{
  display:table-row-group;
}

.table-row{
  display:table-row;
}

.flow-root{
  display:flow-root;
}

.grid{
  display:grid;
}

.inline-grid{
  display:inline-grid;
}

.contents{
  display:contents;
}

.list-item{
  display:list-item;
}

.hidden{
  display:none;
}

.h-0{
  height:0px;
}

.h-1{
  height:0.25rem;
}

.h-2{
  height:0.5rem;
}

.h-3{
  height:0.75rem;
}

.h-4{
  height:1rem;
}

.h-5{
  height:1.25rem;
}

.h-6{
  height:1.5rem;
}

.h-7{
  height:1.75rem;
}

.h-8{
  height:2rem;
}

.h-9{
  height:2.25rem;
}

.h-10{
  height:2.5rem;
}

.h-11{
  height:2.75rem;
}

.h-12{
  height:3rem;
}

.h-14{
  height:3.5rem;
}

.h-16{
  height:4rem;
}

.h-20{
  height:5rem;
}

.h-22{
  height:5.5rem;
}

.h-24{
  height:6rem;
}

.h-26{
  height:6.5rem;
}

.h-28{
  height:7rem;
}

.h-32{
  height:8rem;
}

.h-36{
  height:9rem;
}

.h-40{
  height:10rem;
}

.h-44{
  height:11rem;
}

.h-48{
  height:12rem;
}

.h-52{
  height:13rem;
}

.h-56{
  height:14rem;
}

.h-60{
  height:15rem;
}

.h-64{
  height:16rem;
}

.h-68{
  height:17rem;
}

.h-72{
  height:18rem;
}

.h-80{
  height:20rem;
}

.h-82{
  height:20.5rem;
}

.h-96{
  height:24rem;
}

.h-auto{
  height:auto;
}

.h-px{
  height:1px;
}

.h-0\.5{
  height:0.125rem;
}

.h-2\.5{
  height:0.625rem;
}

.h-full{
  height:100%;
}

.h-screen{
  height:100vh;
}

.max-h-0{
  max-height:0;
}

.max-h-1{
  max-height:0.25rem;
}

.max-h-2{
  max-height:0.5rem;
}

.max-h-3{
  max-height:0.75rem;
}

.max-h-4{
  max-height:1rem;
}

.max-h-5{
  max-height:1.25rem;
}

.max-h-6{
  max-height:1.5rem;
}

.max-h-7{
  max-height:1.75rem;
}

.max-h-8{
  max-height:2rem;
}

.max-h-9{
  max-height:2.25rem;
}

.max-h-10{
  max-height:2.5rem;
}

.max-h-11{
  max-height:2.75rem;
}

.max-h-12{
  max-height:3rem;
}

.max-h-14{
  max-height:3.5rem;
}

.max-h-16{
  max-height:4rem;
}

.max-h-20{
  max-height:5rem;
}

.max-h-24{
  max-height:6rem;
}

.max-h-28{
  max-height:7rem;
}

.max-h-32{
  max-height:8rem;
}

.max-h-36{
  max-height:9rem;
}

.max-h-40{
  max-height:10rem;
}

.max-h-44{
  max-height:11rem;
}

.max-h-48{
  max-height:12rem;
}

.max-h-52{
  max-height:13rem;
}

.max-h-56{
  max-height:14rem;
}

.max-h-60{
  max-height:15rem;
}

.max-h-64{
  max-height:16rem;
}

.max-h-72{
  max-height:18rem;
}

.max-h-80{
  max-height:20rem;
}

.max-h-96{
  max-height:24rem;
}

.max-h-px{
  max-height:1px;
}

.max-h-full{
  max-height:100%;
}

.max-h-screen{
  max-height:100vh;
}

.min-h-0{
  min-height:0px;
}

.min-h-full{
  min-height:100%;
}

.min-h-screen{
  min-height:100vh;
}

.w-0{
  width:0px;
}

.w-1{
  width:0.25rem;
}

.w-2{
  width:0.5rem;
}

.w-3{
  width:0.75rem;
}

.w-4{
  width:1rem;
}

.w-5{
  width:1.25rem;
}

.w-6{
  width:1.5rem;
}

.w-7{
  width:1.75rem;
}

.w-8{
  width:2rem;
}

.w-9{
  width:2.25rem;
}

.w-10{
  width:2.5rem;
}

.w-11{
  width:2.75rem;
}

.w-12{
  width:3rem;
}

.w-14{
  width:3.5rem;
}

.w-16{
  width:4rem;
}

.w-20{
  width:5rem;
}

.w-22{
  width:5.5rem;
}

.w-24{
  width:6rem;
}

.w-25{
  width:6.25rem;
}

.w-26{
  width:6.5rem;
}

.w-28{
  width:7rem;
}

.w-32{
  width:8rem;
}

.w-36{
  width:9rem;
}

.w-40{
  width:10rem;
}

.w-44{
  width:11rem;
}

.w-48{
  width:12rem;
}

.w-52{
  width:13rem;
}

.w-56{
  width:14rem;
}

.w-60{
  width:15rem;
}

.w-64{
  width:16rem;
}

.w-68{
  width:17rem;
}

.w-70{
  width:17.5rem;
}

.w-72{
  width:18rem;
}

.w-80{
  width:20rem;
}

.w-96{
  width:24rem;
}

.w-auto{
  width:auto;
}

.w-px{
  width:1px;
}

.w-2\.5{
  width:0.625rem;
}

.w-1\/2{
  width:50%;
}

.w-2\/3{
  width:66.666667%;
}

.w-3\/5{
  width:60%;
}

.w-4\/5{
  width:80%;
}

.w-9\/12{
  width:75%;
}

.w-11\/12{
  width:91.666667%;
}

.w-full{
  width:100%;
}

.w-screen{
  width:100vw;
}

.w-min{
  width:-webkit-min-content;
  width:-moz-min-content;
  width:min-content;
}

.w-max{
  width:-webkit-max-content;
  width:-moz-max-content;
  width:max-content;
}

.min-w-0{
  min-width:0px;
}

.min-w-full{
  min-width:100%;
}

.min-w-min{
  min-width:-webkit-min-content;
  min-width:-moz-min-content;
  min-width:min-content;
}

.min-w-max{
  min-width:-webkit-max-content;
  min-width:-moz-max-content;
  min-width:max-content;
}

.min-w-42\.5{
  min-width:10.625rem;
}

.max-w-0{
  max-width:0rem;
}

.max-w-none{
  max-width:none;
}

.max-w-xs{
  max-width:20rem;
}

.max-w-sm{
  max-width:24rem;
}

.max-w-md{
  max-width:28rem;
}

.max-w-lg{
  max-width:32rem;
}

.max-w-xl{
  max-width:36rem;
}

.max-w-2xl{
  max-width:42rem;
}

.max-w-3xl{
  max-width:48rem;
}

.max-w-4xl{
  max-width:56rem;
}

.max-w-5xl{
  max-width:64rem;
}

.max-w-6xl{
  max-width:72rem;
}

.max-w-7xl{
  max-width:80rem;
}

.max-w-full{
  max-width:100%;
}

.max-w-min{
  max-width:-webkit-min-content;
  max-width:-moz-min-content;
  max-width:min-content;
}

.max-w-max{
  max-width:-webkit-max-content;
  max-width:-moz-max-content;
  max-width:max-content;
}

.max-w-prose{
  max-width:65ch;
}

.max-w-screen-sm{
  max-width:600px;
}

.max-w-screen-md{
  max-width:1024px;
}

.max-w-screen-lg{
  max-width:1366px;
}

.max-w-screen-xl{
  max-width:1448px;
}

.flex-1{
  flex:1 1 0%;
}

.flex-auto{
  flex:1 1 auto;
}

.flex-initial{
  flex:0 1 auto;
}

.flex-none{
  flex:none;
}

.flex-shrink-0{
  flex-shrink:0;
}

.flex-shrink{
  flex-shrink:1;
}

.flex-grow-0{
  flex-grow:0;
}

.flex-grow{
  flex-grow:1;
}

.table-auto{
  table-layout:auto;
}

.table-fixed{
  table-layout:fixed;
}

.border-collapse{
  border-collapse:collapse;
}

.border-separate{
  border-collapse:separate;
}

.origin-center{
  transform-origin:center;
}

.origin-top{
  transform-origin:top;
}

.origin-top-right{
  transform-origin:top right;
}

.origin-right{
  transform-origin:right;
}

.origin-bottom-right{
  transform-origin:bottom right;
}

.origin-bottom{
  transform-origin:bottom;
}

.origin-bottom-left{
  transform-origin:bottom left;
}

.origin-left{
  transform-origin:left;
}

.origin-top-left{
  transform-origin:top left;
}

.transform{
  --tw-translate-x:0;
  --tw-translate-y:0;
  --tw-rotate:0;
  --tw-skew-x:0;
  --tw-skew-y:0;
  --tw-scale-x:1;
  --tw-scale-y:1;
  transform:translateX(var(--tw-translate-x)) translateY(var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.transform-gpu{
  --tw-translate-x:0;
  --tw-translate-y:0;
  --tw-rotate:0;
  --tw-skew-x:0;
  --tw-skew-y:0;
  --tw-scale-x:1;
  --tw-scale-y:1;
  transform:translate3d(var(--tw-translate-x), var(--tw-translate-y), 0) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.transform-none{
  transform:none;
}

.translate-x-0{
  --tw-translate-x:0px;
}

.translate-x-1{
  --tw-translate-x:0.25rem;
}

.translate-x-2{
  --tw-translate-x:0.5rem;
}

.translate-x-3{
  --tw-translate-x:0.75rem;
}

.translate-x-4{
  --tw-translate-x:1rem;
}

.translate-x-5{
  --tw-translate-x:1.25rem;
}

.translate-x-6{
  --tw-translate-x:1.5rem;
}

.translate-x-7{
  --tw-translate-x:1.75rem;
}

.translate-x-8{
  --tw-translate-x:2rem;
}

.translate-x-9{
  --tw-translate-x:2.25rem;
}

.translate-x-10{
  --tw-translate-x:2.5rem;
}

.translate-x-11{
  --tw-translate-x:2.75rem;
}

.translate-x-12{
  --tw-translate-x:3rem;
}

.translate-x-14{
  --tw-translate-x:3.5rem;
}

.translate-x-16{
  --tw-translate-x:4rem;
}

.translate-x-20{
  --tw-translate-x:5rem;
}

.translate-x-24{
  --tw-translate-x:6rem;
}

.translate-x-28{
  --tw-translate-x:7rem;
}

.translate-x-32{
  --tw-translate-x:8rem;
}

.translate-x-36{
  --tw-translate-x:9rem;
}

.translate-x-40{
  --tw-translate-x:10rem;
}

.translate-x-44{
  --tw-translate-x:11rem;
}

.translate-x-48{
  --tw-translate-x:12rem;
}

.translate-x-52{
  --tw-translate-x:13rem;
}

.translate-x-56{
  --tw-translate-x:14rem;
}

.translate-x-60{
  --tw-translate-x:15rem;
}

.translate-x-64{
  --tw-translate-x:16rem;
}

.translate-x-72{
  --tw-translate-x:18rem;
}

.translate-x-80{
  --tw-translate-x:20rem;
}

.translate-x-96{
  --tw-translate-x:24rem;
}

.translate-x-px{
  --tw-translate-x:1px;
}

.-translate-x-0{
  --tw-translate-x:0px;
}

.-translate-x-1{
  --tw-translate-x:-0.25rem;
}

.-translate-x-2{
  --tw-translate-x:-0.5rem;
}

.-translate-x-3{
  --tw-translate-x:-0.75rem;
}

.-translate-x-4{
  --tw-translate-x:-1rem;
}

.-translate-x-5{
  --tw-translate-x:-1.25rem;
}

.-translate-x-6{
  --tw-translate-x:-1.5rem;
}

.-translate-x-7{
  --tw-translate-x:-1.75rem;
}

.-translate-x-8{
  --tw-translate-x:-2rem;
}

.-translate-x-9{
  --tw-translate-x:-2.25rem;
}

.-translate-x-10{
  --tw-translate-x:-2.5rem;
}

.-translate-x-11{
  --tw-translate-x:-2.75rem;
}

.-translate-x-12{
  --tw-translate-x:-3rem;
}

.-translate-x-14{
  --tw-translate-x:-3.5rem;
}

.-translate-x-16{
  --tw-translate-x:-4rem;
}

.-translate-x-20{
  --tw-translate-x:-5rem;
}

.-translate-x-24{
  --tw-translate-x:-6rem;
}

.-translate-x-28{
  --tw-translate-x:-7rem;
}

.-translate-x-32{
  --tw-translate-x:-8rem;
}

.-translate-x-36{
  --tw-translate-x:-9rem;
}

.-translate-x-40{
  --tw-translate-x:-10rem;
}

.-translate-x-44{
  --tw-translate-x:-11rem;
}

.-translate-x-48{
  --tw-translate-x:-12rem;
}

.-translate-x-52{
  --tw-translate-x:-13rem;
}

.-translate-x-56{
  --tw-translate-x:-14rem;
}

.-translate-x-60{
  --tw-translate-x:-15rem;
}

.-translate-x-64{
  --tw-translate-x:-16rem;
}

.-translate-x-72{
  --tw-translate-x:-18rem;
}

.-translate-x-80{
  --tw-translate-x:-20rem;
}

.-translate-x-96{
  --tw-translate-x:-24rem;
}

.-translate-x-px{
  --tw-translate-x:-1px;
}

.translate-x-full{
  --tw-translate-x:100%;
}

.-translate-x-full{
  --tw-translate-x:-100%;
}

.translate-y-0{
  --tw-translate-y:0px;
}

.translate-y-1{
  --tw-translate-y:0.25rem;
}

.translate-y-2{
  --tw-translate-y:0.5rem;
}

.translate-y-3{
  --tw-translate-y:0.75rem;
}

.translate-y-4{
  --tw-translate-y:1rem;
}

.translate-y-5{
  --tw-translate-y:1.25rem;
}

.translate-y-6{
  --tw-translate-y:1.5rem;
}

.translate-y-7{
  --tw-translate-y:1.75rem;
}

.translate-y-8{
  --tw-translate-y:2rem;
}

.translate-y-9{
  --tw-translate-y:2.25rem;
}

.translate-y-10{
  --tw-translate-y:2.5rem;
}

.translate-y-11{
  --tw-translate-y:2.75rem;
}

.translate-y-12{
  --tw-translate-y:3rem;
}

.translate-y-14{
  --tw-translate-y:3.5rem;
}

.translate-y-16{
  --tw-translate-y:4rem;
}

.translate-y-20{
  --tw-translate-y:5rem;
}

.translate-y-24{
  --tw-translate-y:6rem;
}

.translate-y-28{
  --tw-translate-y:7rem;
}

.translate-y-32{
  --tw-translate-y:8rem;
}

.translate-y-36{
  --tw-translate-y:9rem;
}

.translate-y-40{
  --tw-translate-y:10rem;
}

.translate-y-44{
  --tw-translate-y:11rem;
}

.translate-y-48{
  --tw-translate-y:12rem;
}

.translate-y-52{
  --tw-translate-y:13rem;
}

.translate-y-56{
  --tw-translate-y:14rem;
}

.translate-y-60{
  --tw-translate-y:15rem;
}

.translate-y-64{
  --tw-translate-y:16rem;
}

.translate-y-72{
  --tw-translate-y:18rem;
}

.translate-y-80{
  --tw-translate-y:20rem;
}

.translate-y-96{
  --tw-translate-y:24rem;
}

.translate-y-px{
  --tw-translate-y:1px;
}

.-translate-y-0{
  --tw-translate-y:0px;
}

.-translate-y-1{
  --tw-translate-y:-0.25rem;
}

.-translate-y-2{
  --tw-translate-y:-0.5rem;
}

.-translate-y-3{
  --tw-translate-y:-0.75rem;
}

.-translate-y-4{
  --tw-translate-y:-1rem;
}

.-translate-y-5{
  --tw-translate-y:-1.25rem;
}

.-translate-y-6{
  --tw-translate-y:-1.5rem;
}

.-translate-y-7{
  --tw-translate-y:-1.75rem;
}

.-translate-y-8{
  --tw-translate-y:-2rem;
}

.-translate-y-9{
  --tw-translate-y:-2.25rem;
}

.-translate-y-10{
  --tw-translate-y:-2.5rem;
}

.-translate-y-11{
  --tw-translate-y:-2.75rem;
}

.-translate-y-12{
  --tw-translate-y:-3rem;
}

.-translate-y-14{
  --tw-translate-y:-3.5rem;
}

.-translate-y-16{
  --tw-translate-y:-4rem;
}

.-translate-y-20{
  --tw-translate-y:-5rem;
}

.-translate-y-24{
  --tw-translate-y:-6rem;
}

.-translate-y-28{
  --tw-translate-y:-7rem;
}

.-translate-y-32{
  --tw-translate-y:-8rem;
}

.-translate-y-36{
  --tw-translate-y:-9rem;
}

.-translate-y-40{
  --tw-translate-y:-10rem;
}

.-translate-y-44{
  --tw-translate-y:-11rem;
}

.-translate-y-48{
  --tw-translate-y:-12rem;
}

.-translate-y-52{
  --tw-translate-y:-13rem;
}

.-translate-y-56{
  --tw-translate-y:-14rem;
}

.-translate-y-60{
  --tw-translate-y:-15rem;
}

.-translate-y-64{
  --tw-translate-y:-16rem;
}

.-translate-y-72{
  --tw-translate-y:-18rem;
}

.-translate-y-80{
  --tw-translate-y:-20rem;
}

.-translate-y-96{
  --tw-translate-y:-24rem;
}

.-translate-y-px{
  --tw-translate-y:-1px;
}

.translate-y-full{
  --tw-translate-y:100%;
}

.-translate-y-full{
  --tw-translate-y:-100%;
}

.rotate-0{
  --tw-rotate:0deg;
}

.rotate-1{
  --tw-rotate:1deg;
}

.rotate-2{
  --tw-rotate:2deg;
}

.rotate-3{
  --tw-rotate:3deg;
}

.rotate-6{
  --tw-rotate:6deg;
}

.rotate-12{
  --tw-rotate:12deg;
}

.rotate-45{
  --tw-rotate:45deg;
}

.rotate-90{
  --tw-rotate:90deg;
}

.rotate-180{
  --tw-rotate:180deg;
}

.-rotate-180{
  --tw-rotate:-180deg;
}

.-rotate-90{
  --tw-rotate:-90deg;
}

.-rotate-45{
  --tw-rotate:-45deg;
}

.-rotate-12{
  --tw-rotate:-12deg;
}

.-rotate-6{
  --tw-rotate:-6deg;
}

.-rotate-3{
  --tw-rotate:-3deg;
}

.-rotate-2{
  --tw-rotate:-2deg;
}

.-rotate-1{
  --tw-rotate:-1deg;
}

.skew-x-0{
  --tw-skew-x:0deg;
}

.skew-x-1{
  --tw-skew-x:1deg;
}

.skew-x-2{
  --tw-skew-x:2deg;
}

.skew-x-3{
  --tw-skew-x:3deg;
}

.skew-x-6{
  --tw-skew-x:6deg;
}

.skew-x-12{
  --tw-skew-x:12deg;
}

.-skew-x-12{
  --tw-skew-x:-12deg;
}

.-skew-x-6{
  --tw-skew-x:-6deg;
}

.-skew-x-3{
  --tw-skew-x:-3deg;
}

.-skew-x-2{
  --tw-skew-x:-2deg;
}

.-skew-x-1{
  --tw-skew-x:-1deg;
}

.skew-y-0{
  --tw-skew-y:0deg;
}

.skew-y-1{
  --tw-skew-y:1deg;
}

.skew-y-2{
  --tw-skew-y:2deg;
}

.skew-y-3{
  --tw-skew-y:3deg;
}

.skew-y-6{
  --tw-skew-y:6deg;
}

.skew-y-12{
  --tw-skew-y:12deg;
}

.-skew-y-12{
  --tw-skew-y:-12deg;
}

.-skew-y-6{
  --tw-skew-y:-6deg;
}

.-skew-y-3{
  --tw-skew-y:-3deg;
}

.-skew-y-2{
  --tw-skew-y:-2deg;
}

.-skew-y-1{
  --tw-skew-y:-1deg;
}

.scale-0{
  --tw-scale-x:0;
  --tw-scale-y:0;
}

.scale-50{
  --tw-scale-x:.5;
  --tw-scale-y:.5;
}

.scale-75{
  --tw-scale-x:.75;
  --tw-scale-y:.75;
}

.scale-90{
  --tw-scale-x:.9;
  --tw-scale-y:.9;
}

.scale-95{
  --tw-scale-x:.95;
  --tw-scale-y:.95;
}

.scale-100{
  --tw-scale-x:1;
  --tw-scale-y:1;
}

.scale-105{
  --tw-scale-x:1.05;
  --tw-scale-y:1.05;
}

.scale-110{
  --tw-scale-x:1.1;
  --tw-scale-y:1.1;
}

.scale-125{
  --tw-scale-x:1.25;
  --tw-scale-y:1.25;
}

.scale-150{
  --tw-scale-x:1.5;
  --tw-scale-y:1.5;
}

.scale-x-0{
  --tw-scale-x:0;
}

.scale-x-50{
  --tw-scale-x:.5;
}

.scale-x-75{
  --tw-scale-x:.75;
}

.scale-x-90{
  --tw-scale-x:.9;
}

.scale-x-95{
  --tw-scale-x:.95;
}

.scale-x-100{
  --tw-scale-x:1;
}

.scale-x-105{
  --tw-scale-x:1.05;
}

.scale-x-110{
  --tw-scale-x:1.1;
}

.scale-x-125{
  --tw-scale-x:1.25;
}

.scale-x-150{
  --tw-scale-x:1.5;
}

.scale-y-0{
  --tw-scale-y:0;
}

.scale-y-50{
  --tw-scale-y:.5;
}

.scale-y-75{
  --tw-scale-y:.75;
}

.scale-y-90{
  --tw-scale-y:.9;
}

.scale-y-95{
  --tw-scale-y:.95;
}

.scale-y-100{
  --tw-scale-y:1;
}

.scale-y-105{
  --tw-scale-y:1.05;
}

.scale-y-110{
  --tw-scale-y:1.1;
}

.scale-y-125{
  --tw-scale-y:1.25;
}

.scale-y-150{
  --tw-scale-y:1.5;
}

@-webkit-keyframes spin{
  to{
    transform:rotate(360deg);
  }
}

@keyframes spin{
  to{
    transform:rotate(360deg);
  }
}

@-webkit-keyframes ping{
  75%, 100%{
    transform:scale(2);
    opacity:0;
  }
}

@keyframes ping{
  75%, 100%{
    transform:scale(2);
    opacity:0;
  }
}

@-webkit-keyframes pulse{
  50%{
    opacity:.5;
  }
}

@keyframes pulse{
  50%{
    opacity:.5;
  }
}

@-webkit-keyframes bounce{
  0%, 100%{
    transform:translateY(-25%);
    -webkit-animation-timing-function:cubic-bezier(0.8,0,1,1);
            animation-timing-function:cubic-bezier(0.8,0,1,1);
  }

  50%{
    transform:none;
    -webkit-animation-timing-function:cubic-bezier(0,0,0.2,1);
            animation-timing-function:cubic-bezier(0,0,0.2,1);
  }
}

@keyframes bounce{
  0%, 100%{
    transform:translateY(-25%);
    -webkit-animation-timing-function:cubic-bezier(0.8,0,1,1);
            animation-timing-function:cubic-bezier(0.8,0,1,1);
  }

  50%{
    transform:none;
    -webkit-animation-timing-function:cubic-bezier(0,0,0.2,1);
            animation-timing-function:cubic-bezier(0,0,0.2,1);
  }
}

.animate-none{
  -webkit-animation:none;
          animation:none;
}

.animate-spin{
  -webkit-animation:spin 1s linear infinite;
          animation:spin 1s linear infinite;
}

.animate-ping{
  -webkit-animation:ping 1s cubic-bezier(0, 0, 0.2, 1) infinite;
          animation:ping 1s cubic-bezier(0, 0, 0.2, 1) infinite;
}

.animate-pulse{
  -webkit-animation:pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
          animation:pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
}

.animate-bounce{
  -webkit-animation:bounce 1s infinite;
          animation:bounce 1s infinite;
}

.cursor-auto{
  cursor:auto;
}

.cursor-default{
  cursor:default;
}

.cursor-pointer{
  cursor:pointer;
}

.cursor-wait{
  cursor:wait;
}

.cursor-text{
  cursor:text;
}

.cursor-move{
  cursor:move;
}

.cursor-help{
  cursor:help;
}

.cursor-not-allowed{
  cursor:not-allowed;
}

.select-none{
  -webkit-user-select:none;
     -moz-user-select:none;
      -ms-user-select:none;
          user-select:none;
}

.select-text{
  -webkit-user-select:text;
     -moz-user-select:text;
      -ms-user-select:text;
          user-select:text;
}

.select-all{
  -webkit-user-select:all;
     -moz-user-select:all;
          user-select:all;
}

.select-auto{
  -webkit-user-select:auto;
     -moz-user-select:auto;
      -ms-user-select:auto;
          user-select:auto;
}

.resize-none{
  resize:none;
}

.resize-y{
  resize:vertical;
}

.resize-x{
  resize:horizontal;
}

.resize{
  resize:both;
}

.list-inside{
  list-style-position:inside;
}

.list-outside{
  list-style-position:outside;
}

.list-none{
  list-style-type:none;
}

.list-disc{
  list-style-type:disc;
}

.list-decimal{
  list-style-type:decimal;
}

.appearance-none{
  -webkit-appearance:none;
     -moz-appearance:none;
          appearance:none;
}

.auto-cols-auto{
  grid-auto-columns:auto;
}

.auto-cols-min{
  grid-auto-columns:-webkit-min-content;
  grid-auto-columns:min-content;
}

.auto-cols-max{
  grid-auto-columns:-webkit-max-content;
  grid-auto-columns:max-content;
}

.auto-cols-fr{
  grid-auto-columns:minmax(0, 1fr);
}

.grid-flow-row{
  grid-auto-flow:row;
}

.grid-flow-col{
  grid-auto-flow:column;
}

.grid-flow-row-dense{
  grid-auto-flow:row dense;
}

.grid-flow-col-dense{
  grid-auto-flow:column dense;
}

.auto-rows-auto{
  grid-auto-rows:auto;
}

.auto-rows-min{
  grid-auto-rows:-webkit-min-content;
  grid-auto-rows:min-content;
}

.auto-rows-max{
  grid-auto-rows:-webkit-max-content;
  grid-auto-rows:max-content;
}

.auto-rows-fr{
  grid-auto-rows:minmax(0, 1fr);
}

.grid-cols-1{
  grid-template-columns:repeat(1, minmax(0, 1fr));
}

.grid-cols-2{
  grid-template-columns:repeat(2, minmax(0, 1fr));
}

.grid-cols-3{
  grid-template-columns:repeat(3, minmax(0, 1fr));
}

.grid-cols-4{
  grid-template-columns:repeat(4, minmax(0, 1fr));
}

.grid-cols-5{
  grid-template-columns:repeat(5, minmax(0, 1fr));
}

.grid-cols-6{
  grid-template-columns:repeat(6, minmax(0, 1fr));
}

.grid-cols-7{
  grid-template-columns:repeat(7, minmax(0, 1fr));
}

.grid-cols-8{
  grid-template-columns:repeat(8, minmax(0, 1fr));
}

.grid-cols-9{
  grid-template-columns:repeat(9, minmax(0, 1fr));
}

.grid-cols-10{
  grid-template-columns:repeat(10, minmax(0, 1fr));
}

.grid-cols-11{
  grid-template-columns:repeat(11, minmax(0, 1fr));
}

.grid-cols-12{
  grid-template-columns:repeat(12, minmax(0, 1fr));
}

.grid-cols-none{
  grid-template-columns:none;
}

.grid-rows-1{
  grid-template-rows:repeat(1, minmax(0, 1fr));
}

.grid-rows-2{
  grid-template-rows:repeat(2, minmax(0, 1fr));
}

.grid-rows-3{
  grid-template-rows:repeat(3, minmax(0, 1fr));
}

.grid-rows-4{
  grid-template-rows:repeat(4, minmax(0, 1fr));
}

.grid-rows-5{
  grid-template-rows:repeat(5, minmax(0, 1fr));
}

.grid-rows-6{
  grid-template-rows:repeat(6, minmax(0, 1fr));
}

.grid-rows-none{
  grid-template-rows:none;
}

.flex-row{
  flex-direction:row;
}

.flex-row-reverse{
  flex-direction:row-reverse;
}

.flex-col{
  flex-direction:column;
}

.flex-col-reverse{
  flex-direction:column-reverse;
}

.flex-wrap{
  flex-wrap:wrap;
}

.flex-wrap-reverse{
  flex-wrap:wrap-reverse;
}

.flex-nowrap{
  flex-wrap:nowrap;
}

.place-content-center{
  place-content:center;
}

.place-content-start{
  place-content:start;
}

.place-content-end{
  place-content:end;
}

.place-content-between{
  place-content:space-between;
}

.place-content-around{
  place-content:space-around;
}

.place-content-evenly{
  place-content:space-evenly;
}

.place-content-stretch{
  place-content:stretch;
}

.place-items-start{
  place-items:start;
}

.place-items-end{
  place-items:end;
}

.place-items-center{
  place-items:center;
}

.place-items-stretch{
  place-items:stretch;
}

.content-center{
  align-content:center;
}

.content-start{
  align-content:flex-start;
}

.content-end{
  align-content:flex-end;
}

.content-between{
  align-content:space-between;
}

.content-around{
  align-content:space-around;
}

.content-evenly{
  align-content:space-evenly;
}

.items-start{
  align-items:flex-start;
}

.items-end{
  align-items:flex-end;
}

.items-center{
  align-items:center;
}

.items-baseline{
  align-items:baseline;
}

.items-stretch{
  align-items:stretch;
}

.justify-start{
  justify-content:flex-start;
}

.justify-end{
  justify-content:flex-end;
}

.justify-center{
  justify-content:center;
}

.justify-between{
  justify-content:space-between;
}

.justify-around{
  justify-content:space-around;
}

.justify-evenly{
  justify-content:space-evenly;
}

.justify-items-start{
  justify-items:start;
}

.justify-items-end{
  justify-items:end;
}

.justify-items-center{
  justify-items:center;
}

.justify-items-stretch{
  justify-items:stretch;
}

.gap-0{
  gap:0px;
}

.gap-1{
  gap:0.25rem;
}

.gap-2{
  gap:0.5rem;
}

.gap-3{
  gap:0.75rem;
}

.gap-4{
  gap:1rem;
}

.gap-5{
  gap:1.25rem;
}

.gap-6{
  gap:1.5rem;
}

.gap-7{
  gap:1.75rem;
}

.gap-8{
  gap:2rem;
}

.gap-9{
  gap:2.25rem;
}

.gap-10{
  gap:2.5rem;
}

.gap-11{
  gap:2.75rem;
}

.gap-12{
  gap:3rem;
}

.gap-14{
  gap:3.5rem;
}

.gap-16{
  gap:4rem;
}

.gap-20{
  gap:5rem;
}

.gap-24{
  gap:6rem;
}

.gap-28{
  gap:7rem;
}

.gap-32{
  gap:8rem;
}

.gap-36{
  gap:9rem;
}

.gap-40{
  gap:10rem;
}

.gap-44{
  gap:11rem;
}

.gap-48{
  gap:12rem;
}

.gap-52{
  gap:13rem;
}

.gap-56{
  gap:14rem;
}

.gap-60{
  gap:15rem;
}

.gap-64{
  gap:16rem;
}

.gap-72{
  gap:18rem;
}

.gap-80{
  gap:20rem;
}

.gap-96{
  gap:24rem;
}

.gap-px{
  gap:1px;
}

.gap-x-0{
  -moz-column-gap:0px;
       column-gap:0px;
}

.gap-x-1{
  -moz-column-gap:0.25rem;
       column-gap:0.25rem;
}

.gap-x-2{
  -moz-column-gap:0.5rem;
       column-gap:0.5rem;
}

.gap-x-3{
  -moz-column-gap:0.75rem;
       column-gap:0.75rem;
}

.gap-x-4{
  -moz-column-gap:1rem;
       column-gap:1rem;
}

.gap-x-5{
  -moz-column-gap:1.25rem;
       column-gap:1.25rem;
}

.gap-x-6{
  -moz-column-gap:1.5rem;
       column-gap:1.5rem;
}

.gap-x-7{
  -moz-column-gap:1.75rem;
       column-gap:1.75rem;
}

.gap-x-8{
  -moz-column-gap:2rem;
       column-gap:2rem;
}

.gap-x-9{
  -moz-column-gap:2.25rem;
       column-gap:2.25rem;
}

.gap-x-10{
  -moz-column-gap:2.5rem;
       column-gap:2.5rem;
}

.gap-x-11{
  -moz-column-gap:2.75rem;
       column-gap:2.75rem;
}

.gap-x-12{
  -moz-column-gap:3rem;
       column-gap:3rem;
}

.gap-x-14{
  -moz-column-gap:3.5rem;
       column-gap:3.5rem;
}

.gap-x-16{
  -moz-column-gap:4rem;
       column-gap:4rem;
}

.gap-x-20{
  -moz-column-gap:5rem;
       column-gap:5rem;
}

.gap-x-24{
  -moz-column-gap:6rem;
       column-gap:6rem;
}

.gap-x-28{
  -moz-column-gap:7rem;
       column-gap:7rem;
}

.gap-x-32{
  -moz-column-gap:8rem;
       column-gap:8rem;
}

.gap-x-36{
  -moz-column-gap:9rem;
       column-gap:9rem;
}

.gap-x-40{
  -moz-column-gap:10rem;
       column-gap:10rem;
}

.gap-x-44{
  -moz-column-gap:11rem;
       column-gap:11rem;
}

.gap-x-48{
  -moz-column-gap:12rem;
       column-gap:12rem;
}

.gap-x-52{
  -moz-column-gap:13rem;
       column-gap:13rem;
}

.gap-x-56{
  -moz-column-gap:14rem;
       column-gap:14rem;
}

.gap-x-60{
  -moz-column-gap:15rem;
       column-gap:15rem;
}

.gap-x-64{
  -moz-column-gap:16rem;
       column-gap:16rem;
}

.gap-x-72{
  -moz-column-gap:18rem;
       column-gap:18rem;
}

.gap-x-80{
  -moz-column-gap:20rem;
       column-gap:20rem;
}

.gap-x-96{
  -moz-column-gap:24rem;
       column-gap:24rem;
}

.gap-x-px{
  -moz-column-gap:1px;
       column-gap:1px;
}

.gap-y-0{
  row-gap:0px;
}

.gap-y-1{
  row-gap:0.25rem;
}

.gap-y-2{
  row-gap:0.5rem;
}

.gap-y-3{
  row-gap:0.75rem;
}

.gap-y-4{
  row-gap:1rem;
}

.gap-y-5{
  row-gap:1.25rem;
}

.gap-y-6{
  row-gap:1.5rem;
}

.gap-y-7{
  row-gap:1.75rem;
}

.gap-y-8{
  row-gap:2rem;
}

.gap-y-9{
  row-gap:2.25rem;
}

.gap-y-10{
  row-gap:2.5rem;
}

.gap-y-11{
  row-gap:2.75rem;
}

.gap-y-12{
  row-gap:3rem;
}

.gap-y-14{
  row-gap:3.5rem;
}

.gap-y-16{
  row-gap:4rem;
}

.gap-y-20{
  row-gap:5rem;
}

.gap-y-24{
  row-gap:6rem;
}

.gap-y-28{
  row-gap:7rem;
}

.gap-y-32{
  row-gap:8rem;
}

.gap-y-36{
  row-gap:9rem;
}

.gap-y-40{
  row-gap:10rem;
}

.gap-y-44{
  row-gap:11rem;
}

.gap-y-48{
  row-gap:12rem;
}

.gap-y-52{
  row-gap:13rem;
}

.gap-y-56{
  row-gap:14rem;
}

.gap-y-60{
  row-gap:15rem;
}

.gap-y-64{
  row-gap:16rem;
}

.gap-y-72{
  row-gap:18rem;
}

.gap-y-80{
  row-gap:20rem;
}

.gap-y-96{
  row-gap:24rem;
}

.gap-y-px{
  row-gap:1px;
}

.space-x-0 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(0px * var(--tw-space-x-reverse));
  margin-left:calc(0px * calc(1 - var(--tw-space-x-reverse)));
}

.space-x-1 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(0.25rem * var(--tw-space-x-reverse));
  margin-left:calc(0.25rem * calc(1 - var(--tw-space-x-reverse)));
}

.space-x-2 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(0.5rem * var(--tw-space-x-reverse));
  margin-left:calc(0.5rem * calc(1 - var(--tw-space-x-reverse)));
}

.space-x-3 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(0.75rem * var(--tw-space-x-reverse));
  margin-left:calc(0.75rem * calc(1 - var(--tw-space-x-reverse)));
}

.space-x-4 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(1rem * var(--tw-space-x-reverse));
  margin-left:calc(1rem * calc(1 - var(--tw-space-x-reverse)));
}

.space-x-5 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(1.25rem * var(--tw-space-x-reverse));
  margin-left:calc(1.25rem * calc(1 - var(--tw-space-x-reverse)));
}

.space-x-6 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(1.5rem * var(--tw-space-x-reverse));
  margin-left:calc(1.5rem * calc(1 - var(--tw-space-x-reverse)));
}

.space-x-7 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(1.75rem * var(--tw-space-x-reverse));
  margin-left:calc(1.75rem * calc(1 - var(--tw-space-x-reverse)));
}

.space-x-8 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(2rem * var(--tw-space-x-reverse));
  margin-left:calc(2rem * calc(1 - var(--tw-space-x-reverse)));
}

.space-x-9 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(2.25rem * var(--tw-space-x-reverse));
  margin-left:calc(2.25rem * calc(1 - var(--tw-space-x-reverse)));
}

.space-x-10 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(2.5rem * var(--tw-space-x-reverse));
  margin-left:calc(2.5rem * calc(1 - var(--tw-space-x-reverse)));
}

.space-x-11 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(2.75rem * var(--tw-space-x-reverse));
  margin-left:calc(2.75rem * calc(1 - var(--tw-space-x-reverse)));
}

.space-x-12 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(3rem * var(--tw-space-x-reverse));
  margin-left:calc(3rem * calc(1 - var(--tw-space-x-reverse)));
}

.space-x-14 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(3.5rem * var(--tw-space-x-reverse));
  margin-left:calc(3.5rem * calc(1 - var(--tw-space-x-reverse)));
}

.space-x-16 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(4rem * var(--tw-space-x-reverse));
  margin-left:calc(4rem * calc(1 - var(--tw-space-x-reverse)));
}

.space-x-20 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(5rem * var(--tw-space-x-reverse));
  margin-left:calc(5rem * calc(1 - var(--tw-space-x-reverse)));
}

.space-x-24 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(6rem * var(--tw-space-x-reverse));
  margin-left:calc(6rem * calc(1 - var(--tw-space-x-reverse)));
}

.space-x-28 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(7rem * var(--tw-space-x-reverse));
  margin-left:calc(7rem * calc(1 - var(--tw-space-x-reverse)));
}

.space-x-32 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(8rem * var(--tw-space-x-reverse));
  margin-left:calc(8rem * calc(1 - var(--tw-space-x-reverse)));
}

.space-x-36 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(9rem * var(--tw-space-x-reverse));
  margin-left:calc(9rem * calc(1 - var(--tw-space-x-reverse)));
}

.space-x-40 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(10rem * var(--tw-space-x-reverse));
  margin-left:calc(10rem * calc(1 - var(--tw-space-x-reverse)));
}

.space-x-44 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(11rem * var(--tw-space-x-reverse));
  margin-left:calc(11rem * calc(1 - var(--tw-space-x-reverse)));
}

.space-x-48 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(12rem * var(--tw-space-x-reverse));
  margin-left:calc(12rem * calc(1 - var(--tw-space-x-reverse)));
}

.space-x-52 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(13rem * var(--tw-space-x-reverse));
  margin-left:calc(13rem * calc(1 - var(--tw-space-x-reverse)));
}

.space-x-56 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(14rem * var(--tw-space-x-reverse));
  margin-left:calc(14rem * calc(1 - var(--tw-space-x-reverse)));
}

.space-x-60 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(15rem * var(--tw-space-x-reverse));
  margin-left:calc(15rem * calc(1 - var(--tw-space-x-reverse)));
}

.space-x-64 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(16rem * var(--tw-space-x-reverse));
  margin-left:calc(16rem * calc(1 - var(--tw-space-x-reverse)));
}

.space-x-72 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(18rem * var(--tw-space-x-reverse));
  margin-left:calc(18rem * calc(1 - var(--tw-space-x-reverse)));
}

.space-x-80 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(20rem * var(--tw-space-x-reverse));
  margin-left:calc(20rem * calc(1 - var(--tw-space-x-reverse)));
}

.space-x-96 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(24rem * var(--tw-space-x-reverse));
  margin-left:calc(24rem * calc(1 - var(--tw-space-x-reverse)));
}

.space-x-px > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(1px * var(--tw-space-x-reverse));
  margin-left:calc(1px * calc(1 - var(--tw-space-x-reverse)));
}

.-space-x-0 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(0px * var(--tw-space-x-reverse));
  margin-left:calc(0px * calc(1 - var(--tw-space-x-reverse)));
}

.-space-x-1 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(-0.25rem * var(--tw-space-x-reverse));
  margin-left:calc(-0.25rem * calc(1 - var(--tw-space-x-reverse)));
}

.-space-x-2 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(-0.5rem * var(--tw-space-x-reverse));
  margin-left:calc(-0.5rem * calc(1 - var(--tw-space-x-reverse)));
}

.-space-x-3 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(-0.75rem * var(--tw-space-x-reverse));
  margin-left:calc(-0.75rem * calc(1 - var(--tw-space-x-reverse)));
}

.-space-x-4 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(-1rem * var(--tw-space-x-reverse));
  margin-left:calc(-1rem * calc(1 - var(--tw-space-x-reverse)));
}

.-space-x-5 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(-1.25rem * var(--tw-space-x-reverse));
  margin-left:calc(-1.25rem * calc(1 - var(--tw-space-x-reverse)));
}

.-space-x-6 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(-1.5rem * var(--tw-space-x-reverse));
  margin-left:calc(-1.5rem * calc(1 - var(--tw-space-x-reverse)));
}

.-space-x-7 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(-1.75rem * var(--tw-space-x-reverse));
  margin-left:calc(-1.75rem * calc(1 - var(--tw-space-x-reverse)));
}

.-space-x-8 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(-2rem * var(--tw-space-x-reverse));
  margin-left:calc(-2rem * calc(1 - var(--tw-space-x-reverse)));
}

.-space-x-9 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(-2.25rem * var(--tw-space-x-reverse));
  margin-left:calc(-2.25rem * calc(1 - var(--tw-space-x-reverse)));
}

.-space-x-10 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(-2.5rem * var(--tw-space-x-reverse));
  margin-left:calc(-2.5rem * calc(1 - var(--tw-space-x-reverse)));
}

.-space-x-11 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(-2.75rem * var(--tw-space-x-reverse));
  margin-left:calc(-2.75rem * calc(1 - var(--tw-space-x-reverse)));
}

.-space-x-12 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(-3rem * var(--tw-space-x-reverse));
  margin-left:calc(-3rem * calc(1 - var(--tw-space-x-reverse)));
}

.-space-x-14 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(-3.5rem * var(--tw-space-x-reverse));
  margin-left:calc(-3.5rem * calc(1 - var(--tw-space-x-reverse)));
}

.-space-x-16 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(-4rem * var(--tw-space-x-reverse));
  margin-left:calc(-4rem * calc(1 - var(--tw-space-x-reverse)));
}

.-space-x-20 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(-5rem * var(--tw-space-x-reverse));
  margin-left:calc(-5rem * calc(1 - var(--tw-space-x-reverse)));
}

.-space-x-24 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(-6rem * var(--tw-space-x-reverse));
  margin-left:calc(-6rem * calc(1 - var(--tw-space-x-reverse)));
}

.-space-x-28 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(-7rem * var(--tw-space-x-reverse));
  margin-left:calc(-7rem * calc(1 - var(--tw-space-x-reverse)));
}

.-space-x-32 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(-8rem * var(--tw-space-x-reverse));
  margin-left:calc(-8rem * calc(1 - var(--tw-space-x-reverse)));
}

.-space-x-36 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(-9rem * var(--tw-space-x-reverse));
  margin-left:calc(-9rem * calc(1 - var(--tw-space-x-reverse)));
}

.-space-x-40 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(-10rem * var(--tw-space-x-reverse));
  margin-left:calc(-10rem * calc(1 - var(--tw-space-x-reverse)));
}

.-space-x-44 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(-11rem * var(--tw-space-x-reverse));
  margin-left:calc(-11rem * calc(1 - var(--tw-space-x-reverse)));
}

.-space-x-48 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(-12rem * var(--tw-space-x-reverse));
  margin-left:calc(-12rem * calc(1 - var(--tw-space-x-reverse)));
}

.-space-x-52 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(-13rem * var(--tw-space-x-reverse));
  margin-left:calc(-13rem * calc(1 - var(--tw-space-x-reverse)));
}

.-space-x-56 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(-14rem * var(--tw-space-x-reverse));
  margin-left:calc(-14rem * calc(1 - var(--tw-space-x-reverse)));
}

.-space-x-60 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(-15rem * var(--tw-space-x-reverse));
  margin-left:calc(-15rem * calc(1 - var(--tw-space-x-reverse)));
}

.-space-x-64 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(-16rem * var(--tw-space-x-reverse));
  margin-left:calc(-16rem * calc(1 - var(--tw-space-x-reverse)));
}

.-space-x-72 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(-18rem * var(--tw-space-x-reverse));
  margin-left:calc(-18rem * calc(1 - var(--tw-space-x-reverse)));
}

.-space-x-80 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(-20rem * var(--tw-space-x-reverse));
  margin-left:calc(-20rem * calc(1 - var(--tw-space-x-reverse)));
}

.-space-x-96 > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(-24rem * var(--tw-space-x-reverse));
  margin-left:calc(-24rem * calc(1 - var(--tw-space-x-reverse)));
}

.-space-x-px > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:0;
  margin-right:calc(-1px * var(--tw-space-x-reverse));
  margin-left:calc(-1px * calc(1 - var(--tw-space-x-reverse)));
}

.space-y-0 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(0px * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(0px * var(--tw-space-y-reverse));
}

.space-y-1 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(0.25rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(0.25rem * var(--tw-space-y-reverse));
}

.space-y-2 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(0.5rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(0.5rem * var(--tw-space-y-reverse));
}

.space-y-3 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(0.75rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(0.75rem * var(--tw-space-y-reverse));
}

.space-y-4 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(1rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(1rem * var(--tw-space-y-reverse));
}

.space-y-5 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(1.25rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(1.25rem * var(--tw-space-y-reverse));
}

.space-y-6 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(1.5rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(1.5rem * var(--tw-space-y-reverse));
}

.space-y-7 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(1.75rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(1.75rem * var(--tw-space-y-reverse));
}

.space-y-8 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(2rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(2rem * var(--tw-space-y-reverse));
}

.space-y-9 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(2.25rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(2.25rem * var(--tw-space-y-reverse));
}

.space-y-10 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(2.5rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(2.5rem * var(--tw-space-y-reverse));
}

.space-y-11 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(2.75rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(2.75rem * var(--tw-space-y-reverse));
}

.space-y-12 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(3rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(3rem * var(--tw-space-y-reverse));
}

.space-y-14 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(3.5rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(3.5rem * var(--tw-space-y-reverse));
}

.space-y-16 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(4rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(4rem * var(--tw-space-y-reverse));
}

.space-y-20 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(5rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(5rem * var(--tw-space-y-reverse));
}

.space-y-24 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(6rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(6rem * var(--tw-space-y-reverse));
}

.space-y-28 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(7rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(7rem * var(--tw-space-y-reverse));
}

.space-y-32 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(8rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(8rem * var(--tw-space-y-reverse));
}

.space-y-36 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(9rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(9rem * var(--tw-space-y-reverse));
}

.space-y-40 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(10rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(10rem * var(--tw-space-y-reverse));
}

.space-y-44 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(11rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(11rem * var(--tw-space-y-reverse));
}

.space-y-48 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(12rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(12rem * var(--tw-space-y-reverse));
}

.space-y-52 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(13rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(13rem * var(--tw-space-y-reverse));
}

.space-y-56 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(14rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(14rem * var(--tw-space-y-reverse));
}

.space-y-60 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(15rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(15rem * var(--tw-space-y-reverse));
}

.space-y-64 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(16rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(16rem * var(--tw-space-y-reverse));
}

.space-y-72 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(18rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(18rem * var(--tw-space-y-reverse));
}

.space-y-80 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(20rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(20rem * var(--tw-space-y-reverse));
}

.space-y-96 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(24rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(24rem * var(--tw-space-y-reverse));
}

.space-y-px > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(1px * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(1px * var(--tw-space-y-reverse));
}

.-space-y-0 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(0px * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(0px * var(--tw-space-y-reverse));
}

.-space-y-1 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(-0.25rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(-0.25rem * var(--tw-space-y-reverse));
}

.-space-y-2 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(-0.5rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(-0.5rem * var(--tw-space-y-reverse));
}

.-space-y-3 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(-0.75rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(-0.75rem * var(--tw-space-y-reverse));
}

.-space-y-4 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(-1rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(-1rem * var(--tw-space-y-reverse));
}

.-space-y-5 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(-1.25rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(-1.25rem * var(--tw-space-y-reverse));
}

.-space-y-6 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(-1.5rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(-1.5rem * var(--tw-space-y-reverse));
}

.-space-y-7 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(-1.75rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(-1.75rem * var(--tw-space-y-reverse));
}

.-space-y-8 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(-2rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(-2rem * var(--tw-space-y-reverse));
}

.-space-y-9 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(-2.25rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(-2.25rem * var(--tw-space-y-reverse));
}

.-space-y-10 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(-2.5rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(-2.5rem * var(--tw-space-y-reverse));
}

.-space-y-11 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(-2.75rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(-2.75rem * var(--tw-space-y-reverse));
}

.-space-y-12 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(-3rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(-3rem * var(--tw-space-y-reverse));
}

.-space-y-14 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(-3.5rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(-3.5rem * var(--tw-space-y-reverse));
}

.-space-y-16 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(-4rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(-4rem * var(--tw-space-y-reverse));
}

.-space-y-20 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(-5rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(-5rem * var(--tw-space-y-reverse));
}

.-space-y-24 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(-6rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(-6rem * var(--tw-space-y-reverse));
}

.-space-y-28 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(-7rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(-7rem * var(--tw-space-y-reverse));
}

.-space-y-32 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(-8rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(-8rem * var(--tw-space-y-reverse));
}

.-space-y-36 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(-9rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(-9rem * var(--tw-space-y-reverse));
}

.-space-y-40 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(-10rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(-10rem * var(--tw-space-y-reverse));
}

.-space-y-44 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(-11rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(-11rem * var(--tw-space-y-reverse));
}

.-space-y-48 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(-12rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(-12rem * var(--tw-space-y-reverse));
}

.-space-y-52 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(-13rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(-13rem * var(--tw-space-y-reverse));
}

.-space-y-56 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(-14rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(-14rem * var(--tw-space-y-reverse));
}

.-space-y-60 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(-15rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(-15rem * var(--tw-space-y-reverse));
}

.-space-y-64 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(-16rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(-16rem * var(--tw-space-y-reverse));
}

.-space-y-72 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(-18rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(-18rem * var(--tw-space-y-reverse));
}

.-space-y-80 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(-20rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(-20rem * var(--tw-space-y-reverse));
}

.-space-y-96 > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(-24rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(-24rem * var(--tw-space-y-reverse));
}

.-space-y-px > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:0;
  margin-top:calc(-1px * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom:calc(-1px * var(--tw-space-y-reverse));
}

.space-y-reverse > :not([hidden]) ~ :not([hidden]){
  --tw-space-y-reverse:1;
}

.space-x-reverse > :not([hidden]) ~ :not([hidden]){
  --tw-space-x-reverse:1;
}

.divide-x-0 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-x-reverse:0;
  border-right-width:calc(0px * var(--tw-divide-x-reverse));
  border-left-width:calc(0px * calc(1 - var(--tw-divide-x-reverse)));
}

.divide-x-2 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-x-reverse:0;
  border-right-width:calc(2px * var(--tw-divide-x-reverse));
  border-left-width:calc(2px * calc(1 - var(--tw-divide-x-reverse)));
}

.divide-x-4 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-x-reverse:0;
  border-right-width:calc(4px * var(--tw-divide-x-reverse));
  border-left-width:calc(4px * calc(1 - var(--tw-divide-x-reverse)));
}

.divide-x-8 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-x-reverse:0;
  border-right-width:calc(8px * var(--tw-divide-x-reverse));
  border-left-width:calc(8px * calc(1 - var(--tw-divide-x-reverse)));
}

.divide-x > :not([hidden]) ~ :not([hidden]){
  --tw-divide-x-reverse:0;
  border-right-width:calc(1px * var(--tw-divide-x-reverse));
  border-left-width:calc(1px * calc(1 - var(--tw-divide-x-reverse)));
}

.divide-y-0 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-y-reverse:0;
  border-top-width:calc(0px * calc(1 - var(--tw-divide-y-reverse)));
  border-bottom-width:calc(0px * var(--tw-divide-y-reverse));
}

.divide-y-2 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-y-reverse:0;
  border-top-width:calc(2px * calc(1 - var(--tw-divide-y-reverse)));
  border-bottom-width:calc(2px * var(--tw-divide-y-reverse));
}

.divide-y-4 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-y-reverse:0;
  border-top-width:calc(4px * calc(1 - var(--tw-divide-y-reverse)));
  border-bottom-width:calc(4px * var(--tw-divide-y-reverse));
}

.divide-y-8 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-y-reverse:0;
  border-top-width:calc(8px * calc(1 - var(--tw-divide-y-reverse)));
  border-bottom-width:calc(8px * var(--tw-divide-y-reverse));
}

.divide-y > :not([hidden]) ~ :not([hidden]){
  --tw-divide-y-reverse:0;
  border-top-width:calc(1px * calc(1 - var(--tw-divide-y-reverse)));
  border-bottom-width:calc(1px * var(--tw-divide-y-reverse));
}

.divide-y-reverse > :not([hidden]) ~ :not([hidden]){
  --tw-divide-y-reverse:1;
}

.divide-x-reverse > :not([hidden]) ~ :not([hidden]){
  --tw-divide-x-reverse:1;
}

.divide-solid > :not([hidden]) ~ :not([hidden]){
  border-style:solid;
}

.divide-dashed > :not([hidden]) ~ :not([hidden]){
  border-style:dashed;
}

.divide-dotted > :not([hidden]) ~ :not([hidden]){
  border-style:dotted;
}

.divide-double > :not([hidden]) ~ :not([hidden]){
  border-style:double;
}

.divide-none > :not([hidden]) ~ :not([hidden]){
  border-style:none;
}

.divide-transparent > :not([hidden]) ~ :not([hidden]){
  border-color:transparent;
}

.divide-current > :not([hidden]) ~ :not([hidden]){
  border-color:currentColor;
}

.divide-black > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(0, 0, 0, var(--tw-divide-opacity));
}

.divide-white > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(255, 255, 255, var(--tw-divide-opacity));
}

.divide-gray-50 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(249, 250, 251, var(--tw-divide-opacity));
}

.divide-gray-100 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(243, 244, 246, var(--tw-divide-opacity));
}

.divide-gray-200 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(229, 231, 235, var(--tw-divide-opacity));
}

.divide-gray-300 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(209, 213, 219, var(--tw-divide-opacity));
}

.divide-gray-400 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(156, 163, 175, var(--tw-divide-opacity));
}

.divide-gray-500 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(107, 114, 128, var(--tw-divide-opacity));
}

.divide-gray-600 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(75, 85, 99, var(--tw-divide-opacity));
}

.divide-gray-700 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(55, 65, 81, var(--tw-divide-opacity));
}

.divide-gray-800 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(31, 41, 55, var(--tw-divide-opacity));
}

.divide-gray-900 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(17, 24, 39, var(--tw-divide-opacity));
}

.divide-red-50 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(254, 242, 242, var(--tw-divide-opacity));
}

.divide-red-100 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(254, 226, 226, var(--tw-divide-opacity));
}

.divide-red-200 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(254, 202, 202, var(--tw-divide-opacity));
}

.divide-red-300 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(252, 165, 165, var(--tw-divide-opacity));
}

.divide-red-400 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(248, 113, 113, var(--tw-divide-opacity));
}

.divide-red-500 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(239, 68, 68, var(--tw-divide-opacity));
}

.divide-red-600 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(220, 38, 38, var(--tw-divide-opacity));
}

.divide-red-700 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(185, 28, 28, var(--tw-divide-opacity));
}

.divide-red-800 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(153, 27, 27, var(--tw-divide-opacity));
}

.divide-red-900 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(127, 29, 29, var(--tw-divide-opacity));
}

.divide-yellow-50 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(255, 251, 235, var(--tw-divide-opacity));
}

.divide-yellow-100 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(254, 243, 199, var(--tw-divide-opacity));
}

.divide-yellow-200 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(253, 230, 138, var(--tw-divide-opacity));
}

.divide-yellow-300 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(252, 211, 77, var(--tw-divide-opacity));
}

.divide-yellow-400 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(251, 191, 36, var(--tw-divide-opacity));
}

.divide-yellow-500 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(245, 158, 11, var(--tw-divide-opacity));
}

.divide-yellow-600 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(217, 119, 6, var(--tw-divide-opacity));
}

.divide-yellow-700 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(180, 83, 9, var(--tw-divide-opacity));
}

.divide-yellow-800 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(146, 64, 14, var(--tw-divide-opacity));
}

.divide-yellow-900 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(120, 53, 15, var(--tw-divide-opacity));
}

.divide-green-50 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(236, 253, 245, var(--tw-divide-opacity));
}

.divide-green-100 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(209, 250, 229, var(--tw-divide-opacity));
}

.divide-green-200 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(167, 243, 208, var(--tw-divide-opacity));
}

.divide-green-300 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(110, 231, 183, var(--tw-divide-opacity));
}

.divide-green-400 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(52, 211, 153, var(--tw-divide-opacity));
}

.divide-green-500 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(16, 185, 129, var(--tw-divide-opacity));
}

.divide-green-600 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(5, 150, 105, var(--tw-divide-opacity));
}

.divide-green-700 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(4, 120, 87, var(--tw-divide-opacity));
}

.divide-green-800 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(6, 95, 70, var(--tw-divide-opacity));
}

.divide-green-900 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(6, 78, 59, var(--tw-divide-opacity));
}

.divide-blue-50 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(239, 246, 255, var(--tw-divide-opacity));
}

.divide-blue-100 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(219, 234, 254, var(--tw-divide-opacity));
}

.divide-blue-200 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(191, 219, 254, var(--tw-divide-opacity));
}

.divide-blue-300 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(147, 197, 253, var(--tw-divide-opacity));
}

.divide-blue-400 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(96, 165, 250, var(--tw-divide-opacity));
}

.divide-blue-500 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(59, 130, 246, var(--tw-divide-opacity));
}

.divide-blue-600 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(37, 99, 235, var(--tw-divide-opacity));
}

.divide-blue-700 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(29, 78, 216, var(--tw-divide-opacity));
}

.divide-blue-800 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(30, 64, 175, var(--tw-divide-opacity));
}

.divide-blue-900 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(30, 58, 138, var(--tw-divide-opacity));
}

.divide-indigo-50 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(238, 242, 255, var(--tw-divide-opacity));
}

.divide-indigo-100 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(224, 231, 255, var(--tw-divide-opacity));
}

.divide-indigo-200 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(199, 210, 254, var(--tw-divide-opacity));
}

.divide-indigo-300 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(165, 180, 252, var(--tw-divide-opacity));
}

.divide-indigo-400 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(129, 140, 248, var(--tw-divide-opacity));
}

.divide-indigo-500 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(99, 102, 241, var(--tw-divide-opacity));
}

.divide-indigo-600 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(79, 70, 229, var(--tw-divide-opacity));
}

.divide-indigo-700 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(67, 56, 202, var(--tw-divide-opacity));
}

.divide-indigo-800 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(55, 48, 163, var(--tw-divide-opacity));
}

.divide-indigo-900 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(49, 46, 129, var(--tw-divide-opacity));
}

.divide-purple-50 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(245, 243, 255, var(--tw-divide-opacity));
}

.divide-purple-100 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(237, 233, 254, var(--tw-divide-opacity));
}

.divide-purple-200 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(221, 214, 254, var(--tw-divide-opacity));
}

.divide-purple-300 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(196, 181, 253, var(--tw-divide-opacity));
}

.divide-purple-400 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(167, 139, 250, var(--tw-divide-opacity));
}

.divide-purple-500 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(139, 92, 246, var(--tw-divide-opacity));
}

.divide-purple-600 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(124, 58, 237, var(--tw-divide-opacity));
}

.divide-purple-700 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(109, 40, 217, var(--tw-divide-opacity));
}

.divide-purple-800 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(91, 33, 182, var(--tw-divide-opacity));
}

.divide-purple-900 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(76, 29, 149, var(--tw-divide-opacity));
}

.divide-pink-50 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(253, 242, 248, var(--tw-divide-opacity));
}

.divide-pink-100 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(252, 231, 243, var(--tw-divide-opacity));
}

.divide-pink-200 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(251, 207, 232, var(--tw-divide-opacity));
}

.divide-pink-300 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(249, 168, 212, var(--tw-divide-opacity));
}

.divide-pink-400 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(244, 114, 182, var(--tw-divide-opacity));
}

.divide-pink-500 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(236, 72, 153, var(--tw-divide-opacity));
}

.divide-pink-600 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(219, 39, 119, var(--tw-divide-opacity));
}

.divide-pink-700 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(190, 24, 93, var(--tw-divide-opacity));
}

.divide-pink-800 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(157, 23, 77, var(--tw-divide-opacity));
}

.divide-pink-900 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
  border-color:rgba(131, 24, 67, var(--tw-divide-opacity));
}

.divide-opacity-0 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:0;
}

.divide-opacity-5 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:0.05;
}

.divide-opacity-10 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:.1;
}

.divide-opacity-20 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:.2;
}

.divide-opacity-25 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:0.25;
}

.divide-opacity-30 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:.3;
}

.divide-opacity-40 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:.4;
}

.divide-opacity-50 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:.5;
}

.divide-opacity-60 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:.6;
}

.divide-opacity-70 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:.7;
}

.divide-opacity-75 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:0.75;
}

.divide-opacity-80 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:.8;
}

.divide-opacity-90 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:.9;
}

.divide-opacity-95 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:0.95;
}

.divide-opacity-100 > :not([hidden]) ~ :not([hidden]){
  --tw-divide-opacity:1;
}

.place-self-auto{
  place-self:auto;
}

.place-self-start{
  place-self:start;
}

.place-self-end{
  place-self:end;
}

.place-self-center{
  place-self:center;
}

.place-self-stretch{
  place-self:stretch;
}

.self-auto{
  align-self:auto;
}

.self-start{
  align-self:flex-start;
}

.self-end{
  align-self:flex-end;
}

.self-center{
  align-self:center;
}

.self-stretch{
  align-self:stretch;
}

.self-baseline{
  align-self:baseline;
}

.justify-self-auto{
  justify-self:auto;
}

.justify-self-start{
  justify-self:start;
}

.justify-self-end{
  justify-self:end;
}

.justify-self-center{
  justify-self:center;
}

.justify-self-stretch{
  justify-self:stretch;
}

.overflow-auto{
  overflow:auto;
}

.overflow-hidden{
  overflow:hidden;
}

.overflow-visible{
  overflow:visible;
}

.overflow-scroll{
  overflow:scroll;
}

.overflow-x-auto{
  overflow-x:auto;
}

.overflow-y-auto{
  overflow-y:auto;
}

.overflow-x-hidden{
  overflow-x:hidden;
}

.overflow-y-hidden{
  overflow-y:hidden;
}

.overflow-x-visible{
  overflow-x:visible;
}

.overflow-y-visible{
  overflow-y:visible;
}

.overflow-x-scroll{
  overflow-x:scroll;
}

.overflow-y-scroll{
  overflow-y:scroll;
}

.overscroll-auto{
  -ms-scroll-chaining:chained;
      overscroll-behavior:auto;
}

.overscroll-contain{
  -ms-scroll-chaining:none;
      overscroll-behavior:contain;
}

.overscroll-none{
  -ms-scroll-chaining:none;
      overscroll-behavior:none;
}

.overscroll-y-auto{
  overscroll-behavior-y:auto;
}

.overscroll-y-contain{
  overscroll-behavior-y:contain;
}

.overscroll-y-none{
  overscroll-behavior-y:none;
}

.overscroll-x-auto{
  overscroll-behavior-x:auto;
}

.overscroll-x-contain{
  overscroll-behavior-x:contain;
}

.overscroll-x-none{
  overscroll-behavior-x:none;
}

.truncate{
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
}

.overflow-ellipsis{
  text-overflow:ellipsis;
}

.overflow-clip{
  text-overflow:clip;
}

.whitespace-normal{
  white-space:normal;
}

.whitespace-nowrap{
  white-space:nowrap;
}

.whitespace-pre{
  white-space:pre;
}

.whitespace-pre-line{
  white-space:pre-line;
}

.whitespace-pre-wrap{
  white-space:pre-wrap;
}

.break-normal{
  overflow-wrap:normal;
  word-break:normal;
}

.break-words{
  overflow-wrap:break-word;
}

.break-all{
  word-break:break-all;
}

.rounded-4{
  border-radius:1rem;
}

.rounded-8{
  border-radius:2rem;
}

.rounded-none{
  border-radius:0px;
}

.rounded-sm{
  border-radius:0.125rem;
}

.rounded{
  border-radius:0.25rem;
}

.rounded-md{
  border-radius:0.375rem;
}

.rounded-lg{
  border-radius:0.5rem;
}

.rounded-xl{
  border-radius:0.75rem;
}

.rounded-2xl{
  border-radius:1rem;
}

.rounded-3xl{
  border-radius:1.5rem;
}

.rounded-full{
  border-radius:9999px;
}

.rounded-t-none{
  border-top-left-radius:0px;
  border-top-right-radius:0px;
}

.rounded-t-sm{
  border-top-left-radius:0.125rem;
  border-top-right-radius:0.125rem;
}

.rounded-t{
  border-top-left-radius:0.25rem;
  border-top-right-radius:0.25rem;
}

.rounded-t-md{
  border-top-left-radius:0.375rem;
  border-top-right-radius:0.375rem;
}

.rounded-t-lg{
  border-top-left-radius:0.5rem;
  border-top-right-radius:0.5rem;
}

.rounded-t-xl{
  border-top-left-radius:0.75rem;
  border-top-right-radius:0.75rem;
}

.rounded-t-2xl{
  border-top-left-radius:1rem;
  border-top-right-radius:1rem;
}

.rounded-t-3xl{
  border-top-left-radius:1.5rem;
  border-top-right-radius:1.5rem;
}

.rounded-t-full{
  border-top-left-radius:9999px;
  border-top-right-radius:9999px;
}

.rounded-r-none{
  border-top-right-radius:0px;
  border-bottom-right-radius:0px;
}

.rounded-r-sm{
  border-top-right-radius:0.125rem;
  border-bottom-right-radius:0.125rem;
}

.rounded-r{
  border-top-right-radius:0.25rem;
  border-bottom-right-radius:0.25rem;
}

.rounded-r-md{
  border-top-right-radius:0.375rem;
  border-bottom-right-radius:0.375rem;
}

.rounded-r-lg{
  border-top-right-radius:0.5rem;
  border-bottom-right-radius:0.5rem;
}

.rounded-r-xl{
  border-top-right-radius:0.75rem;
  border-bottom-right-radius:0.75rem;
}

.rounded-r-2xl{
  border-top-right-radius:1rem;
  border-bottom-right-radius:1rem;
}

.rounded-r-3xl{
  border-top-right-radius:1.5rem;
  border-bottom-right-radius:1.5rem;
}

.rounded-r-full{
  border-top-right-radius:9999px;
  border-bottom-right-radius:9999px;
}

.rounded-b-none{
  border-bottom-right-radius:0px;
  border-bottom-left-radius:0px;
}

.rounded-b-sm{
  border-bottom-right-radius:0.125rem;
  border-bottom-left-radius:0.125rem;
}

.rounded-b{
  border-bottom-right-radius:0.25rem;
  border-bottom-left-radius:0.25rem;
}

.rounded-b-md{
  border-bottom-right-radius:0.375rem;
  border-bottom-left-radius:0.375rem;
}

.rounded-b-lg{
  border-bottom-right-radius:0.5rem;
  border-bottom-left-radius:0.5rem;
}

.rounded-b-xl{
  border-bottom-right-radius:0.75rem;
  border-bottom-left-radius:0.75rem;
}

.rounded-b-2xl{
  border-bottom-right-radius:1rem;
  border-bottom-left-radius:1rem;
}

.rounded-b-3xl{
  border-bottom-right-radius:1.5rem;
  border-bottom-left-radius:1.5rem;
}

.rounded-b-full{
  border-bottom-right-radius:9999px;
  border-bottom-left-radius:9999px;
}

.rounded-l-none{
  border-top-left-radius:0px;
  border-bottom-left-radius:0px;
}

.rounded-l-sm{
  border-top-left-radius:0.125rem;
  border-bottom-left-radius:0.125rem;
}

.rounded-l{
  border-top-left-radius:0.25rem;
  border-bottom-left-radius:0.25rem;
}

.rounded-l-md{
  border-top-left-radius:0.375rem;
  border-bottom-left-radius:0.375rem;
}

.rounded-l-lg{
  border-top-left-radius:0.5rem;
  border-bottom-left-radius:0.5rem;
}

.rounded-l-xl{
  border-top-left-radius:0.75rem;
  border-bottom-left-radius:0.75rem;
}

.rounded-l-2xl{
  border-top-left-radius:1rem;
  border-bottom-left-radius:1rem;
}

.rounded-l-3xl{
  border-top-left-radius:1.5rem;
  border-bottom-left-radius:1.5rem;
}

.rounded-l-full{
  border-top-left-radius:9999px;
  border-bottom-left-radius:9999px;
}

.rounded-tl-none{
  border-top-left-radius:0px;
}

.rounded-tl-sm{
  border-top-left-radius:0.125rem;
}

.rounded-tl{
  border-top-left-radius:0.25rem;
}

.rounded-tl-md{
  border-top-left-radius:0.375rem;
}

.rounded-tl-lg{
  border-top-left-radius:0.5rem;
}

.rounded-tl-xl{
  border-top-left-radius:0.75rem;
}

.rounded-tl-2xl{
  border-top-left-radius:1rem;
}

.rounded-tl-3xl{
  border-top-left-radius:1.5rem;
}

.rounded-tl-full{
  border-top-left-radius:9999px;
}

.rounded-tr-none{
  border-top-right-radius:0px;
}

.rounded-tr-sm{
  border-top-right-radius:0.125rem;
}

.rounded-tr{
  border-top-right-radius:0.25rem;
}

.rounded-tr-md{
  border-top-right-radius:0.375rem;
}

.rounded-tr-lg{
  border-top-right-radius:0.5rem;
}

.rounded-tr-xl{
  border-top-right-radius:0.75rem;
}

.rounded-tr-2xl{
  border-top-right-radius:1rem;
}

.rounded-tr-3xl{
  border-top-right-radius:1.5rem;
}

.rounded-tr-full{
  border-top-right-radius:9999px;
}

.rounded-br-none{
  border-bottom-right-radius:0px;
}

.rounded-br-sm{
  border-bottom-right-radius:0.125rem;
}

.rounded-br{
  border-bottom-right-radius:0.25rem;
}

.rounded-br-md{
  border-bottom-right-radius:0.375rem;
}

.rounded-br-lg{
  border-bottom-right-radius:0.5rem;
}

.rounded-br-xl{
  border-bottom-right-radius:0.75rem;
}

.rounded-br-2xl{
  border-bottom-right-radius:1rem;
}

.rounded-br-3xl{
  border-bottom-right-radius:1.5rem;
}

.rounded-br-full{
  border-bottom-right-radius:9999px;
}

.rounded-bl-none{
  border-bottom-left-radius:0px;
}

.rounded-bl-sm{
  border-bottom-left-radius:0.125rem;
}

.rounded-bl{
  border-bottom-left-radius:0.25rem;
}

.rounded-bl-md{
  border-bottom-left-radius:0.375rem;
}

.rounded-bl-lg{
  border-bottom-left-radius:0.5rem;
}

.rounded-bl-xl{
  border-bottom-left-radius:0.75rem;
}

.rounded-bl-2xl{
  border-bottom-left-radius:1rem;
}

.rounded-bl-3xl{
  border-bottom-left-radius:1.5rem;
}

.rounded-bl-full{
  border-bottom-left-radius:9999px;
}

.border-0{
  border-width:0px;
}

.border-2{
  border-width:2px;
}

.border-4{
  border-width:4px;
}

.border-8{
  border-width:8px;
}

.border{
  border-width:1px;
}

.border-t-0{
  border-top-width:0px;
}

.border-t-2{
  border-top-width:2px;
}

.border-t-4{
  border-top-width:4px;
}

.border-t-8{
  border-top-width:8px;
}

.border-t{
  border-top-width:1px;
}

.border-r-0{
  border-right-width:0px;
}

.border-r-2{
  border-right-width:2px;
}

.border-r-4{
  border-right-width:4px;
}

.border-r-8{
  border-right-width:8px;
}

.border-r{
  border-right-width:1px;
}

.border-b-0{
  border-bottom-width:0px;
}

.border-b-2{
  border-bottom-width:2px;
}

.border-b-4{
  border-bottom-width:4px;
}

.border-b-8{
  border-bottom-width:8px;
}

.border-b{
  border-bottom-width:1px;
}

.border-l-0{
  border-left-width:0px;
}

.border-l-2{
  border-left-width:2px;
}

.border-l-4{
  border-left-width:4px;
}

.border-l-8{
  border-left-width:8px;
}

.border-l{
  border-left-width:1px;
}

.border-solid{
  border-style:solid;
}

.border-dashed{
  border-style:dashed;
}

.border-dotted{
  border-style:dotted;
}

.border-double{
  border-style:double;
}

.border-none{
  border-style:none;
}

.border-transparent{
  border-color:transparent;
}

.border-current{
  border-color:currentColor;
}

.border-black{
  --tw-border-opacity:1;
  border-color:rgba(0, 0, 0, var(--tw-border-opacity));
}

.border-white{
  --tw-border-opacity:1;
  border-color:rgba(255, 255, 255, var(--tw-border-opacity));
}

.border-gray-50{
  --tw-border-opacity:1;
  border-color:rgba(249, 250, 251, var(--tw-border-opacity));
}

.border-gray-100{
  --tw-border-opacity:1;
  border-color:rgba(243, 244, 246, var(--tw-border-opacity));
}

.border-gray-200{
  --tw-border-opacity:1;
  border-color:rgba(229, 231, 235, var(--tw-border-opacity));
}

.border-gray-300{
  --tw-border-opacity:1;
  border-color:rgba(209, 213, 219, var(--tw-border-opacity));
}

.border-gray-400{
  --tw-border-opacity:1;
  border-color:rgba(156, 163, 175, var(--tw-border-opacity));
}

.border-gray-500{
  --tw-border-opacity:1;
  border-color:rgba(107, 114, 128, var(--tw-border-opacity));
}

.border-gray-600{
  --tw-border-opacity:1;
  border-color:rgba(75, 85, 99, var(--tw-border-opacity));
}

.border-gray-700{
  --tw-border-opacity:1;
  border-color:rgba(55, 65, 81, var(--tw-border-opacity));
}

.border-gray-800{
  --tw-border-opacity:1;
  border-color:rgba(31, 41, 55, var(--tw-border-opacity));
}

.border-gray-900{
  --tw-border-opacity:1;
  border-color:rgba(17, 24, 39, var(--tw-border-opacity));
}

.border-red-50{
  --tw-border-opacity:1;
  border-color:rgba(254, 242, 242, var(--tw-border-opacity));
}

.border-red-100{
  --tw-border-opacity:1;
  border-color:rgba(254, 226, 226, var(--tw-border-opacity));
}

.border-red-200{
  --tw-border-opacity:1;
  border-color:rgba(254, 202, 202, var(--tw-border-opacity));
}

.border-red-300{
  --tw-border-opacity:1;
  border-color:rgba(252, 165, 165, var(--tw-border-opacity));
}

.border-red-400{
  --tw-border-opacity:1;
  border-color:rgba(248, 113, 113, var(--tw-border-opacity));
}

.border-red-500{
  --tw-border-opacity:1;
  border-color:rgba(239, 68, 68, var(--tw-border-opacity));
}

.border-red-600{
  --tw-border-opacity:1;
  border-color:rgba(220, 38, 38, var(--tw-border-opacity));
}

.border-red-700{
  --tw-border-opacity:1;
  border-color:rgba(185, 28, 28, var(--tw-border-opacity));
}

.border-red-800{
  --tw-border-opacity:1;
  border-color:rgba(153, 27, 27, var(--tw-border-opacity));
}

.border-red-900{
  --tw-border-opacity:1;
  border-color:rgba(127, 29, 29, var(--tw-border-opacity));
}

.border-yellow-50{
  --tw-border-opacity:1;
  border-color:rgba(255, 251, 235, var(--tw-border-opacity));
}

.border-yellow-100{
  --tw-border-opacity:1;
  border-color:rgba(254, 243, 199, var(--tw-border-opacity));
}

.border-yellow-200{
  --tw-border-opacity:1;
  border-color:rgba(253, 230, 138, var(--tw-border-opacity));
}

.border-yellow-300{
  --tw-border-opacity:1;
  border-color:rgba(252, 211, 77, var(--tw-border-opacity));
}

.border-yellow-400{
  --tw-border-opacity:1;
  border-color:rgba(251, 191, 36, var(--tw-border-opacity));
}

.border-yellow-500{
  --tw-border-opacity:1;
  border-color:rgba(245, 158, 11, var(--tw-border-opacity));
}

.border-yellow-600{
  --tw-border-opacity:1;
  border-color:rgba(217, 119, 6, var(--tw-border-opacity));
}

.border-yellow-700{
  --tw-border-opacity:1;
  border-color:rgba(180, 83, 9, var(--tw-border-opacity));
}

.border-yellow-800{
  --tw-border-opacity:1;
  border-color:rgba(146, 64, 14, var(--tw-border-opacity));
}

.border-yellow-900{
  --tw-border-opacity:1;
  border-color:rgba(120, 53, 15, var(--tw-border-opacity));
}

.border-green-50{
  --tw-border-opacity:1;
  border-color:rgba(236, 253, 245, var(--tw-border-opacity));
}

.border-green-100{
  --tw-border-opacity:1;
  border-color:rgba(209, 250, 229, var(--tw-border-opacity));
}

.border-green-200{
  --tw-border-opacity:1;
  border-color:rgba(167, 243, 208, var(--tw-border-opacity));
}

.border-green-300{
  --tw-border-opacity:1;
  border-color:rgba(110, 231, 183, var(--tw-border-opacity));
}

.border-green-400{
  --tw-border-opacity:1;
  border-color:rgba(52, 211, 153, var(--tw-border-opacity));
}

.border-green-500{
  --tw-border-opacity:1;
  border-color:rgba(16, 185, 129, var(--tw-border-opacity));
}

.border-green-600{
  --tw-border-opacity:1;
  border-color:rgba(5, 150, 105, var(--tw-border-opacity));
}

.border-green-700{
  --tw-border-opacity:1;
  border-color:rgba(4, 120, 87, var(--tw-border-opacity));
}

.border-green-800{
  --tw-border-opacity:1;
  border-color:rgba(6, 95, 70, var(--tw-border-opacity));
}

.border-green-900{
  --tw-border-opacity:1;
  border-color:rgba(6, 78, 59, var(--tw-border-opacity));
}

.border-blue-50{
  --tw-border-opacity:1;
  border-color:rgba(239, 246, 255, var(--tw-border-opacity));
}

.border-blue-100{
  --tw-border-opacity:1;
  border-color:rgba(219, 234, 254, var(--tw-border-opacity));
}

.border-blue-200{
  --tw-border-opacity:1;
  border-color:rgba(191, 219, 254, var(--tw-border-opacity));
}

.border-blue-300{
  --tw-border-opacity:1;
  border-color:rgba(147, 197, 253, var(--tw-border-opacity));
}

.border-blue-400{
  --tw-border-opacity:1;
  border-color:rgba(96, 165, 250, var(--tw-border-opacity));
}

.border-blue-500{
  --tw-border-opacity:1;
  border-color:rgba(59, 130, 246, var(--tw-border-opacity));
}

.border-blue-600{
  --tw-border-opacity:1;
  border-color:rgba(37, 99, 235, var(--tw-border-opacity));
}

.border-blue-700{
  --tw-border-opacity:1;
  border-color:rgba(29, 78, 216, var(--tw-border-opacity));
}

.border-blue-800{
  --tw-border-opacity:1;
  border-color:rgba(30, 64, 175, var(--tw-border-opacity));
}

.border-blue-900{
  --tw-border-opacity:1;
  border-color:rgba(30, 58, 138, var(--tw-border-opacity));
}

.border-indigo-50{
  --tw-border-opacity:1;
  border-color:rgba(238, 242, 255, var(--tw-border-opacity));
}

.border-indigo-100{
  --tw-border-opacity:1;
  border-color:rgba(224, 231, 255, var(--tw-border-opacity));
}

.border-indigo-200{
  --tw-border-opacity:1;
  border-color:rgba(199, 210, 254, var(--tw-border-opacity));
}

.border-indigo-300{
  --tw-border-opacity:1;
  border-color:rgba(165, 180, 252, var(--tw-border-opacity));
}

.border-indigo-400{
  --tw-border-opacity:1;
  border-color:rgba(129, 140, 248, var(--tw-border-opacity));
}

.border-indigo-500{
  --tw-border-opacity:1;
  border-color:rgba(99, 102, 241, var(--tw-border-opacity));
}

.border-indigo-600{
  --tw-border-opacity:1;
  border-color:rgba(79, 70, 229, var(--tw-border-opacity));
}

.border-indigo-700{
  --tw-border-opacity:1;
  border-color:rgba(67, 56, 202, var(--tw-border-opacity));
}

.border-indigo-800{
  --tw-border-opacity:1;
  border-color:rgba(55, 48, 163, var(--tw-border-opacity));
}

.border-indigo-900{
  --tw-border-opacity:1;
  border-color:rgba(49, 46, 129, var(--tw-border-opacity));
}

.border-purple-50{
  --tw-border-opacity:1;
  border-color:rgba(245, 243, 255, var(--tw-border-opacity));
}

.border-purple-100{
  --tw-border-opacity:1;
  border-color:rgba(237, 233, 254, var(--tw-border-opacity));
}

.border-purple-200{
  --tw-border-opacity:1;
  border-color:rgba(221, 214, 254, var(--tw-border-opacity));
}

.border-purple-300{
  --tw-border-opacity:1;
  border-color:rgba(196, 181, 253, var(--tw-border-opacity));
}

.border-purple-400{
  --tw-border-opacity:1;
  border-color:rgba(167, 139, 250, var(--tw-border-opacity));
}

.border-purple-500{
  --tw-border-opacity:1;
  border-color:rgba(139, 92, 246, var(--tw-border-opacity));
}

.border-purple-600{
  --tw-border-opacity:1;
  border-color:rgba(124, 58, 237, var(--tw-border-opacity));
}

.border-purple-700{
  --tw-border-opacity:1;
  border-color:rgba(109, 40, 217, var(--tw-border-opacity));
}

.border-purple-800{
  --tw-border-opacity:1;
  border-color:rgba(91, 33, 182, var(--tw-border-opacity));
}

.border-purple-900{
  --tw-border-opacity:1;
  border-color:rgba(76, 29, 149, var(--tw-border-opacity));
}

.border-pink-50{
  --tw-border-opacity:1;
  border-color:rgba(253, 242, 248, var(--tw-border-opacity));
}

.border-pink-100{
  --tw-border-opacity:1;
  border-color:rgba(252, 231, 243, var(--tw-border-opacity));
}

.border-pink-200{
  --tw-border-opacity:1;
  border-color:rgba(251, 207, 232, var(--tw-border-opacity));
}

.border-pink-300{
  --tw-border-opacity:1;
  border-color:rgba(249, 168, 212, var(--tw-border-opacity));
}

.border-pink-400{
  --tw-border-opacity:1;
  border-color:rgba(244, 114, 182, var(--tw-border-opacity));
}

.border-pink-500{
  --tw-border-opacity:1;
  border-color:rgba(236, 72, 153, var(--tw-border-opacity));
}

.border-pink-600{
  --tw-border-opacity:1;
  border-color:rgba(219, 39, 119, var(--tw-border-opacity));
}

.border-pink-700{
  --tw-border-opacity:1;
  border-color:rgba(190, 24, 93, var(--tw-border-opacity));
}

.border-pink-800{
  --tw-border-opacity:1;
  border-color:rgba(157, 23, 77, var(--tw-border-opacity));
}

.border-pink-900{
  --tw-border-opacity:1;
  border-color:rgba(131, 24, 67, var(--tw-border-opacity));
}

.border-neutral-300{
  --tw-border-opacity:1;
  border-color:rgba(210, 217, 216, var(--tw-border-opacity));
}

.border-neutral-400{
  --tw-border-opacity:1;
  border-color:rgba(146, 152, 151, var(--tw-border-opacity));
}

.border-neutral-500{
  --tw-border-opacity:1;
  border-color:rgba(52, 61, 60, var(--tw-border-opacity));
}

.border-lightgraycyan-400{
  --tw-border-opacity:1;
  border-color:rgba(222, 234, 233, var(--tw-border-opacity));
}

.border-opacity-0{
  --tw-border-opacity:0;
}

.border-opacity-5{
  --tw-border-opacity:0.05;
}

.border-opacity-10{
  --tw-border-opacity:.1;
}

.border-opacity-20{
  --tw-border-opacity:.2;
}

.border-opacity-25{
  --tw-border-opacity:0.25;
}

.border-opacity-30{
  --tw-border-opacity:.3;
}

.border-opacity-40{
  --tw-border-opacity:.4;
}

.border-opacity-50{
  --tw-border-opacity:.5;
}

.border-opacity-60{
  --tw-border-opacity:.6;
}

.border-opacity-70{
  --tw-border-opacity:.7;
}

.border-opacity-75{
  --tw-border-opacity:0.75;
}

.border-opacity-80{
  --tw-border-opacity:.8;
}

.border-opacity-90{
  --tw-border-opacity:.9;
}

.border-opacity-95{
  --tw-border-opacity:0.95;
}

.border-opacity-100{
  --tw-border-opacity:1;
}

.bg-transparent{
  background-color:transparent;
}

.bg-current{
  background-color:currentColor;
}

.bg-black{
  --tw-bg-opacity:1;
  background-color:rgba(0, 0, 0, var(--tw-bg-opacity));
}

.bg-white{
  --tw-bg-opacity:1;
  background-color:rgba(255, 255, 255, var(--tw-bg-opacity));
}

.bg-gray-50{
  --tw-bg-opacity:1;
  background-color:rgba(249, 250, 251, var(--tw-bg-opacity));
}

.bg-gray-100{
  --tw-bg-opacity:1;
  background-color:rgba(243, 244, 246, var(--tw-bg-opacity));
}

.bg-gray-200{
  --tw-bg-opacity:1;
  background-color:rgba(229, 231, 235, var(--tw-bg-opacity));
}

.bg-gray-300{
  --tw-bg-opacity:1;
  background-color:rgba(209, 213, 219, var(--tw-bg-opacity));
}

.bg-gray-400{
  --tw-bg-opacity:1;
  background-color:rgba(156, 163, 175, var(--tw-bg-opacity));
}

.bg-gray-500{
  --tw-bg-opacity:1;
  background-color:rgba(107, 114, 128, var(--tw-bg-opacity));
}

.bg-gray-600{
  --tw-bg-opacity:1;
  background-color:rgba(75, 85, 99, var(--tw-bg-opacity));
}

.bg-gray-700{
  --tw-bg-opacity:1;
  background-color:rgba(55, 65, 81, var(--tw-bg-opacity));
}

.bg-gray-800{
  --tw-bg-opacity:1;
  background-color:rgba(31, 41, 55, var(--tw-bg-opacity));
}

.bg-gray-900{
  --tw-bg-opacity:1;
  background-color:rgba(17, 24, 39, var(--tw-bg-opacity));
}

.bg-red-50{
  --tw-bg-opacity:1;
  background-color:rgba(254, 242, 242, var(--tw-bg-opacity));
}

.bg-red-100{
  --tw-bg-opacity:1;
  background-color:rgba(254, 226, 226, var(--tw-bg-opacity));
}

.bg-red-200{
  --tw-bg-opacity:1;
  background-color:rgba(254, 202, 202, var(--tw-bg-opacity));
}

.bg-red-300{
  --tw-bg-opacity:1;
  background-color:rgba(252, 165, 165, var(--tw-bg-opacity));
}

.bg-red-400{
  --tw-bg-opacity:1;
  background-color:rgba(248, 113, 113, var(--tw-bg-opacity));
}

.bg-red-500{
  --tw-bg-opacity:1;
  background-color:rgba(239, 68, 68, var(--tw-bg-opacity));
}

.bg-red-600{
  --tw-bg-opacity:1;
  background-color:rgba(220, 38, 38, var(--tw-bg-opacity));
}

.bg-red-700{
  --tw-bg-opacity:1;
  background-color:rgba(185, 28, 28, var(--tw-bg-opacity));
}

.bg-red-800{
  --tw-bg-opacity:1;
  background-color:rgba(153, 27, 27, var(--tw-bg-opacity));
}

.bg-red-900{
  --tw-bg-opacity:1;
  background-color:rgba(127, 29, 29, var(--tw-bg-opacity));
}

.bg-yellow-50{
  --tw-bg-opacity:1;
  background-color:rgba(255, 251, 235, var(--tw-bg-opacity));
}

.bg-yellow-100{
  --tw-bg-opacity:1;
  background-color:rgba(254, 243, 199, var(--tw-bg-opacity));
}

.bg-yellow-200{
  --tw-bg-opacity:1;
  background-color:rgba(253, 230, 138, var(--tw-bg-opacity));
}

.bg-yellow-300{
  --tw-bg-opacity:1;
  background-color:rgba(252, 211, 77, var(--tw-bg-opacity));
}

.bg-yellow-400{
  --tw-bg-opacity:1;
  background-color:rgba(251, 191, 36, var(--tw-bg-opacity));
}

.bg-yellow-500{
  --tw-bg-opacity:1;
  background-color:rgba(245, 158, 11, var(--tw-bg-opacity));
}

.bg-yellow-600{
  --tw-bg-opacity:1;
  background-color:rgba(217, 119, 6, var(--tw-bg-opacity));
}

.bg-yellow-700{
  --tw-bg-opacity:1;
  background-color:rgba(180, 83, 9, var(--tw-bg-opacity));
}

.bg-yellow-800{
  --tw-bg-opacity:1;
  background-color:rgba(146, 64, 14, var(--tw-bg-opacity));
}

.bg-yellow-900{
  --tw-bg-opacity:1;
  background-color:rgba(120, 53, 15, var(--tw-bg-opacity));
}

.bg-green-50{
  --tw-bg-opacity:1;
  background-color:rgba(236, 253, 245, var(--tw-bg-opacity));
}

.bg-green-100{
  --tw-bg-opacity:1;
  background-color:rgba(209, 250, 229, var(--tw-bg-opacity));
}

.bg-green-200{
  --tw-bg-opacity:1;
  background-color:rgba(167, 243, 208, var(--tw-bg-opacity));
}

.bg-green-300{
  --tw-bg-opacity:1;
  background-color:rgba(110, 231, 183, var(--tw-bg-opacity));
}

.bg-green-400{
  --tw-bg-opacity:1;
  background-color:rgba(52, 211, 153, var(--tw-bg-opacity));
}

.bg-green-500{
  --tw-bg-opacity:1;
  background-color:rgba(16, 185, 129, var(--tw-bg-opacity));
}

.bg-green-600{
  --tw-bg-opacity:1;
  background-color:rgba(5, 150, 105, var(--tw-bg-opacity));
}

.bg-green-700{
  --tw-bg-opacity:1;
  background-color:rgba(4, 120, 87, var(--tw-bg-opacity));
}

.bg-green-800{
  --tw-bg-opacity:1;
  background-color:rgba(6, 95, 70, var(--tw-bg-opacity));
}

.bg-green-900{
  --tw-bg-opacity:1;
  background-color:rgba(6, 78, 59, var(--tw-bg-opacity));
}

.bg-blue-50{
  --tw-bg-opacity:1;
  background-color:rgba(239, 246, 255, var(--tw-bg-opacity));
}

.bg-blue-100{
  --tw-bg-opacity:1;
  background-color:rgba(219, 234, 254, var(--tw-bg-opacity));
}

.bg-blue-200{
  --tw-bg-opacity:1;
  background-color:rgba(191, 219, 254, var(--tw-bg-opacity));
}

.bg-blue-300{
  --tw-bg-opacity:1;
  background-color:rgba(147, 197, 253, var(--tw-bg-opacity));
}

.bg-blue-400{
  --tw-bg-opacity:1;
  background-color:rgba(96, 165, 250, var(--tw-bg-opacity));
}

.bg-blue-500{
  --tw-bg-opacity:1;
  background-color:rgba(59, 130, 246, var(--tw-bg-opacity));
}

.bg-blue-600{
  --tw-bg-opacity:1;
  background-color:rgba(37, 99, 235, var(--tw-bg-opacity));
}

.bg-blue-700{
  --tw-bg-opacity:1;
  background-color:rgba(29, 78, 216, var(--tw-bg-opacity));
}

.bg-blue-800{
  --tw-bg-opacity:1;
  background-color:rgba(30, 64, 175, var(--tw-bg-opacity));
}

.bg-blue-900{
  --tw-bg-opacity:1;
  background-color:rgba(30, 58, 138, var(--tw-bg-opacity));
}

.bg-indigo-50{
  --tw-bg-opacity:1;
  background-color:rgba(238, 242, 255, var(--tw-bg-opacity));
}

.bg-indigo-100{
  --tw-bg-opacity:1;
  background-color:rgba(224, 231, 255, var(--tw-bg-opacity));
}

.bg-indigo-200{
  --tw-bg-opacity:1;
  background-color:rgba(199, 210, 254, var(--tw-bg-opacity));
}

.bg-indigo-300{
  --tw-bg-opacity:1;
  background-color:rgba(165, 180, 252, var(--tw-bg-opacity));
}

.bg-indigo-400{
  --tw-bg-opacity:1;
  background-color:rgba(129, 140, 248, var(--tw-bg-opacity));
}

.bg-indigo-500{
  --tw-bg-opacity:1;
  background-color:rgba(99, 102, 241, var(--tw-bg-opacity));
}

.bg-indigo-600{
  --tw-bg-opacity:1;
  background-color:rgba(79, 70, 229, var(--tw-bg-opacity));
}

.bg-indigo-700{
  --tw-bg-opacity:1;
  background-color:rgba(67, 56, 202, var(--tw-bg-opacity));
}

.bg-indigo-800{
  --tw-bg-opacity:1;
  background-color:rgba(55, 48, 163, var(--tw-bg-opacity));
}

.bg-indigo-900{
  --tw-bg-opacity:1;
  background-color:rgba(49, 46, 129, var(--tw-bg-opacity));
}

.bg-purple-50{
  --tw-bg-opacity:1;
  background-color:rgba(245, 243, 255, var(--tw-bg-opacity));
}

.bg-purple-100{
  --tw-bg-opacity:1;
  background-color:rgba(237, 233, 254, var(--tw-bg-opacity));
}

.bg-purple-200{
  --tw-bg-opacity:1;
  background-color:rgba(221, 214, 254, var(--tw-bg-opacity));
}

.bg-purple-300{
  --tw-bg-opacity:1;
  background-color:rgba(196, 181, 253, var(--tw-bg-opacity));
}

.bg-purple-400{
  --tw-bg-opacity:1;
  background-color:rgba(167, 139, 250, var(--tw-bg-opacity));
}

.bg-purple-500{
  --tw-bg-opacity:1;
  background-color:rgba(139, 92, 246, var(--tw-bg-opacity));
}

.bg-purple-600{
  --tw-bg-opacity:1;
  background-color:rgba(124, 58, 237, var(--tw-bg-opacity));
}

.bg-purple-700{
  --tw-bg-opacity:1;
  background-color:rgba(109, 40, 217, var(--tw-bg-opacity));
}

.bg-purple-800{
  --tw-bg-opacity:1;
  background-color:rgba(91, 33, 182, var(--tw-bg-opacity));
}

.bg-purple-900{
  --tw-bg-opacity:1;
  background-color:rgba(76, 29, 149, var(--tw-bg-opacity));
}

.bg-pink-50{
  --tw-bg-opacity:1;
  background-color:rgba(253, 242, 248, var(--tw-bg-opacity));
}

.bg-pink-100{
  --tw-bg-opacity:1;
  background-color:rgba(252, 231, 243, var(--tw-bg-opacity));
}

.bg-pink-200{
  --tw-bg-opacity:1;
  background-color:rgba(251, 207, 232, var(--tw-bg-opacity));
}

.bg-pink-300{
  --tw-bg-opacity:1;
  background-color:rgba(249, 168, 212, var(--tw-bg-opacity));
}

.bg-pink-400{
  --tw-bg-opacity:1;
  background-color:rgba(244, 114, 182, var(--tw-bg-opacity));
}

.bg-pink-500{
  --tw-bg-opacity:1;
  background-color:rgba(236, 72, 153, var(--tw-bg-opacity));
}

.bg-pink-600{
  --tw-bg-opacity:1;
  background-color:rgba(219, 39, 119, var(--tw-bg-opacity));
}

.bg-pink-700{
  --tw-bg-opacity:1;
  background-color:rgba(190, 24, 93, var(--tw-bg-opacity));
}

.bg-pink-800{
  --tw-bg-opacity:1;
  background-color:rgba(157, 23, 77, var(--tw-bg-opacity));
}

.bg-pink-900{
  --tw-bg-opacity:1;
  background-color:rgba(131, 24, 67, var(--tw-bg-opacity));
}

.bg-bluelagoon-100{
  --tw-bg-opacity:1;
  background-color:rgba(214, 229, 227, var(--tw-bg-opacity));
}

.bg-bluelagoon-300{
  --tw-bg-opacity:1;
  background-color:rgba(98, 140, 145, var(--tw-bg-opacity));
}

.bg-bluelagoon-400{
  --tw-bg-opacity:1;
  background-color:rgba(12, 100, 111, var(--tw-bg-opacity));
}

.bg-seagreen-400{
  --tw-bg-opacity:1;
  background-color:rgba(56, 187, 160, var(--tw-bg-opacity));
}

.bg-neutral-100{
  --tw-bg-opacity:1;
  background-color:rgba(245, 247, 247, var(--tw-bg-opacity));
}

.bg-neutral-150{
  --tw-bg-opacity:1;
  background-color:rgba(244, 244, 244, var(--tw-bg-opacity));
}

.bg-neutral-200{
  --tw-bg-opacity:1;
  background-color:rgba(227, 230, 229, var(--tw-bg-opacity));
}

.bg-neutral-400{
  --tw-bg-opacity:1;
  background-color:rgba(146, 152, 151, var(--tw-bg-opacity));
}

.bg-lightgraycyan-400{
  --tw-bg-opacity:1;
  background-color:rgba(222, 234, 233, var(--tw-bg-opacity));
}

.hover\:bg-neutral-100:hover{
  --tw-bg-opacity:1;
  background-color:rgba(245, 247, 247, var(--tw-bg-opacity));
}

.bg-opacity-0{
  --tw-bg-opacity:0;
}

.bg-opacity-5{
  --tw-bg-opacity:0.05;
}

.bg-opacity-10{
  --tw-bg-opacity:.1;
}

.bg-opacity-20{
  --tw-bg-opacity:.2;
}

.bg-opacity-25{
  --tw-bg-opacity:0.25;
}

.bg-opacity-30{
  --tw-bg-opacity:.3;
}

.bg-opacity-40{
  --tw-bg-opacity:.4;
}

.bg-opacity-50{
  --tw-bg-opacity:.5;
}

.bg-opacity-60{
  --tw-bg-opacity:.6;
}

.bg-opacity-70{
  --tw-bg-opacity:.7;
}

.bg-opacity-75{
  --tw-bg-opacity:0.75;
}

.bg-opacity-80{
  --tw-bg-opacity:.8;
}

.bg-opacity-90{
  --tw-bg-opacity:.9;
}

.bg-opacity-95{
  --tw-bg-opacity:0.95;
}

.bg-opacity-100{
  --tw-bg-opacity:1;
}

.bg-none{
  background-image:none;
}

.bg-gradient-to-t{
  background-image:linear-gradient(to top, var(--tw-gradient-stops));
}

.bg-gradient-to-tr{
  background-image:linear-gradient(to top right, var(--tw-gradient-stops));
}

.bg-gradient-to-r{
  background-image:linear-gradient(to right, var(--tw-gradient-stops));
}

.bg-gradient-to-br{
  background-image:linear-gradient(to bottom right, var(--tw-gradient-stops));
}

.bg-gradient-to-b{
  background-image:linear-gradient(to bottom, var(--tw-gradient-stops));
}

.bg-gradient-to-bl{
  background-image:linear-gradient(to bottom left, var(--tw-gradient-stops));
}

.bg-gradient-to-l{
  background-image:linear-gradient(to left, var(--tw-gradient-stops));
}

.bg-gradient-to-tl{
  background-image:linear-gradient(to top left, var(--tw-gradient-stops));
}

.from-transparent{
  --tw-gradient-from:transparent;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(0, 0, 0, 0));
}

.from-current{
  --tw-gradient-from:currentColor;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(255, 255, 255, 0));
}

.from-black{
  --tw-gradient-from:#000;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(0, 0, 0, 0));
}

.from-white{
  --tw-gradient-from:#fff;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(255, 255, 255, 0));
}

.from-gray-50{
  --tw-gradient-from:#f9fafb;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(249, 250, 251, 0));
}

.from-gray-100{
  --tw-gradient-from:#f3f4f6;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(243, 244, 246, 0));
}

.from-gray-200{
  --tw-gradient-from:#e5e7eb;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(229, 231, 235, 0));
}

.from-gray-300{
  --tw-gradient-from:#d1d5db;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(209, 213, 219, 0));
}

.from-gray-400{
  --tw-gradient-from:#9ca3af;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(156, 163, 175, 0));
}

.from-gray-500{
  --tw-gradient-from:#6b7280;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(107, 114, 128, 0));
}

.from-gray-600{
  --tw-gradient-from:#4b5563;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(75, 85, 99, 0));
}

.from-gray-700{
  --tw-gradient-from:#374151;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(55, 65, 81, 0));
}

.from-gray-800{
  --tw-gradient-from:#1f2937;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(31, 41, 55, 0));
}

.from-gray-900{
  --tw-gradient-from:#111827;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(17, 24, 39, 0));
}

.from-red-50{
  --tw-gradient-from:#fef2f2;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(254, 242, 242, 0));
}

.from-red-100{
  --tw-gradient-from:#fee2e2;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(254, 226, 226, 0));
}

.from-red-200{
  --tw-gradient-from:#fecaca;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(254, 202, 202, 0));
}

.from-red-300{
  --tw-gradient-from:#fca5a5;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(252, 165, 165, 0));
}

.from-red-400{
  --tw-gradient-from:#f87171;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(248, 113, 113, 0));
}

.from-red-500{
  --tw-gradient-from:#ef4444;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(239, 68, 68, 0));
}

.from-red-600{
  --tw-gradient-from:#dc2626;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(220, 38, 38, 0));
}

.from-red-700{
  --tw-gradient-from:#b91c1c;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(185, 28, 28, 0));
}

.from-red-800{
  --tw-gradient-from:#991b1b;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(153, 27, 27, 0));
}

.from-red-900{
  --tw-gradient-from:#7f1d1d;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(127, 29, 29, 0));
}

.from-yellow-50{
  --tw-gradient-from:#fffbeb;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(255, 251, 235, 0));
}

.from-yellow-100{
  --tw-gradient-from:#fef3c7;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(254, 243, 199, 0));
}

.from-yellow-200{
  --tw-gradient-from:#fde68a;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(253, 230, 138, 0));
}

.from-yellow-300{
  --tw-gradient-from:#fcd34d;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(252, 211, 77, 0));
}

.from-yellow-400{
  --tw-gradient-from:#fbbf24;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(251, 191, 36, 0));
}

.from-yellow-500{
  --tw-gradient-from:#f59e0b;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(245, 158, 11, 0));
}

.from-yellow-600{
  --tw-gradient-from:#d97706;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(217, 119, 6, 0));
}

.from-yellow-700{
  --tw-gradient-from:#b45309;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(180, 83, 9, 0));
}

.from-yellow-800{
  --tw-gradient-from:#92400e;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(146, 64, 14, 0));
}

.from-yellow-900{
  --tw-gradient-from:#78350f;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(120, 53, 15, 0));
}

.from-green-50{
  --tw-gradient-from:#ecfdf5;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(236, 253, 245, 0));
}

.from-green-100{
  --tw-gradient-from:#d1fae5;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(209, 250, 229, 0));
}

.from-green-200{
  --tw-gradient-from:#a7f3d0;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(167, 243, 208, 0));
}

.from-green-300{
  --tw-gradient-from:#6ee7b7;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(110, 231, 183, 0));
}

.from-green-400{
  --tw-gradient-from:#34d399;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(52, 211, 153, 0));
}

.from-green-500{
  --tw-gradient-from:#10b981;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(16, 185, 129, 0));
}

.from-green-600{
  --tw-gradient-from:#059669;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(5, 150, 105, 0));
}

.from-green-700{
  --tw-gradient-from:#047857;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(4, 120, 87, 0));
}

.from-green-800{
  --tw-gradient-from:#065f46;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(6, 95, 70, 0));
}

.from-green-900{
  --tw-gradient-from:#064e3b;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(6, 78, 59, 0));
}

.from-blue-50{
  --tw-gradient-from:#eff6ff;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(239, 246, 255, 0));
}

.from-blue-100{
  --tw-gradient-from:#dbeafe;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(219, 234, 254, 0));
}

.from-blue-200{
  --tw-gradient-from:#bfdbfe;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(191, 219, 254, 0));
}

.from-blue-300{
  --tw-gradient-from:#93c5fd;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(147, 197, 253, 0));
}

.from-blue-400{
  --tw-gradient-from:#60a5fa;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(96, 165, 250, 0));
}

.from-blue-500{
  --tw-gradient-from:#3b82f6;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(59, 130, 246, 0));
}

.from-blue-600{
  --tw-gradient-from:#2563eb;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(37, 99, 235, 0));
}

.from-blue-700{
  --tw-gradient-from:#1d4ed8;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(29, 78, 216, 0));
}

.from-blue-800{
  --tw-gradient-from:#1e40af;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(30, 64, 175, 0));
}

.from-blue-900{
  --tw-gradient-from:#1e3a8a;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(30, 58, 138, 0));
}

.from-indigo-50{
  --tw-gradient-from:#eef2ff;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(238, 242, 255, 0));
}

.from-indigo-100{
  --tw-gradient-from:#e0e7ff;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(224, 231, 255, 0));
}

.from-indigo-200{
  --tw-gradient-from:#c7d2fe;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(199, 210, 254, 0));
}

.from-indigo-300{
  --tw-gradient-from:#a5b4fc;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(165, 180, 252, 0));
}

.from-indigo-400{
  --tw-gradient-from:#818cf8;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(129, 140, 248, 0));
}

.from-indigo-500{
  --tw-gradient-from:#6366f1;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(99, 102, 241, 0));
}

.from-indigo-600{
  --tw-gradient-from:#4f46e5;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(79, 70, 229, 0));
}

.from-indigo-700{
  --tw-gradient-from:#4338ca;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(67, 56, 202, 0));
}

.from-indigo-800{
  --tw-gradient-from:#3730a3;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(55, 48, 163, 0));
}

.from-indigo-900{
  --tw-gradient-from:#312e81;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(49, 46, 129, 0));
}

.from-purple-50{
  --tw-gradient-from:#f5f3ff;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(245, 243, 255, 0));
}

.from-purple-100{
  --tw-gradient-from:#ede9fe;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(237, 233, 254, 0));
}

.from-purple-200{
  --tw-gradient-from:#ddd6fe;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(221, 214, 254, 0));
}

.from-purple-300{
  --tw-gradient-from:#c4b5fd;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(196, 181, 253, 0));
}

.from-purple-400{
  --tw-gradient-from:#a78bfa;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(167, 139, 250, 0));
}

.from-purple-500{
  --tw-gradient-from:#8b5cf6;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(139, 92, 246, 0));
}

.from-purple-600{
  --tw-gradient-from:#7c3aed;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(124, 58, 237, 0));
}

.from-purple-700{
  --tw-gradient-from:#6d28d9;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(109, 40, 217, 0));
}

.from-purple-800{
  --tw-gradient-from:#5b21b6;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(91, 33, 182, 0));
}

.from-purple-900{
  --tw-gradient-from:#4c1d95;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(76, 29, 149, 0));
}

.from-pink-50{
  --tw-gradient-from:#fdf2f8;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(253, 242, 248, 0));
}

.from-pink-100{
  --tw-gradient-from:#fce7f3;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(252, 231, 243, 0));
}

.from-pink-200{
  --tw-gradient-from:#fbcfe8;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(251, 207, 232, 0));
}

.from-pink-300{
  --tw-gradient-from:#f9a8d4;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(249, 168, 212, 0));
}

.from-pink-400{
  --tw-gradient-from:#f472b6;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(244, 114, 182, 0));
}

.from-pink-500{
  --tw-gradient-from:#ec4899;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(236, 72, 153, 0));
}

.from-pink-600{
  --tw-gradient-from:#db2777;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(219, 39, 119, 0));
}

.from-pink-700{
  --tw-gradient-from:#be185d;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(190, 24, 93, 0));
}

.from-pink-800{
  --tw-gradient-from:#9d174d;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(157, 23, 77, 0));
}

.from-pink-900{
  --tw-gradient-from:#831843;
  --tw-gradient-stops:var(--tw-gradient-from), var(--tw-gradient-to, rgba(131, 24, 67, 0));
}

.via-transparent{
  --tw-gradient-stops:var(--tw-gradient-from), transparent, var(--tw-gradient-to, rgba(0, 0, 0, 0));
}

.via-current{
  --tw-gradient-stops:var(--tw-gradient-from), currentColor, var(--tw-gradient-to, rgba(255, 255, 255, 0));
}

.via-black{
  --tw-gradient-stops:var(--tw-gradient-from), #000, var(--tw-gradient-to, rgba(0, 0, 0, 0));
}

.via-white{
  --tw-gradient-stops:var(--tw-gradient-from), #fff, var(--tw-gradient-to, rgba(255, 255, 255, 0));
}

.via-gray-50{
  --tw-gradient-stops:var(--tw-gradient-from), #f9fafb, var(--tw-gradient-to, rgba(249, 250, 251, 0));
}

.via-gray-100{
  --tw-gradient-stops:var(--tw-gradient-from), #f3f4f6, var(--tw-gradient-to, rgba(243, 244, 246, 0));
}

.via-gray-200{
  --tw-gradient-stops:var(--tw-gradient-from), #e5e7eb, var(--tw-gradient-to, rgba(229, 231, 235, 0));
}

.via-gray-300{
  --tw-gradient-stops:var(--tw-gradient-from), #d1d5db, var(--tw-gradient-to, rgba(209, 213, 219, 0));
}

.via-gray-400{
  --tw-gradient-stops:var(--tw-gradient-from), #9ca3af, var(--tw-gradient-to, rgba(156, 163, 175, 0));
}

.via-gray-500{
  --tw-gradient-stops:var(--tw-gradient-from), #6b7280, var(--tw-gradient-to, rgba(107, 114, 128, 0));
}

.via-gray-600{
  --tw-gradient-stops:var(--tw-gradient-from), #4b5563, var(--tw-gradient-to, rgba(75, 85, 99, 0));
}

.via-gray-700{
  --tw-gradient-stops:var(--tw-gradient-from), #374151, var(--tw-gradient-to, rgba(55, 65, 81, 0));
}

.via-gray-800{
  --tw-gradient-stops:var(--tw-gradient-from), #1f2937, var(--tw-gradient-to, rgba(31, 41, 55, 0));
}

.via-gray-900{
  --tw-gradient-stops:var(--tw-gradient-from), #111827, var(--tw-gradient-to, rgba(17, 24, 39, 0));
}

.via-red-50{
  --tw-gradient-stops:var(--tw-gradient-from), #fef2f2, var(--tw-gradient-to, rgba(254, 242, 242, 0));
}

.via-red-100{
  --tw-gradient-stops:var(--tw-gradient-from), #fee2e2, var(--tw-gradient-to, rgba(254, 226, 226, 0));
}

.via-red-200{
  --tw-gradient-stops:var(--tw-gradient-from), #fecaca, var(--tw-gradient-to, rgba(254, 202, 202, 0));
}

.via-red-300{
  --tw-gradient-stops:var(--tw-gradient-from), #fca5a5, var(--tw-gradient-to, rgba(252, 165, 165, 0));
}

.via-red-400{
  --tw-gradient-stops:var(--tw-gradient-from), #f87171, var(--tw-gradient-to, rgba(248, 113, 113, 0));
}

.via-red-500{
  --tw-gradient-stops:var(--tw-gradient-from), #ef4444, var(--tw-gradient-to, rgba(239, 68, 68, 0));
}

.via-red-600{
  --tw-gradient-stops:var(--tw-gradient-from), #dc2626, var(--tw-gradient-to, rgba(220, 38, 38, 0));
}

.via-red-700{
  --tw-gradient-stops:var(--tw-gradient-from), #b91c1c, var(--tw-gradient-to, rgba(185, 28, 28, 0));
}

.via-red-800{
  --tw-gradient-stops:var(--tw-gradient-from), #991b1b, var(--tw-gradient-to, rgba(153, 27, 27, 0));
}

.via-red-900{
  --tw-gradient-stops:var(--tw-gradient-from), #7f1d1d, var(--tw-gradient-to, rgba(127, 29, 29, 0));
}

.via-yellow-50{
  --tw-gradient-stops:var(--tw-gradient-from), #fffbeb, var(--tw-gradient-to, rgba(255, 251, 235, 0));
}

.via-yellow-100{
  --tw-gradient-stops:var(--tw-gradient-from), #fef3c7, var(--tw-gradient-to, rgba(254, 243, 199, 0));
}

.via-yellow-200{
  --tw-gradient-stops:var(--tw-gradient-from), #fde68a, var(--tw-gradient-to, rgba(253, 230, 138, 0));
}

.via-yellow-300{
  --tw-gradient-stops:var(--tw-gradient-from), #fcd34d, var(--tw-gradient-to, rgba(252, 211, 77, 0));
}

.via-yellow-400{
  --tw-gradient-stops:var(--tw-gradient-from), #fbbf24, var(--tw-gradient-to, rgba(251, 191, 36, 0));
}

.via-yellow-500{
  --tw-gradient-stops:var(--tw-gradient-from), #f59e0b, var(--tw-gradient-to, rgba(245, 158, 11, 0));
}

.via-yellow-600{
  --tw-gradient-stops:var(--tw-gradient-from), #d97706, var(--tw-gradient-to, rgba(217, 119, 6, 0));
}

.via-yellow-700{
  --tw-gradient-stops:var(--tw-gradient-from), #b45309, var(--tw-gradient-to, rgba(180, 83, 9, 0));
}

.via-yellow-800{
  --tw-gradient-stops:var(--tw-gradient-from), #92400e, var(--tw-gradient-to, rgba(146, 64, 14, 0));
}

.via-yellow-900{
  --tw-gradient-stops:var(--tw-gradient-from), #78350f, var(--tw-gradient-to, rgba(120, 53, 15, 0));
}

.via-green-50{
  --tw-gradient-stops:var(--tw-gradient-from), #ecfdf5, var(--tw-gradient-to, rgba(236, 253, 245, 0));
}

.via-green-100{
  --tw-gradient-stops:var(--tw-gradient-from), #d1fae5, var(--tw-gradient-to, rgba(209, 250, 229, 0));
}

.via-green-200{
  --tw-gradient-stops:var(--tw-gradient-from), #a7f3d0, var(--tw-gradient-to, rgba(167, 243, 208, 0));
}

.via-green-300{
  --tw-gradient-stops:var(--tw-gradient-from), #6ee7b7, var(--tw-gradient-to, rgba(110, 231, 183, 0));
}

.via-green-400{
  --tw-gradient-stops:var(--tw-gradient-from), #34d399, var(--tw-gradient-to, rgba(52, 211, 153, 0));
}

.via-green-500{
  --tw-gradient-stops:var(--tw-gradient-from), #10b981, var(--tw-gradient-to, rgba(16, 185, 129, 0));
}

.via-green-600{
  --tw-gradient-stops:var(--tw-gradient-from), #059669, var(--tw-gradient-to, rgba(5, 150, 105, 0));
}

.via-green-700{
  --tw-gradient-stops:var(--tw-gradient-from), #047857, var(--tw-gradient-to, rgba(4, 120, 87, 0));
}

.via-green-800{
  --tw-gradient-stops:var(--tw-gradient-from), #065f46, var(--tw-gradient-to, rgba(6, 95, 70, 0));
}

.via-green-900{
  --tw-gradient-stops:var(--tw-gradient-from), #064e3b, var(--tw-gradient-to, rgba(6, 78, 59, 0));
}

.via-blue-50{
  --tw-gradient-stops:var(--tw-gradient-from), #eff6ff, var(--tw-gradient-to, rgba(239, 246, 255, 0));
}

.via-blue-100{
  --tw-gradient-stops:var(--tw-gradient-from), #dbeafe, var(--tw-gradient-to, rgba(219, 234, 254, 0));
}

.via-blue-200{
  --tw-gradient-stops:var(--tw-gradient-from), #bfdbfe, var(--tw-gradient-to, rgba(191, 219, 254, 0));
}

.via-blue-300{
  --tw-gradient-stops:var(--tw-gradient-from), #93c5fd, var(--tw-gradient-to, rgba(147, 197, 253, 0));
}

.via-blue-400{
  --tw-gradient-stops:var(--tw-gradient-from), #60a5fa, var(--tw-gradient-to, rgba(96, 165, 250, 0));
}

.via-blue-500{
  --tw-gradient-stops:var(--tw-gradient-from), #3b82f6, var(--tw-gradient-to, rgba(59, 130, 246, 0));
}

.via-blue-600{
  --tw-gradient-stops:var(--tw-gradient-from), #2563eb, var(--tw-gradient-to, rgba(37, 99, 235, 0));
}

.via-blue-700{
  --tw-gradient-stops:var(--tw-gradient-from), #1d4ed8, var(--tw-gradient-to, rgba(29, 78, 216, 0));
}

.via-blue-800{
  --tw-gradient-stops:var(--tw-gradient-from), #1e40af, var(--tw-gradient-to, rgba(30, 64, 175, 0));
}

.via-blue-900{
  --tw-gradient-stops:var(--tw-gradient-from), #1e3a8a, var(--tw-gradient-to, rgba(30, 58, 138, 0));
}

.via-indigo-50{
  --tw-gradient-stops:var(--tw-gradient-from), #eef2ff, var(--tw-gradient-to, rgba(238, 242, 255, 0));
}

.via-indigo-100{
  --tw-gradient-stops:var(--tw-gradient-from), #e0e7ff, var(--tw-gradient-to, rgba(224, 231, 255, 0));
}

.via-indigo-200{
  --tw-gradient-stops:var(--tw-gradient-from), #c7d2fe, var(--tw-gradient-to, rgba(199, 210, 254, 0));
}

.via-indigo-300{
  --tw-gradient-stops:var(--tw-gradient-from), #a5b4fc, var(--tw-gradient-to, rgba(165, 180, 252, 0));
}

.via-indigo-400{
  --tw-gradient-stops:var(--tw-gradient-from), #818cf8, var(--tw-gradient-to, rgba(129, 140, 248, 0));
}

.via-indigo-500{
  --tw-gradient-stops:var(--tw-gradient-from), #6366f1, var(--tw-gradient-to, rgba(99, 102, 241, 0));
}

.via-indigo-600{
  --tw-gradient-stops:var(--tw-gradient-from), #4f46e5, var(--tw-gradient-to, rgba(79, 70, 229, 0));
}

.via-indigo-700{
  --tw-gradient-stops:var(--tw-gradient-from), #4338ca, var(--tw-gradient-to, rgba(67, 56, 202, 0));
}

.via-indigo-800{
  --tw-gradient-stops:var(--tw-gradient-from), #3730a3, var(--tw-gradient-to, rgba(55, 48, 163, 0));
}

.via-indigo-900{
  --tw-gradient-stops:var(--tw-gradient-from), #312e81, var(--tw-gradient-to, rgba(49, 46, 129, 0));
}

.via-purple-50{
  --tw-gradient-stops:var(--tw-gradient-from), #f5f3ff, var(--tw-gradient-to, rgba(245, 243, 255, 0));
}

.via-purple-100{
  --tw-gradient-stops:var(--tw-gradient-from), #ede9fe, var(--tw-gradient-to, rgba(237, 233, 254, 0));
}

.via-purple-200{
  --tw-gradient-stops:var(--tw-gradient-from), #ddd6fe, var(--tw-gradient-to, rgba(221, 214, 254, 0));
}

.via-purple-300{
  --tw-gradient-stops:var(--tw-gradient-from), #c4b5fd, var(--tw-gradient-to, rgba(196, 181, 253, 0));
}

.via-purple-400{
  --tw-gradient-stops:var(--tw-gradient-from), #a78bfa, var(--tw-gradient-to, rgba(167, 139, 250, 0));
}

.via-purple-500{
  --tw-gradient-stops:var(--tw-gradient-from), #8b5cf6, var(--tw-gradient-to, rgba(139, 92, 246, 0));
}

.via-purple-600{
  --tw-gradient-stops:var(--tw-gradient-from), #7c3aed, var(--tw-gradient-to, rgba(124, 58, 237, 0));
}

.via-purple-700{
  --tw-gradient-stops:var(--tw-gradient-from), #6d28d9, var(--tw-gradient-to, rgba(109, 40, 217, 0));
}

.via-purple-800{
  --tw-gradient-stops:var(--tw-gradient-from), #5b21b6, var(--tw-gradient-to, rgba(91, 33, 182, 0));
}

.via-purple-900{
  --tw-gradient-stops:var(--tw-gradient-from), #4c1d95, var(--tw-gradient-to, rgba(76, 29, 149, 0));
}

.via-pink-50{
  --tw-gradient-stops:var(--tw-gradient-from), #fdf2f8, var(--tw-gradient-to, rgba(253, 242, 248, 0));
}

.via-pink-100{
  --tw-gradient-stops:var(--tw-gradient-from), #fce7f3, var(--tw-gradient-to, rgba(252, 231, 243, 0));
}

.via-pink-200{
  --tw-gradient-stops:var(--tw-gradient-from), #fbcfe8, var(--tw-gradient-to, rgba(251, 207, 232, 0));
}

.via-pink-300{
  --tw-gradient-stops:var(--tw-gradient-from), #f9a8d4, var(--tw-gradient-to, rgba(249, 168, 212, 0));
}

.via-pink-400{
  --tw-gradient-stops:var(--tw-gradient-from), #f472b6, var(--tw-gradient-to, rgba(244, 114, 182, 0));
}

.via-pink-500{
  --tw-gradient-stops:var(--tw-gradient-from), #ec4899, var(--tw-gradient-to, rgba(236, 72, 153, 0));
}

.via-pink-600{
  --tw-gradient-stops:var(--tw-gradient-from), #db2777, var(--tw-gradient-to, rgba(219, 39, 119, 0));
}

.via-pink-700{
  --tw-gradient-stops:var(--tw-gradient-from), #be185d, var(--tw-gradient-to, rgba(190, 24, 93, 0));
}

.via-pink-800{
  --tw-gradient-stops:var(--tw-gradient-from), #9d174d, var(--tw-gradient-to, rgba(157, 23, 77, 0));
}

.via-pink-900{
  --tw-gradient-stops:var(--tw-gradient-from), #831843, var(--tw-gradient-to, rgba(131, 24, 67, 0));
}

.to-transparent{
  --tw-gradient-to:transparent;
}

.to-current{
  --tw-gradient-to:currentColor;
}

.to-black{
  --tw-gradient-to:#000;
}

.to-white{
  --tw-gradient-to:#fff;
}

.to-gray-50{
  --tw-gradient-to:#f9fafb;
}

.to-gray-100{
  --tw-gradient-to:#f3f4f6;
}

.to-gray-200{
  --tw-gradient-to:#e5e7eb;
}

.to-gray-300{
  --tw-gradient-to:#d1d5db;
}

.to-gray-400{
  --tw-gradient-to:#9ca3af;
}

.to-gray-500{
  --tw-gradient-to:#6b7280;
}

.to-gray-600{
  --tw-gradient-to:#4b5563;
}

.to-gray-700{
  --tw-gradient-to:#374151;
}

.to-gray-800{
  --tw-gradient-to:#1f2937;
}

.to-gray-900{
  --tw-gradient-to:#111827;
}

.to-red-50{
  --tw-gradient-to:#fef2f2;
}

.to-red-100{
  --tw-gradient-to:#fee2e2;
}

.to-red-200{
  --tw-gradient-to:#fecaca;
}

.to-red-300{
  --tw-gradient-to:#fca5a5;
}

.to-red-400{
  --tw-gradient-to:#f87171;
}

.to-red-500{
  --tw-gradient-to:#ef4444;
}

.to-red-600{
  --tw-gradient-to:#dc2626;
}

.to-red-700{
  --tw-gradient-to:#b91c1c;
}

.to-red-800{
  --tw-gradient-to:#991b1b;
}

.to-red-900{
  --tw-gradient-to:#7f1d1d;
}

.to-yellow-50{
  --tw-gradient-to:#fffbeb;
}

.to-yellow-100{
  --tw-gradient-to:#fef3c7;
}

.to-yellow-200{
  --tw-gradient-to:#fde68a;
}

.to-yellow-300{
  --tw-gradient-to:#fcd34d;
}

.to-yellow-400{
  --tw-gradient-to:#fbbf24;
}

.to-yellow-500{
  --tw-gradient-to:#f59e0b;
}

.to-yellow-600{
  --tw-gradient-to:#d97706;
}

.to-yellow-700{
  --tw-gradient-to:#b45309;
}

.to-yellow-800{
  --tw-gradient-to:#92400e;
}

.to-yellow-900{
  --tw-gradient-to:#78350f;
}

.to-green-50{
  --tw-gradient-to:#ecfdf5;
}

.to-green-100{
  --tw-gradient-to:#d1fae5;
}

.to-green-200{
  --tw-gradient-to:#a7f3d0;
}

.to-green-300{
  --tw-gradient-to:#6ee7b7;
}

.to-green-400{
  --tw-gradient-to:#34d399;
}

.to-green-500{
  --tw-gradient-to:#10b981;
}

.to-green-600{
  --tw-gradient-to:#059669;
}

.to-green-700{
  --tw-gradient-to:#047857;
}

.to-green-800{
  --tw-gradient-to:#065f46;
}

.to-green-900{
  --tw-gradient-to:#064e3b;
}

.to-blue-50{
  --tw-gradient-to:#eff6ff;
}

.to-blue-100{
  --tw-gradient-to:#dbeafe;
}

.to-blue-200{
  --tw-gradient-to:#bfdbfe;
}

.to-blue-300{
  --tw-gradient-to:#93c5fd;
}

.to-blue-400{
  --tw-gradient-to:#60a5fa;
}

.to-blue-500{
  --tw-gradient-to:#3b82f6;
}

.to-blue-600{
  --tw-gradient-to:#2563eb;
}

.to-blue-700{
  --tw-gradient-to:#1d4ed8;
}

.to-blue-800{
  --tw-gradient-to:#1e40af;
}

.to-blue-900{
  --tw-gradient-to:#1e3a8a;
}

.to-indigo-50{
  --tw-gradient-to:#eef2ff;
}

.to-indigo-100{
  --tw-gradient-to:#e0e7ff;
}

.to-indigo-200{
  --tw-gradient-to:#c7d2fe;
}

.to-indigo-300{
  --tw-gradient-to:#a5b4fc;
}

.to-indigo-400{
  --tw-gradient-to:#818cf8;
}

.to-indigo-500{
  --tw-gradient-to:#6366f1;
}

.to-indigo-600{
  --tw-gradient-to:#4f46e5;
}

.to-indigo-700{
  --tw-gradient-to:#4338ca;
}

.to-indigo-800{
  --tw-gradient-to:#3730a3;
}

.to-indigo-900{
  --tw-gradient-to:#312e81;
}

.to-purple-50{
  --tw-gradient-to:#f5f3ff;
}

.to-purple-100{
  --tw-gradient-to:#ede9fe;
}

.to-purple-200{
  --tw-gradient-to:#ddd6fe;
}

.to-purple-300{
  --tw-gradient-to:#c4b5fd;
}

.to-purple-400{
  --tw-gradient-to:#a78bfa;
}

.to-purple-500{
  --tw-gradient-to:#8b5cf6;
}

.to-purple-600{
  --tw-gradient-to:#7c3aed;
}

.to-purple-700{
  --tw-gradient-to:#6d28d9;
}

.to-purple-800{
  --tw-gradient-to:#5b21b6;
}

.to-purple-900{
  --tw-gradient-to:#4c1d95;
}

.to-pink-50{
  --tw-gradient-to:#fdf2f8;
}

.to-pink-100{
  --tw-gradient-to:#fce7f3;
}

.to-pink-200{
  --tw-gradient-to:#fbcfe8;
}

.to-pink-300{
  --tw-gradient-to:#f9a8d4;
}

.to-pink-400{
  --tw-gradient-to:#f472b6;
}

.to-pink-500{
  --tw-gradient-to:#ec4899;
}

.to-pink-600{
  --tw-gradient-to:#db2777;
}

.to-pink-700{
  --tw-gradient-to:#be185d;
}

.to-pink-800{
  --tw-gradient-to:#9d174d;
}

.to-pink-900{
  --tw-gradient-to:#831843;
}

.decoration-slice{
  -webkit-box-decoration-break:slice;
          box-decoration-break:slice;
}

.decoration-clone{
  -webkit-box-decoration-break:clone;
          box-decoration-break:clone;
}

.bg-auto{
  background-size:auto;
}

.bg-cover{
  background-size:cover;
}

.bg-contain{
  background-size:contain;
}

.bg-fixed{
  background-attachment:fixed;
}

.bg-local{
  background-attachment:local;
}

.bg-scroll{
  background-attachment:scroll;
}

.bg-clip-border{
  background-clip:border-box;
}

.bg-clip-padding{
  background-clip:padding-box;
}

.bg-clip-content{
  background-clip:content-box;
}

.bg-clip-text{
  -webkit-background-clip:text;
          background-clip:text;
}

.bg-bottom{
  background-position:bottom;
}

.bg-center{
  background-position:center;
}

.bg-left{
  background-position:left;
}

.bg-left-bottom{
  background-position:left bottom;
}

.bg-left-top{
  background-position:left top;
}

.bg-right{
  background-position:right;
}

.bg-right-bottom{
  background-position:right bottom;
}

.bg-right-top{
  background-position:right top;
}

.bg-top{
  background-position:top;
}

.bg-repeat{
  background-repeat:repeat;
}

.bg-no-repeat{
  background-repeat:no-repeat;
}

.bg-repeat-x{
  background-repeat:repeat-x;
}

.bg-repeat-y{
  background-repeat:repeat-y;
}

.bg-repeat-round{
  background-repeat:round;
}

.bg-repeat-space{
  background-repeat:space;
}

.bg-origin-border{
  background-origin:border-box;
}

.bg-origin-padding{
  background-origin:padding-box;
}

.bg-origin-content{
  background-origin:content-box;
}

.fill-current{
  fill:currentColor;
}

.stroke-current{
  stroke:currentColor;
}

.stroke-0{
  stroke-width:0;
}

.stroke-1{
  stroke-width:1;
}

.stroke-2{
  stroke-width:2;
}

.object-contain{
  -o-object-fit:contain;
     object-fit:contain;
}

.object-cover{
  -o-object-fit:cover;
     object-fit:cover;
}

.object-fill{
  -o-object-fit:fill;
     object-fit:fill;
}

.object-none{
  -o-object-fit:none;
     object-fit:none;
}

.object-scale-down{
  -o-object-fit:scale-down;
     object-fit:scale-down;
}

.object-bottom{
  -o-object-position:bottom;
     object-position:bottom;
}

.object-center{
  -o-object-position:center;
     object-position:center;
}

.object-left{
  -o-object-position:left;
     object-position:left;
}

.object-left-bottom{
  -o-object-position:left bottom;
     object-position:left bottom;
}

.object-left-top{
  -o-object-position:left top;
     object-position:left top;
}

.object-right{
  -o-object-position:right;
     object-position:right;
}

.object-right-bottom{
  -o-object-position:right bottom;
     object-position:right bottom;
}

.object-right-top{
  -o-object-position:right top;
     object-position:right top;
}

.object-top{
  -o-object-position:top;
     object-position:top;
}

.p-0{
  padding:0px;
}

.p-1{
  padding:0.25rem;
}

.p-2{
  padding:0.5rem;
}

.p-3{
  padding:0.75rem;
}

.p-4{
  padding:1rem;
}

.p-5{
  padding:1.25rem;
}

.p-6{
  padding:1.5rem;
}

.p-7{
  padding:1.75rem;
}

.p-8{
  padding:2rem;
}

.p-9{
  padding:2.25rem;
}

.p-10{
  padding:2.5rem;
}

.p-11{
  padding:2.75rem;
}

.p-12{
  padding:3rem;
}

.p-14{
  padding:3.5rem;
}

.p-16{
  padding:4rem;
}

.p-20{
  padding:5rem;
}

.p-24{
  padding:6rem;
}

.p-28{
  padding:7rem;
}

.p-32{
  padding:8rem;
}

.p-36{
  padding:9rem;
}

.p-40{
  padding:10rem;
}

.p-44{
  padding:11rem;
}

.p-48{
  padding:12rem;
}

.p-52{
  padding:13rem;
}

.p-56{
  padding:14rem;
}

.p-60{
  padding:15rem;
}

.p-64{
  padding:16rem;
}

.p-72{
  padding:18rem;
}

.p-80{
  padding:20rem;
}

.p-96{
  padding:24rem;
}

.p-px{
  padding:1px;
}

.px-0{
  padding-left:0px;
  padding-right:0px;
}

.px-1{
  padding-left:0.25rem;
  padding-right:0.25rem;
}

.px-2{
  padding-left:0.5rem;
  padding-right:0.5rem;
}

.px-3{
  padding-left:0.75rem;
  padding-right:0.75rem;
}

.px-4{
  padding-left:1rem;
  padding-right:1rem;
}

.px-5{
  padding-left:1.25rem;
  padding-right:1.25rem;
}

.px-6{
  padding-left:1.5rem;
  padding-right:1.5rem;
}

.px-7{
  padding-left:1.75rem;
  padding-right:1.75rem;
}

.px-8{
  padding-left:2rem;
  padding-right:2rem;
}

.px-9{
  padding-left:2.25rem;
  padding-right:2.25rem;
}

.px-10{
  padding-left:2.5rem;
  padding-right:2.5rem;
}

.px-11{
  padding-left:2.75rem;
  padding-right:2.75rem;
}

.px-12{
  padding-left:3rem;
  padding-right:3rem;
}

.px-14{
  padding-left:3.5rem;
  padding-right:3.5rem;
}

.px-16{
  padding-left:4rem;
  padding-right:4rem;
}

.px-20{
  padding-left:5rem;
  padding-right:5rem;
}

.px-24{
  padding-left:6rem;
  padding-right:6rem;
}

.px-28{
  padding-left:7rem;
  padding-right:7rem;
}

.px-32{
  padding-left:8rem;
  padding-right:8rem;
}

.px-36{
  padding-left:9rem;
  padding-right:9rem;
}

.px-40{
  padding-left:10rem;
  padding-right:10rem;
}

.px-44{
  padding-left:11rem;
  padding-right:11rem;
}

.px-48{
  padding-left:12rem;
  padding-right:12rem;
}

.px-52{
  padding-left:13rem;
  padding-right:13rem;
}

.px-56{
  padding-left:14rem;
  padding-right:14rem;
}

.px-60{
  padding-left:15rem;
  padding-right:15rem;
}

.px-64{
  padding-left:16rem;
  padding-right:16rem;
}

.px-72{
  padding-left:18rem;
  padding-right:18rem;
}

.px-80{
  padding-left:20rem;
  padding-right:20rem;
}

.px-96{
  padding-left:24rem;
  padding-right:24rem;
}

.px-px{
  padding-left:1px;
  padding-right:1px;
}

.px-2\.5{
  padding-left:0.625rem;
  padding-right:0.625rem;
}

.py-0{
  padding-top:0px;
  padding-bottom:0px;
}

.py-1{
  padding-top:0.25rem;
  padding-bottom:0.25rem;
}

.py-2{
  padding-top:0.5rem;
  padding-bottom:0.5rem;
}

.py-3{
  padding-top:0.75rem;
  padding-bottom:0.75rem;
}

.py-4{
  padding-top:1rem;
  padding-bottom:1rem;
}

.py-5{
  padding-top:1.25rem;
  padding-bottom:1.25rem;
}

.py-6{
  padding-top:1.5rem;
  padding-bottom:1.5rem;
}

.py-7{
  padding-top:1.75rem;
  padding-bottom:1.75rem;
}

.py-8{
  padding-top:2rem;
  padding-bottom:2rem;
}

.py-9{
  padding-top:2.25rem;
  padding-bottom:2.25rem;
}

.py-10{
  padding-top:2.5rem;
  padding-bottom:2.5rem;
}

.py-11{
  padding-top:2.75rem;
  padding-bottom:2.75rem;
}

.py-12{
  padding-top:3rem;
  padding-bottom:3rem;
}

.py-14{
  padding-top:3.5rem;
  padding-bottom:3.5rem;
}

.py-16{
  padding-top:4rem;
  padding-bottom:4rem;
}

.py-20{
  padding-top:5rem;
  padding-bottom:5rem;
}

.py-24{
  padding-top:6rem;
  padding-bottom:6rem;
}

.py-28{
  padding-top:7rem;
  padding-bottom:7rem;
}

.py-32{
  padding-top:8rem;
  padding-bottom:8rem;
}

.py-36{
  padding-top:9rem;
  padding-bottom:9rem;
}

.py-40{
  padding-top:10rem;
  padding-bottom:10rem;
}

.py-44{
  padding-top:11rem;
  padding-bottom:11rem;
}

.py-48{
  padding-top:12rem;
  padding-bottom:12rem;
}

.py-52{
  padding-top:13rem;
  padding-bottom:13rem;
}

.py-56{
  padding-top:14rem;
  padding-bottom:14rem;
}

.py-60{
  padding-top:15rem;
  padding-bottom:15rem;
}

.py-64{
  padding-top:16rem;
  padding-bottom:16rem;
}

.py-72{
  padding-top:18rem;
  padding-bottom:18rem;
}

.py-80{
  padding-top:20rem;
  padding-bottom:20rem;
}

.py-96{
  padding-top:24rem;
  padding-bottom:24rem;
}

.py-px{
  padding-top:1px;
  padding-bottom:1px;
}

.py-0\.5{
  padding-top:0.125rem;
  padding-bottom:0.125rem;
}

.pt-0{
  padding-top:0px;
}

.pt-1{
  padding-top:0.25rem;
}

.pt-2{
  padding-top:0.5rem;
}

.pt-3{
  padding-top:0.75rem;
}

.pt-4{
  padding-top:1rem;
}

.pt-5{
  padding-top:1.25rem;
}

.pt-6{
  padding-top:1.5rem;
}

.pt-7{
  padding-top:1.75rem;
}

.pt-8{
  padding-top:2rem;
}

.pt-9{
  padding-top:2.25rem;
}

.pt-10{
  padding-top:2.5rem;
}

.pt-11{
  padding-top:2.75rem;
}

.pt-12{
  padding-top:3rem;
}

.pt-14{
  padding-top:3.5rem;
}

.pt-16{
  padding-top:4rem;
}

.pt-20{
  padding-top:5rem;
}

.pt-24{
  padding-top:6rem;
}

.pt-28{
  padding-top:7rem;
}

.pt-32{
  padding-top:8rem;
}

.pt-36{
  padding-top:9rem;
}

.pt-40{
  padding-top:10rem;
}

.pt-44{
  padding-top:11rem;
}

.pt-48{
  padding-top:12rem;
}

.pt-52{
  padding-top:13rem;
}

.pt-56{
  padding-top:14rem;
}

.pt-60{
  padding-top:15rem;
}

.pt-64{
  padding-top:16rem;
}

.pt-72{
  padding-top:18rem;
}

.pt-80{
  padding-top:20rem;
}

.pt-96{
  padding-top:24rem;
}

.pt-px{
  padding-top:1px;
}

.pr-0{
  padding-right:0px;
}

.pr-1{
  padding-right:0.25rem;
}

.pr-2{
  padding-right:0.5rem;
}

.pr-3{
  padding-right:0.75rem;
}

.pr-4{
  padding-right:1rem;
}

.pr-5{
  padding-right:1.25rem;
}

.pr-6{
  padding-right:1.5rem;
}

.pr-7{
  padding-right:1.75rem;
}

.pr-8{
  padding-right:2rem;
}

.pr-9{
  padding-right:2.25rem;
}

.pr-10{
  padding-right:2.5rem;
}

.pr-11{
  padding-right:2.75rem;
}

.pr-12{
  padding-right:3rem;
}

.pr-14{
  padding-right:3.5rem;
}

.pr-16{
  padding-right:4rem;
}

.pr-20{
  padding-right:5rem;
}

.pr-24{
  padding-right:6rem;
}

.pr-28{
  padding-right:7rem;
}

.pr-32{
  padding-right:8rem;
}

.pr-36{
  padding-right:9rem;
}

.pr-40{
  padding-right:10rem;
}

.pr-44{
  padding-right:11rem;
}

.pr-48{
  padding-right:12rem;
}

.pr-52{
  padding-right:13rem;
}

.pr-56{
  padding-right:14rem;
}

.pr-60{
  padding-right:15rem;
}

.pr-64{
  padding-right:16rem;
}

.pr-72{
  padding-right:18rem;
}

.pr-80{
  padding-right:20rem;
}

.pr-96{
  padding-right:24rem;
}

.pr-px{
  padding-right:1px;
}

.pb-0{
  padding-bottom:0px;
}

.pb-1{
  padding-bottom:0.25rem;
}

.pb-2{
  padding-bottom:0.5rem;
}

.pb-3{
  padding-bottom:0.75rem;
}

.pb-4{
  padding-bottom:1rem;
}

.pb-5{
  padding-bottom:1.25rem;
}

.pb-6{
  padding-bottom:1.5rem;
}

.pb-7{
  padding-bottom:1.75rem;
}

.pb-8{
  padding-bottom:2rem;
}

.pb-9{
  padding-bottom:2.25rem;
}

.pb-10{
  padding-bottom:2.5rem;
}

.pb-11{
  padding-bottom:2.75rem;
}

.pb-12{
  padding-bottom:3rem;
}

.pb-14{
  padding-bottom:3.5rem;
}

.pb-16{
  padding-bottom:4rem;
}

.pb-20{
  padding-bottom:5rem;
}

.pb-24{
  padding-bottom:6rem;
}

.pb-28{
  padding-bottom:7rem;
}

.pb-32{
  padding-bottom:8rem;
}

.pb-36{
  padding-bottom:9rem;
}

.pb-40{
  padding-bottom:10rem;
}

.pb-44{
  padding-bottom:11rem;
}

.pb-48{
  padding-bottom:12rem;
}

.pb-52{
  padding-bottom:13rem;
}

.pb-56{
  padding-bottom:14rem;
}

.pb-60{
  padding-bottom:15rem;
}

.pb-64{
  padding-bottom:16rem;
}

.pb-72{
  padding-bottom:18rem;
}

.pb-80{
  padding-bottom:20rem;
}

.pb-96{
  padding-bottom:24rem;
}

.pb-px{
  padding-bottom:1px;
}

.pl-0{
  padding-left:0px;
}

.pl-1{
  padding-left:0.25rem;
}

.pl-2{
  padding-left:0.5rem;
}

.pl-3{
  padding-left:0.75rem;
}

.pl-4{
  padding-left:1rem;
}

.pl-5{
  padding-left:1.25rem;
}

.pl-6{
  padding-left:1.5rem;
}

.pl-7{
  padding-left:1.75rem;
}

.pl-8{
  padding-left:2rem;
}

.pl-9{
  padding-left:2.25rem;
}

.pl-10{
  padding-left:2.5rem;
}

.pl-11{
  padding-left:2.75rem;
}

.pl-12{
  padding-left:3rem;
}

.pl-14{
  padding-left:3.5rem;
}

.pl-16{
  padding-left:4rem;
}

.pl-20{
  padding-left:5rem;
}

.pl-24{
  padding-left:6rem;
}

.pl-28{
  padding-left:7rem;
}

.pl-32{
  padding-left:8rem;
}

.pl-36{
  padding-left:9rem;
}

.pl-40{
  padding-left:10rem;
}

.pl-44{
  padding-left:11rem;
}

.pl-48{
  padding-left:12rem;
}

.pl-52{
  padding-left:13rem;
}

.pl-56{
  padding-left:14rem;
}

.pl-60{
  padding-left:15rem;
}

.pl-64{
  padding-left:16rem;
}

.pl-72{
  padding-left:18rem;
}

.pl-80{
  padding-left:20rem;
}

.pl-96{
  padding-left:24rem;
}

.pl-px{
  padding-left:1px;
}

.text-left{
  text-align:left;
}

.text-center{
  text-align:center;
}

.text-right{
  text-align:right;
}

.text-justify{
  text-align:justify;
}

.align-baseline{
  vertical-align:baseline;
}

.align-top{
  vertical-align:top;
}

.align-middle{
  vertical-align:middle;
}

.align-bottom{
  vertical-align:bottom;
}

.align-text-top{
  vertical-align:text-top;
}

.align-text-bottom{
  vertical-align:text-bottom;
}

.font-sans{
  font-family:ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
}

.font-serif{
  font-family:ui-serif, Georgia, Cambria, "Times New Roman", Times, serif;
}

.font-mono{
  font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
}

.font-heading{
  font-family:sofia-pro, sans-serif;
}

.font-body{
  font-family:pt-serif, serif;
}

.text-xs{
  font-size:0.75rem;
  line-height:1rem;
}

.text-sm{
  font-size:0.875rem;
  line-height:1.25rem;
}

.text-base{
  font-size:1rem;
  line-height:1.5rem;
}

.text-lg{
  font-size:1.125rem;
  line-height:1.75rem;
}

.text-xl{
  font-size:1.25rem;
  line-height:1.75rem;
}

.text-2xl{
  font-size:1.5rem;
  line-height:2rem;
}

.text-3xl{
  font-size:1.875rem;
  line-height:2.25rem;
}

.text-4xl{
  font-size:2.25rem;
  line-height:2.5rem;
}

.text-5xl{
  font-size:3rem;
  line-height:1;
}

.text-6xl{
  font-size:3.75rem;
  line-height:1;
}

.text-7xl{
  font-size:4.5rem;
  line-height:1;
}

.text-8xl{
  font-size:6rem;
  line-height:1;
}

.text-9xl{
  font-size:8rem;
  line-height:1;
}

.text-smaller{
  font-size:0.8125rem;
}

.text-md{
  font-size:0.9375rem;
}

.text-1\.4xl{
  font-size:1.3125rem;
}

.text-1\.5xl{
  font-size:1.375rem;
}

.text-2\.5xl{
  font-size:1.75rem;
}

.text-3\.5xl{
  font-size:2rem;
}

.text-4\.5xl{
  font-size:2.5rem;
}

.text-display-1{
  font-size:6rem;
}

.font-thin{
  font-weight:100;
}

.font-extralight{
  font-weight:200;
}

.font-light{
  font-weight:300;
}

.font-normal{
  font-weight:400;
}

.font-medium{
  font-weight:500;
}

.font-semibold{
  font-weight:600;
}

.font-bold{
  font-weight:700;
}

.font-extrabold{
  font-weight:800;
}

.font-black{
  font-weight:900;
}

.uppercase{
  text-transform:uppercase;
}

.lowercase{
  text-transform:lowercase;
}

.capitalize{
  text-transform:capitalize;
}

.normal-case{
  text-transform:none;
}

.italic{
  font-style:italic;
}

.not-italic{
  font-style:normal;
}

.ordinal, .slashed-zero, .lining-nums, .oldstyle-nums, .proportional-nums, .tabular-nums, .diagonal-fractions, .stacked-fractions{
  --tw-ordinal:var(--tw-empty,/*!*/ /*!*/);
  --tw-slashed-zero:var(--tw-empty,/*!*/ /*!*/);
  --tw-numeric-figure:var(--tw-empty,/*!*/ /*!*/);
  --tw-numeric-spacing:var(--tw-empty,/*!*/ /*!*/);
  --tw-numeric-fraction:var(--tw-empty,/*!*/ /*!*/);
  font-variant-numeric:var(--tw-ordinal) var(--tw-slashed-zero) var(--tw-numeric-figure) var(--tw-numeric-spacing) var(--tw-numeric-fraction);
}

.normal-nums{
  font-variant-numeric:normal;
}

.ordinal{
  --tw-ordinal:ordinal;
}

.slashed-zero{
  --tw-slashed-zero:slashed-zero;
}

.lining-nums{
  --tw-numeric-figure:lining-nums;
}

.oldstyle-nums{
  --tw-numeric-figure:oldstyle-nums;
}

.proportional-nums{
  --tw-numeric-spacing:proportional-nums;
}

.tabular-nums{
  --tw-numeric-spacing:tabular-nums;
}

.diagonal-fractions{
  --tw-numeric-fraction:diagonal-fractions;
}

.stacked-fractions{
  --tw-numeric-fraction:stacked-fractions;
}

.leading-3{
  line-height:.75rem;
}

.leading-4{
  line-height:1rem;
}

.leading-5{
  line-height:1.25rem;
}

.leading-6{
  line-height:1.5rem;
}

.leading-7{
  line-height:1.75rem;
}

.leading-8{
  line-height:2rem;
}

.leading-9{
  line-height:2.25rem;
}

.leading-10{
  line-height:2.5rem;
}

.leading-none{
  line-height:1;
}

.leading-tight{
  line-height:1.25;
}

.leading-snug{
  line-height:1.375;
}

.leading-normal{
  line-height:1.5;
}

.leading-relaxed{
  line-height:1.625;
}

.leading-loose{
  line-height:2;
}

.tracking-tighter{
  letter-spacing:-0.05em;
}

.tracking-tight{
  letter-spacing:-0.025em;
}

.tracking-normal{
  letter-spacing:0em;
}

.tracking-wide{
  letter-spacing:0.025em;
}

.tracking-wider{
  letter-spacing:0.05em;
}

.tracking-widest{
  letter-spacing:0.1em;
}

.text-transparent{
  color:transparent;
}

.text-current{
  color:currentColor;
}

.text-black{
  --tw-text-opacity:1;
  color:rgba(0, 0, 0, var(--tw-text-opacity));
}

.text-white{
  --tw-text-opacity:1;
  color:rgba(255, 255, 255, var(--tw-text-opacity));
}

.text-gray-50{
  --tw-text-opacity:1;
  color:rgba(249, 250, 251, var(--tw-text-opacity));
}

.text-gray-100{
  --tw-text-opacity:1;
  color:rgba(243, 244, 246, var(--tw-text-opacity));
}

.text-gray-200{
  --tw-text-opacity:1;
  color:rgba(229, 231, 235, var(--tw-text-opacity));
}

.text-gray-300{
  --tw-text-opacity:1;
  color:rgba(209, 213, 219, var(--tw-text-opacity));
}

.text-gray-400{
  --tw-text-opacity:1;
  color:rgba(156, 163, 175, var(--tw-text-opacity));
}

.text-gray-500{
  --tw-text-opacity:1;
  color:rgba(107, 114, 128, var(--tw-text-opacity));
}

.text-gray-600{
  --tw-text-opacity:1;
  color:rgba(75, 85, 99, var(--tw-text-opacity));
}

.text-gray-700{
  --tw-text-opacity:1;
  color:rgba(55, 65, 81, var(--tw-text-opacity));
}

.text-gray-800{
  --tw-text-opacity:1;
  color:rgba(31, 41, 55, var(--tw-text-opacity));
}

.text-gray-900{
  --tw-text-opacity:1;
  color:rgba(17, 24, 39, var(--tw-text-opacity));
}

.text-red-50{
  --tw-text-opacity:1;
  color:rgba(254, 242, 242, var(--tw-text-opacity));
}

.text-red-100{
  --tw-text-opacity:1;
  color:rgba(254, 226, 226, var(--tw-text-opacity));
}

.text-red-200{
  --tw-text-opacity:1;
  color:rgba(254, 202, 202, var(--tw-text-opacity));
}

.text-red-300{
  --tw-text-opacity:1;
  color:rgba(252, 165, 165, var(--tw-text-opacity));
}

.text-red-400{
  --tw-text-opacity:1;
  color:rgba(248, 113, 113, var(--tw-text-opacity));
}

.text-red-500{
  --tw-text-opacity:1;
  color:rgba(239, 68, 68, var(--tw-text-opacity));
}

.text-red-600{
  --tw-text-opacity:1;
  color:rgba(220, 38, 38, var(--tw-text-opacity));
}

.text-red-700{
  --tw-text-opacity:1;
  color:rgba(185, 28, 28, var(--tw-text-opacity));
}

.text-red-800{
  --tw-text-opacity:1;
  color:rgba(153, 27, 27, var(--tw-text-opacity));
}

.text-red-900{
  --tw-text-opacity:1;
  color:rgba(127, 29, 29, var(--tw-text-opacity));
}

.text-yellow-50{
  --tw-text-opacity:1;
  color:rgba(255, 251, 235, var(--tw-text-opacity));
}

.text-yellow-100{
  --tw-text-opacity:1;
  color:rgba(254, 243, 199, var(--tw-text-opacity));
}

.text-yellow-200{
  --tw-text-opacity:1;
  color:rgba(253, 230, 138, var(--tw-text-opacity));
}

.text-yellow-300{
  --tw-text-opacity:1;
  color:rgba(252, 211, 77, var(--tw-text-opacity));
}

.text-yellow-400{
  --tw-text-opacity:1;
  color:rgba(251, 191, 36, var(--tw-text-opacity));
}

.text-yellow-500{
  --tw-text-opacity:1;
  color:rgba(245, 158, 11, var(--tw-text-opacity));
}

.text-yellow-600{
  --tw-text-opacity:1;
  color:rgba(217, 119, 6, var(--tw-text-opacity));
}

.text-yellow-700{
  --tw-text-opacity:1;
  color:rgba(180, 83, 9, var(--tw-text-opacity));
}

.text-yellow-800{
  --tw-text-opacity:1;
  color:rgba(146, 64, 14, var(--tw-text-opacity));
}

.text-yellow-900{
  --tw-text-opacity:1;
  color:rgba(120, 53, 15, var(--tw-text-opacity));
}

.text-green-50{
  --tw-text-opacity:1;
  color:rgba(236, 253, 245, var(--tw-text-opacity));
}

.text-green-100{
  --tw-text-opacity:1;
  color:rgba(209, 250, 229, var(--tw-text-opacity));
}

.text-green-200{
  --tw-text-opacity:1;
  color:rgba(167, 243, 208, var(--tw-text-opacity));
}

.text-green-300{
  --tw-text-opacity:1;
  color:rgba(110, 231, 183, var(--tw-text-opacity));
}

.text-green-400{
  --tw-text-opacity:1;
  color:rgba(52, 211, 153, var(--tw-text-opacity));
}

.text-green-500{
  --tw-text-opacity:1;
  color:rgba(16, 185, 129, var(--tw-text-opacity));
}

.text-green-600{
  --tw-text-opacity:1;
  color:rgba(5, 150, 105, var(--tw-text-opacity));
}

.text-green-700{
  --tw-text-opacity:1;
  color:rgba(4, 120, 87, var(--tw-text-opacity));
}

.text-green-800{
  --tw-text-opacity:1;
  color:rgba(6, 95, 70, var(--tw-text-opacity));
}

.text-green-900{
  --tw-text-opacity:1;
  color:rgba(6, 78, 59, var(--tw-text-opacity));
}

.text-blue-50{
  --tw-text-opacity:1;
  color:rgba(239, 246, 255, var(--tw-text-opacity));
}

.text-blue-100{
  --tw-text-opacity:1;
  color:rgba(219, 234, 254, var(--tw-text-opacity));
}

.text-blue-200{
  --tw-text-opacity:1;
  color:rgba(191, 219, 254, var(--tw-text-opacity));
}

.text-blue-300{
  --tw-text-opacity:1;
  color:rgba(147, 197, 253, var(--tw-text-opacity));
}

.text-blue-400{
  --tw-text-opacity:1;
  color:rgba(96, 165, 250, var(--tw-text-opacity));
}

.text-blue-500{
  --tw-text-opacity:1;
  color:rgba(59, 130, 246, var(--tw-text-opacity));
}

.text-blue-600{
  --tw-text-opacity:1;
  color:rgba(37, 99, 235, var(--tw-text-opacity));
}

.text-blue-700{
  --tw-text-opacity:1;
  color:rgba(29, 78, 216, var(--tw-text-opacity));
}

.text-blue-800{
  --tw-text-opacity:1;
  color:rgba(30, 64, 175, var(--tw-text-opacity));
}

.text-blue-900{
  --tw-text-opacity:1;
  color:rgba(30, 58, 138, var(--tw-text-opacity));
}

.text-indigo-50{
  --tw-text-opacity:1;
  color:rgba(238, 242, 255, var(--tw-text-opacity));
}

.text-indigo-100{
  --tw-text-opacity:1;
  color:rgba(224, 231, 255, var(--tw-text-opacity));
}

.text-indigo-200{
  --tw-text-opacity:1;
  color:rgba(199, 210, 254, var(--tw-text-opacity));
}

.text-indigo-300{
  --tw-text-opacity:1;
  color:rgba(165, 180, 252, var(--tw-text-opacity));
}

.text-indigo-400{
  --tw-text-opacity:1;
  color:rgba(129, 140, 248, var(--tw-text-opacity));
}

.text-indigo-500{
  --tw-text-opacity:1;
  color:rgba(99, 102, 241, var(--tw-text-opacity));
}

.text-indigo-600{
  --tw-text-opacity:1;
  color:rgba(79, 70, 229, var(--tw-text-opacity));
}

.text-indigo-700{
  --tw-text-opacity:1;
  color:rgba(67, 56, 202, var(--tw-text-opacity));
}

.text-indigo-800{
  --tw-text-opacity:1;
  color:rgba(55, 48, 163, var(--tw-text-opacity));
}

.text-indigo-900{
  --tw-text-opacity:1;
  color:rgba(49, 46, 129, var(--tw-text-opacity));
}

.text-purple-50{
  --tw-text-opacity:1;
  color:rgba(245, 243, 255, var(--tw-text-opacity));
}

.text-purple-100{
  --tw-text-opacity:1;
  color:rgba(237, 233, 254, var(--tw-text-opacity));
}

.text-purple-200{
  --tw-text-opacity:1;
  color:rgba(221, 214, 254, var(--tw-text-opacity));
}

.text-purple-300{
  --tw-text-opacity:1;
  color:rgba(196, 181, 253, var(--tw-text-opacity));
}

.text-purple-400{
  --tw-text-opacity:1;
  color:rgba(167, 139, 250, var(--tw-text-opacity));
}

.text-purple-500{
  --tw-text-opacity:1;
  color:rgba(139, 92, 246, var(--tw-text-opacity));
}

.text-purple-600{
  --tw-text-opacity:1;
  color:rgba(124, 58, 237, var(--tw-text-opacity));
}

.text-purple-700{
  --tw-text-opacity:1;
  color:rgba(109, 40, 217, var(--tw-text-opacity));
}

.text-purple-800{
  --tw-text-opacity:1;
  color:rgba(91, 33, 182, var(--tw-text-opacity));
}

.text-purple-900{
  --tw-text-opacity:1;
  color:rgba(76, 29, 149, var(--tw-text-opacity));
}

.text-pink-50{
  --tw-text-opacity:1;
  color:rgba(253, 242, 248, var(--tw-text-opacity));
}

.text-pink-100{
  --tw-text-opacity:1;
  color:rgba(252, 231, 243, var(--tw-text-opacity));
}

.text-pink-200{
  --tw-text-opacity:1;
  color:rgba(251, 207, 232, var(--tw-text-opacity));
}

.text-pink-300{
  --tw-text-opacity:1;
  color:rgba(249, 168, 212, var(--tw-text-opacity));
}

.text-pink-400{
  --tw-text-opacity:1;
  color:rgba(244, 114, 182, var(--tw-text-opacity));
}

.text-pink-500{
  --tw-text-opacity:1;
  color:rgba(236, 72, 153, var(--tw-text-opacity));
}

.text-pink-600{
  --tw-text-opacity:1;
  color:rgba(219, 39, 119, var(--tw-text-opacity));
}

.text-pink-700{
  --tw-text-opacity:1;
  color:rgba(190, 24, 93, var(--tw-text-opacity));
}

.text-pink-800{
  --tw-text-opacity:1;
  color:rgba(157, 23, 77, var(--tw-text-opacity));
}

.text-pink-900{
  --tw-text-opacity:1;
  color:rgba(131, 24, 67, var(--tw-text-opacity));
}

.text-bluelagoon-100{
  --tw-text-opacity:1;
  color:rgba(214, 229, 227, var(--tw-text-opacity));
}

.text-bluelagoon-300{
  --tw-text-opacity:1;
  color:rgba(98, 140, 145, var(--tw-text-opacity));
}

.text-bluelagoon-400{
  --tw-text-opacity:1;
  color:rgba(12, 100, 111, var(--tw-text-opacity));
}

.text-bluelagoon-500{
  --tw-text-opacity:1;
  color:rgba(6, 84, 94, var(--tw-text-opacity));
}

.text-salmon-400{
  --tw-text-opacity:1;
  color:rgba(251, 98, 90, var(--tw-text-opacity));
}

.text-squash-400{
  --tw-text-opacity:1;
  color:rgba(235, 183, 29, var(--tw-text-opacity));
}

.text-seagreen-400{
  --tw-text-opacity:1;
  color:rgba(56, 187, 160, var(--tw-text-opacity));
}

.text-neutral-400{
  --tw-text-opacity:1;
  color:rgba(146, 152, 151, var(--tw-text-opacity));
}

.text-neutral-450{
  --tw-text-opacity:1;
  color:rgba(84, 85, 84, var(--tw-text-opacity));
}

.text-neutral-500{
  --tw-text-opacity:1;
  color:rgba(52, 61, 60, var(--tw-text-opacity));
}

.text-radicalred-400{
  --tw-text-opacity:1;
  color:rgba(255, 56, 96, var(--tw-text-opacity));
}

.hover\:text-bluelagoon-300:hover{
  --tw-text-opacity:1;
  color:rgba(98, 140, 145, var(--tw-text-opacity));
}

.hover\:text-neutral-500:hover{
  --tw-text-opacity:1;
  color:rgba(52, 61, 60, var(--tw-text-opacity));
}

.text-opacity-0{
  --tw-text-opacity:0;
}

.text-opacity-5{
  --tw-text-opacity:0.05;
}

.text-opacity-10{
  --tw-text-opacity:.1;
}

.text-opacity-20{
  --tw-text-opacity:.2;
}

.text-opacity-25{
  --tw-text-opacity:0.25;
}

.text-opacity-30{
  --tw-text-opacity:.3;
}

.text-opacity-40{
  --tw-text-opacity:.4;
}

.text-opacity-50{
  --tw-text-opacity:.5;
}

.text-opacity-60{
  --tw-text-opacity:.6;
}

.text-opacity-70{
  --tw-text-opacity:.7;
}

.text-opacity-75{
  --tw-text-opacity:0.75;
}

.text-opacity-80{
  --tw-text-opacity:.8;
}

.text-opacity-90{
  --tw-text-opacity:.9;
}

.text-opacity-95{
  --tw-text-opacity:0.95;
}

.text-opacity-100{
  --tw-text-opacity:1;
}

.underline{
  text-decoration:underline;
}

.line-through{
  text-decoration:line-through;
}

.no-underline{
  text-decoration:none;
}

.antialiased{
  -webkit-font-smoothing:antialiased;
  -moz-osx-font-smoothing:grayscale;
}

.subpixel-antialiased{
  -webkit-font-smoothing:auto;
  -moz-osx-font-smoothing:auto;
}

.placeholder-neutral-500::-moz-placeholder{
  --tw-placeholder-opacity:1;
  color:rgba(52, 61, 60, var(--tw-placeholder-opacity));
}

.placeholder-neutral-500:-ms-input-placeholder{
  --tw-placeholder-opacity:1;
  color:rgba(52, 61, 60, var(--tw-placeholder-opacity));
}

.placeholder-neutral-500::placeholder{
  --tw-placeholder-opacity:1;
  color:rgba(52, 61, 60, var(--tw-placeholder-opacity));
}

.focus\:placeholder-neutral-400:focus::-moz-placeholder{
  --tw-placeholder-opacity:1;
  color:rgba(146, 152, 151, var(--tw-placeholder-opacity));
}

.focus\:placeholder-neutral-400:focus:-ms-input-placeholder{
  --tw-placeholder-opacity:1;
  color:rgba(146, 152, 151, var(--tw-placeholder-opacity));
}

.focus\:placeholder-neutral-400:focus::placeholder{
  --tw-placeholder-opacity:1;
  color:rgba(146, 152, 151, var(--tw-placeholder-opacity));
}

.opacity-0{
  opacity:0;
}

.opacity-5{
  opacity:0.05;
}

.opacity-10{
  opacity:.1;
}

.opacity-20{
  opacity:.2;
}

.opacity-25{
  opacity:0.25;
}

.opacity-30{
  opacity:.3;
}

.opacity-40{
  opacity:.4;
}

.opacity-50{
  opacity:.5;
}

.opacity-60{
  opacity:.6;
}

.opacity-70{
  opacity:.7;
}

.opacity-75{
  opacity:0.75;
}

.opacity-80{
  opacity:.8;
}

.opacity-90{
  opacity:.9;
}

.opacity-95{
  opacity:0.95;
}

.opacity-100{
  opacity:1;
}

.bg-blend-normal{
  background-blend-mode:normal;
}

.bg-blend-multiply{
  background-blend-mode:multiply;
}

.bg-blend-screen{
  background-blend-mode:screen;
}

.bg-blend-overlay{
  background-blend-mode:overlay;
}

.bg-blend-darken{
  background-blend-mode:darken;
}

.bg-blend-lighten{
  background-blend-mode:lighten;
}

.bg-blend-color-dodge{
  background-blend-mode:color-dodge;
}

.bg-blend-color-burn{
  background-blend-mode:color-burn;
}

.bg-blend-hard-light{
  background-blend-mode:hard-light;
}

.bg-blend-soft-light{
  background-blend-mode:soft-light;
}

.bg-blend-difference{
  background-blend-mode:difference;
}

.bg-blend-exclusion{
  background-blend-mode:exclusion;
}

.bg-blend-hue{
  background-blend-mode:hue;
}

.bg-blend-saturation{
  background-blend-mode:saturation;
}

.bg-blend-color{
  background-blend-mode:color;
}

.bg-blend-luminosity{
  background-blend-mode:luminosity;
}

.mix-blend-normal{
  mix-blend-mode:normal;
}

.mix-blend-multiply{
  mix-blend-mode:multiply;
}

.mix-blend-screen{
  mix-blend-mode:screen;
}

.mix-blend-overlay{
  mix-blend-mode:overlay;
}

.mix-blend-darken{
  mix-blend-mode:darken;
}

.mix-blend-lighten{
  mix-blend-mode:lighten;
}

.mix-blend-color-dodge{
  mix-blend-mode:color-dodge;
}

.mix-blend-color-burn{
  mix-blend-mode:color-burn;
}

.mix-blend-hard-light{
  mix-blend-mode:hard-light;
}

.mix-blend-soft-light{
  mix-blend-mode:soft-light;
}

.mix-blend-difference{
  mix-blend-mode:difference;
}

.mix-blend-exclusion{
  mix-blend-mode:exclusion;
}

.mix-blend-hue{
  mix-blend-mode:hue;
}

.mix-blend-saturation{
  mix-blend-mode:saturation;
}

.mix-blend-color{
  mix-blend-mode:color;
}

.mix-blend-luminosity{
  mix-blend-mode:luminosity;
}

*, ::before, ::after{
  --tw-shadow:0 0 #0000;
}

.shadow-sm{
  --tw-shadow:0 1px 2px 0 rgba(0, 0, 0, 0.05);
  box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

.shadow{
  --tw-shadow:0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
  box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

.shadow-md{
  --tw-shadow:0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
  box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

.shadow-lg{
  --tw-shadow:0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
  box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

.shadow-xl{
  --tw-shadow:0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
  box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

.shadow-2xl{
  --tw-shadow:0 25px 50px -12px rgba(0, 0, 0, 0.25);
  box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

.shadow-inner{
  --tw-shadow:inset 0 2px 4px 0 rgba(0, 0, 0, 0.06);
  box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

.shadow-none{
  --tw-shadow:0 0 #0000;
  box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

.shadow-popup_message{
  --tw-shadow:0 3px 16px 0 rgba(0, 0, 0, 0.08);
  box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

.outline-none{
  outline:2px solid transparent;
  outline-offset:2px;
}

.outline-white{
  outline:2px dotted white;
  outline-offset:2px;
}

.outline-black{
  outline:2px dotted black;
  outline-offset:2px;
}

*, ::before, ::after{
  --tw-ring-inset:var(--tw-empty,/*!*/ /*!*/);
  --tw-ring-offset-width:0px;
  --tw-ring-offset-color:#fff;
  --tw-ring-color:rgba(59, 130, 246, 0.5);
  --tw-ring-offset-shadow:0 0 #0000;
  --tw-ring-shadow:0 0 #0000;
}

.ring-0{
  --tw-ring-offset-shadow:var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow:var(--tw-ring-inset) 0 0 0 calc(0px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow:var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}

.ring-1{
  --tw-ring-offset-shadow:var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow:var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow:var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}

.ring-2{
  --tw-ring-offset-shadow:var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow:var(--tw-ring-inset) 0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow:var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}

.ring-4{
  --tw-ring-offset-shadow:var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow:var(--tw-ring-inset) 0 0 0 calc(4px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow:var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}

.ring-8{
  --tw-ring-offset-shadow:var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow:var(--tw-ring-inset) 0 0 0 calc(8px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow:var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}

.ring{
  --tw-ring-offset-shadow:var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
  --tw-ring-shadow:var(--tw-ring-inset) 0 0 0 calc(3px + var(--tw-ring-offset-width)) var(--tw-ring-color);
  box-shadow:var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}

.ring-inset{
  --tw-ring-inset:inset;
}

.ring-transparent{
  --tw-ring-color:transparent;
}

.ring-current{
  --tw-ring-color:currentColor;
}

.ring-black{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(0, 0, 0, var(--tw-ring-opacity));
}

.ring-white{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(255, 255, 255, var(--tw-ring-opacity));
}

.ring-gray-50{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(249, 250, 251, var(--tw-ring-opacity));
}

.ring-gray-100{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(243, 244, 246, var(--tw-ring-opacity));
}

.ring-gray-200{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(229, 231, 235, var(--tw-ring-opacity));
}

.ring-gray-300{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(209, 213, 219, var(--tw-ring-opacity));
}

.ring-gray-400{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(156, 163, 175, var(--tw-ring-opacity));
}

.ring-gray-500{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(107, 114, 128, var(--tw-ring-opacity));
}

.ring-gray-600{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(75, 85, 99, var(--tw-ring-opacity));
}

.ring-gray-700{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(55, 65, 81, var(--tw-ring-opacity));
}

.ring-gray-800{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(31, 41, 55, var(--tw-ring-opacity));
}

.ring-gray-900{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(17, 24, 39, var(--tw-ring-opacity));
}

.ring-red-50{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(254, 242, 242, var(--tw-ring-opacity));
}

.ring-red-100{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(254, 226, 226, var(--tw-ring-opacity));
}

.ring-red-200{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(254, 202, 202, var(--tw-ring-opacity));
}

.ring-red-300{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(252, 165, 165, var(--tw-ring-opacity));
}

.ring-red-400{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(248, 113, 113, var(--tw-ring-opacity));
}

.ring-red-500{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(239, 68, 68, var(--tw-ring-opacity));
}

.ring-red-600{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(220, 38, 38, var(--tw-ring-opacity));
}

.ring-red-700{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(185, 28, 28, var(--tw-ring-opacity));
}

.ring-red-800{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(153, 27, 27, var(--tw-ring-opacity));
}

.ring-red-900{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(127, 29, 29, var(--tw-ring-opacity));
}

.ring-yellow-50{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(255, 251, 235, var(--tw-ring-opacity));
}

.ring-yellow-100{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(254, 243, 199, var(--tw-ring-opacity));
}

.ring-yellow-200{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(253, 230, 138, var(--tw-ring-opacity));
}

.ring-yellow-300{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(252, 211, 77, var(--tw-ring-opacity));
}

.ring-yellow-400{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(251, 191, 36, var(--tw-ring-opacity));
}

.ring-yellow-500{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(245, 158, 11, var(--tw-ring-opacity));
}

.ring-yellow-600{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(217, 119, 6, var(--tw-ring-opacity));
}

.ring-yellow-700{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(180, 83, 9, var(--tw-ring-opacity));
}

.ring-yellow-800{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(146, 64, 14, var(--tw-ring-opacity));
}

.ring-yellow-900{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(120, 53, 15, var(--tw-ring-opacity));
}

.ring-green-50{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(236, 253, 245, var(--tw-ring-opacity));
}

.ring-green-100{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(209, 250, 229, var(--tw-ring-opacity));
}

.ring-green-200{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(167, 243, 208, var(--tw-ring-opacity));
}

.ring-green-300{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(110, 231, 183, var(--tw-ring-opacity));
}

.ring-green-400{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(52, 211, 153, var(--tw-ring-opacity));
}

.ring-green-500{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(16, 185, 129, var(--tw-ring-opacity));
}

.ring-green-600{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(5, 150, 105, var(--tw-ring-opacity));
}

.ring-green-700{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(4, 120, 87, var(--tw-ring-opacity));
}

.ring-green-800{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(6, 95, 70, var(--tw-ring-opacity));
}

.ring-green-900{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(6, 78, 59, var(--tw-ring-opacity));
}

.ring-blue-50{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(239, 246, 255, var(--tw-ring-opacity));
}

.ring-blue-100{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(219, 234, 254, var(--tw-ring-opacity));
}

.ring-blue-200{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(191, 219, 254, var(--tw-ring-opacity));
}

.ring-blue-300{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(147, 197, 253, var(--tw-ring-opacity));
}

.ring-blue-400{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(96, 165, 250, var(--tw-ring-opacity));
}

.ring-blue-500{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(59, 130, 246, var(--tw-ring-opacity));
}

.ring-blue-600{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(37, 99, 235, var(--tw-ring-opacity));
}

.ring-blue-700{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(29, 78, 216, var(--tw-ring-opacity));
}

.ring-blue-800{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(30, 64, 175, var(--tw-ring-opacity));
}

.ring-blue-900{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(30, 58, 138, var(--tw-ring-opacity));
}

.ring-indigo-50{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(238, 242, 255, var(--tw-ring-opacity));
}

.ring-indigo-100{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(224, 231, 255, var(--tw-ring-opacity));
}

.ring-indigo-200{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(199, 210, 254, var(--tw-ring-opacity));
}

.ring-indigo-300{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(165, 180, 252, var(--tw-ring-opacity));
}

.ring-indigo-400{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(129, 140, 248, var(--tw-ring-opacity));
}

.ring-indigo-500{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(99, 102, 241, var(--tw-ring-opacity));
}

.ring-indigo-600{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(79, 70, 229, var(--tw-ring-opacity));
}

.ring-indigo-700{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(67, 56, 202, var(--tw-ring-opacity));
}

.ring-indigo-800{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(55, 48, 163, var(--tw-ring-opacity));
}

.ring-indigo-900{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(49, 46, 129, var(--tw-ring-opacity));
}

.ring-purple-50{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(245, 243, 255, var(--tw-ring-opacity));
}

.ring-purple-100{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(237, 233, 254, var(--tw-ring-opacity));
}

.ring-purple-200{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(221, 214, 254, var(--tw-ring-opacity));
}

.ring-purple-300{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(196, 181, 253, var(--tw-ring-opacity));
}

.ring-purple-400{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(167, 139, 250, var(--tw-ring-opacity));
}

.ring-purple-500{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(139, 92, 246, var(--tw-ring-opacity));
}

.ring-purple-600{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(124, 58, 237, var(--tw-ring-opacity));
}

.ring-purple-700{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(109, 40, 217, var(--tw-ring-opacity));
}

.ring-purple-800{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(91, 33, 182, var(--tw-ring-opacity));
}

.ring-purple-900{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(76, 29, 149, var(--tw-ring-opacity));
}

.ring-pink-50{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(253, 242, 248, var(--tw-ring-opacity));
}

.ring-pink-100{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(252, 231, 243, var(--tw-ring-opacity));
}

.ring-pink-200{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(251, 207, 232, var(--tw-ring-opacity));
}

.ring-pink-300{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(249, 168, 212, var(--tw-ring-opacity));
}

.ring-pink-400{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(244, 114, 182, var(--tw-ring-opacity));
}

.ring-pink-500{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(236, 72, 153, var(--tw-ring-opacity));
}

.ring-pink-600{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(219, 39, 119, var(--tw-ring-opacity));
}

.ring-pink-700{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(190, 24, 93, var(--tw-ring-opacity));
}

.ring-pink-800{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(157, 23, 77, var(--tw-ring-opacity));
}

.ring-pink-900{
  --tw-ring-opacity:1;
  --tw-ring-color:rgba(131, 24, 67, var(--tw-ring-opacity));
}

.ring-opacity-0{
  --tw-ring-opacity:0;
}

.ring-opacity-5{
  --tw-ring-opacity:0.05;
}

.ring-opacity-10{
  --tw-ring-opacity:.1;
}

.ring-opacity-20{
  --tw-ring-opacity:.2;
}

.ring-opacity-25{
  --tw-ring-opacity:0.25;
}

.ring-opacity-30{
  --tw-ring-opacity:.3;
}

.ring-opacity-40{
  --tw-ring-opacity:.4;
}

.ring-opacity-50{
  --tw-ring-opacity:.5;
}

.ring-opacity-60{
  --tw-ring-opacity:.6;
}

.ring-opacity-70{
  --tw-ring-opacity:.7;
}

.ring-opacity-75{
  --tw-ring-opacity:0.75;
}

.ring-opacity-80{
  --tw-ring-opacity:.8;
}

.ring-opacity-90{
  --tw-ring-opacity:.9;
}

.ring-opacity-95{
  --tw-ring-opacity:0.95;
}

.ring-opacity-100{
  --tw-ring-opacity:1;
}

.ring-offset-0{
  --tw-ring-offset-width:0px;
}

.ring-offset-1{
  --tw-ring-offset-width:1px;
}

.ring-offset-2{
  --tw-ring-offset-width:2px;
}

.ring-offset-4{
  --tw-ring-offset-width:4px;
}

.ring-offset-8{
  --tw-ring-offset-width:8px;
}

.ring-offset-transparent{
  --tw-ring-offset-color:transparent;
}

.ring-offset-current{
  --tw-ring-offset-color:currentColor;
}

.ring-offset-black{
  --tw-ring-offset-color:#000;
}

.ring-offset-white{
  --tw-ring-offset-color:#fff;
}

.ring-offset-gray-50{
  --tw-ring-offset-color:#f9fafb;
}

.ring-offset-gray-100{
  --tw-ring-offset-color:#f3f4f6;
}

.ring-offset-gray-200{
  --tw-ring-offset-color:#e5e7eb;
}

.ring-offset-gray-300{
  --tw-ring-offset-color:#d1d5db;
}

.ring-offset-gray-400{
  --tw-ring-offset-color:#9ca3af;
}

.ring-offset-gray-500{
  --tw-ring-offset-color:#6b7280;
}

.ring-offset-gray-600{
  --tw-ring-offset-color:#4b5563;
}

.ring-offset-gray-700{
  --tw-ring-offset-color:#374151;
}

.ring-offset-gray-800{
  --tw-ring-offset-color:#1f2937;
}

.ring-offset-gray-900{
  --tw-ring-offset-color:#111827;
}

.ring-offset-red-50{
  --tw-ring-offset-color:#fef2f2;
}

.ring-offset-red-100{
  --tw-ring-offset-color:#fee2e2;
}

.ring-offset-red-200{
  --tw-ring-offset-color:#fecaca;
}

.ring-offset-red-300{
  --tw-ring-offset-color:#fca5a5;
}

.ring-offset-red-400{
  --tw-ring-offset-color:#f87171;
}

.ring-offset-red-500{
  --tw-ring-offset-color:#ef4444;
}

.ring-offset-red-600{
  --tw-ring-offset-color:#dc2626;
}

.ring-offset-red-700{
  --tw-ring-offset-color:#b91c1c;
}

.ring-offset-red-800{
  --tw-ring-offset-color:#991b1b;
}

.ring-offset-red-900{
  --tw-ring-offset-color:#7f1d1d;
}

.ring-offset-yellow-50{
  --tw-ring-offset-color:#fffbeb;
}

.ring-offset-yellow-100{
  --tw-ring-offset-color:#fef3c7;
}

.ring-offset-yellow-200{
  --tw-ring-offset-color:#fde68a;
}

.ring-offset-yellow-300{
  --tw-ring-offset-color:#fcd34d;
}

.ring-offset-yellow-400{
  --tw-ring-offset-color:#fbbf24;
}

.ring-offset-yellow-500{
  --tw-ring-offset-color:#f59e0b;
}

.ring-offset-yellow-600{
  --tw-ring-offset-color:#d97706;
}

.ring-offset-yellow-700{
  --tw-ring-offset-color:#b45309;
}

.ring-offset-yellow-800{
  --tw-ring-offset-color:#92400e;
}

.ring-offset-yellow-900{
  --tw-ring-offset-color:#78350f;
}

.ring-offset-green-50{
  --tw-ring-offset-color:#ecfdf5;
}

.ring-offset-green-100{
  --tw-ring-offset-color:#d1fae5;
}

.ring-offset-green-200{
  --tw-ring-offset-color:#a7f3d0;
}

.ring-offset-green-300{
  --tw-ring-offset-color:#6ee7b7;
}

.ring-offset-green-400{
  --tw-ring-offset-color:#34d399;
}

.ring-offset-green-500{
  --tw-ring-offset-color:#10b981;
}

.ring-offset-green-600{
  --tw-ring-offset-color:#059669;
}

.ring-offset-green-700{
  --tw-ring-offset-color:#047857;
}

.ring-offset-green-800{
  --tw-ring-offset-color:#065f46;
}

.ring-offset-green-900{
  --tw-ring-offset-color:#064e3b;
}

.ring-offset-blue-50{
  --tw-ring-offset-color:#eff6ff;
}

.ring-offset-blue-100{
  --tw-ring-offset-color:#dbeafe;
}

.ring-offset-blue-200{
  --tw-ring-offset-color:#bfdbfe;
}

.ring-offset-blue-300{
  --tw-ring-offset-color:#93c5fd;
}

.ring-offset-blue-400{
  --tw-ring-offset-color:#60a5fa;
}

.ring-offset-blue-500{
  --tw-ring-offset-color:#3b82f6;
}

.ring-offset-blue-600{
  --tw-ring-offset-color:#2563eb;
}

.ring-offset-blue-700{
  --tw-ring-offset-color:#1d4ed8;
}

.ring-offset-blue-800{
  --tw-ring-offset-color:#1e40af;
}

.ring-offset-blue-900{
  --tw-ring-offset-color:#1e3a8a;
}

.ring-offset-indigo-50{
  --tw-ring-offset-color:#eef2ff;
}

.ring-offset-indigo-100{
  --tw-ring-offset-color:#e0e7ff;
}

.ring-offset-indigo-200{
  --tw-ring-offset-color:#c7d2fe;
}

.ring-offset-indigo-300{
  --tw-ring-offset-color:#a5b4fc;
}

.ring-offset-indigo-400{
  --tw-ring-offset-color:#818cf8;
}

.ring-offset-indigo-500{
  --tw-ring-offset-color:#6366f1;
}

.ring-offset-indigo-600{
  --tw-ring-offset-color:#4f46e5;
}

.ring-offset-indigo-700{
  --tw-ring-offset-color:#4338ca;
}

.ring-offset-indigo-800{
  --tw-ring-offset-color:#3730a3;
}

.ring-offset-indigo-900{
  --tw-ring-offset-color:#312e81;
}

.ring-offset-purple-50{
  --tw-ring-offset-color:#f5f3ff;
}

.ring-offset-purple-100{
  --tw-ring-offset-color:#ede9fe;
}

.ring-offset-purple-200{
  --tw-ring-offset-color:#ddd6fe;
}

.ring-offset-purple-300{
  --tw-ring-offset-color:#c4b5fd;
}

.ring-offset-purple-400{
  --tw-ring-offset-color:#a78bfa;
}

.ring-offset-purple-500{
  --tw-ring-offset-color:#8b5cf6;
}

.ring-offset-purple-600{
  --tw-ring-offset-color:#7c3aed;
}

.ring-offset-purple-700{
  --tw-ring-offset-color:#6d28d9;
}

.ring-offset-purple-800{
  --tw-ring-offset-color:#5b21b6;
}

.ring-offset-purple-900{
  --tw-ring-offset-color:#4c1d95;
}

.ring-offset-pink-50{
  --tw-ring-offset-color:#fdf2f8;
}

.ring-offset-pink-100{
  --tw-ring-offset-color:#fce7f3;
}

.ring-offset-pink-200{
  --tw-ring-offset-color:#fbcfe8;
}

.ring-offset-pink-300{
  --tw-ring-offset-color:#f9a8d4;
}

.ring-offset-pink-400{
  --tw-ring-offset-color:#f472b6;
}

.ring-offset-pink-500{
  --tw-ring-offset-color:#ec4899;
}

.ring-offset-pink-600{
  --tw-ring-offset-color:#db2777;
}

.ring-offset-pink-700{
  --tw-ring-offset-color:#be185d;
}

.ring-offset-pink-800{
  --tw-ring-offset-color:#9d174d;
}

.ring-offset-pink-900{
  --tw-ring-offset-color:#831843;
}

.filter{
  --tw-blur:var(--tw-empty,/*!*/ /*!*/);
  --tw-brightness:var(--tw-empty,/*!*/ /*!*/);
  --tw-contrast:var(--tw-empty,/*!*/ /*!*/);
  --tw-grayscale:var(--tw-empty,/*!*/ /*!*/);
  --tw-hue-rotate:var(--tw-empty,/*!*/ /*!*/);
  --tw-invert:var(--tw-empty,/*!*/ /*!*/);
  --tw-saturate:var(--tw-empty,/*!*/ /*!*/);
  --tw-sepia:var(--tw-empty,/*!*/ /*!*/);
  --tw-drop-shadow:var(--tw-empty,/*!*/ /*!*/);
  filter:var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}

.filter-none{
  filter:none;
}

.blur-0{
  --tw-blur:blur(0);
}

.blur-none{
  --tw-blur:blur(0);
}

.blur-sm{
  --tw-blur:blur(4px);
}

.blur{
  --tw-blur:blur(8px);
}

.blur-md{
  --tw-blur:blur(12px);
}

.blur-lg{
  --tw-blur:blur(16px);
}

.blur-xl{
  --tw-blur:blur(24px);
}

.blur-2xl{
  --tw-blur:blur(40px);
}

.blur-3xl{
  --tw-blur:blur(64px);
}

.brightness-0{
  --tw-brightness:brightness(0);
}

.brightness-50{
  --tw-brightness:brightness(.5);
}

.brightness-75{
  --tw-brightness:brightness(.75);
}

.brightness-90{
  --tw-brightness:brightness(.9);
}

.brightness-95{
  --tw-brightness:brightness(.95);
}

.brightness-100{
  --tw-brightness:brightness(1);
}

.brightness-105{
  --tw-brightness:brightness(1.05);
}

.brightness-110{
  --tw-brightness:brightness(1.1);
}

.brightness-125{
  --tw-brightness:brightness(1.25);
}

.brightness-150{
  --tw-brightness:brightness(1.5);
}

.brightness-200{
  --tw-brightness:brightness(2);
}

.contrast-0{
  --tw-contrast:contrast(0);
}

.contrast-50{
  --tw-contrast:contrast(.5);
}

.contrast-75{
  --tw-contrast:contrast(.75);
}

.contrast-100{
  --tw-contrast:contrast(1);
}

.contrast-125{
  --tw-contrast:contrast(1.25);
}

.contrast-150{
  --tw-contrast:contrast(1.5);
}

.contrast-200{
  --tw-contrast:contrast(2);
}

.drop-shadow-sm{
  --tw-drop-shadow:drop-shadow(0 1px 1px rgba(0,0,0,0.05));
}

.drop-shadow{
  --tw-drop-shadow:drop-shadow(0 1px 2px rgba(0, 0, 0, 0.1)) drop-shadow(0 1px 1px rgba(0, 0, 0, 0.06));
}

.drop-shadow-md{
  --tw-drop-shadow:drop-shadow(0 4px 3px rgba(0, 0, 0, 0.07)) drop-shadow(0 2px 2px rgba(0, 0, 0, 0.06));
}

.drop-shadow-lg{
  --tw-drop-shadow:drop-shadow(0 10px 8px rgba(0, 0, 0, 0.04)) drop-shadow(0 4px 3px rgba(0, 0, 0, 0.1));
}

.drop-shadow-xl{
  --tw-drop-shadow:drop-shadow(0 20px 13px rgba(0, 0, 0, 0.03)) drop-shadow(0 8px 5px rgba(0, 0, 0, 0.08));
}

.drop-shadow-2xl{
  --tw-drop-shadow:drop-shadow(0 25px 25px rgba(0, 0, 0, 0.15));
}

.drop-shadow-none{
  --tw-drop-shadow:drop-shadow(0 0 #0000);
}

.grayscale-0{
  --tw-grayscale:grayscale(0);
}

.grayscale{
  --tw-grayscale:grayscale(100%);
}

.hue-rotate-0{
  --tw-hue-rotate:hue-rotate(0deg);
}

.hue-rotate-15{
  --tw-hue-rotate:hue-rotate(15deg);
}

.hue-rotate-30{
  --tw-hue-rotate:hue-rotate(30deg);
}

.hue-rotate-60{
  --tw-hue-rotate:hue-rotate(60deg);
}

.hue-rotate-90{
  --tw-hue-rotate:hue-rotate(90deg);
}

.hue-rotate-180{
  --tw-hue-rotate:hue-rotate(180deg);
}

.-hue-rotate-180{
  --tw-hue-rotate:hue-rotate(-180deg);
}

.-hue-rotate-90{
  --tw-hue-rotate:hue-rotate(-90deg);
}

.-hue-rotate-60{
  --tw-hue-rotate:hue-rotate(-60deg);
}

.-hue-rotate-30{
  --tw-hue-rotate:hue-rotate(-30deg);
}

.-hue-rotate-15{
  --tw-hue-rotate:hue-rotate(-15deg);
}

.invert-0{
  --tw-invert:invert(0);
}

.invert{
  --tw-invert:invert(100%);
}

.saturate-0{
  --tw-saturate:saturate(0);
}

.saturate-50{
  --tw-saturate:saturate(.5);
}

.saturate-100{
  --tw-saturate:saturate(1);
}

.saturate-150{
  --tw-saturate:saturate(1.5);
}

.saturate-200{
  --tw-saturate:saturate(2);
}

.sepia-0{
  --tw-sepia:sepia(0);
}

.sepia{
  --tw-sepia:sepia(100%);
}

.backdrop-filter{
  --tw-backdrop-blur:var(--tw-empty,/*!*/ /*!*/);
  --tw-backdrop-brightness:var(--tw-empty,/*!*/ /*!*/);
  --tw-backdrop-contrast:var(--tw-empty,/*!*/ /*!*/);
  --tw-backdrop-grayscale:var(--tw-empty,/*!*/ /*!*/);
  --tw-backdrop-hue-rotate:var(--tw-empty,/*!*/ /*!*/);
  --tw-backdrop-invert:var(--tw-empty,/*!*/ /*!*/);
  --tw-backdrop-opacity:var(--tw-empty,/*!*/ /*!*/);
  --tw-backdrop-saturate:var(--tw-empty,/*!*/ /*!*/);
  --tw-backdrop-sepia:var(--tw-empty,/*!*/ /*!*/);
  -webkit-backdrop-filter:var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia);
          backdrop-filter:var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia);
}

.backdrop-filter-none{
  -webkit-backdrop-filter:none;
          backdrop-filter:none;
}

.backdrop-blur-0{
  --tw-backdrop-blur:blur(0);
}

.backdrop-blur-none{
  --tw-backdrop-blur:blur(0);
}

.backdrop-blur-sm{
  --tw-backdrop-blur:blur(4px);
}

.backdrop-blur{
  --tw-backdrop-blur:blur(8px);
}

.backdrop-blur-md{
  --tw-backdrop-blur:blur(12px);
}

.backdrop-blur-lg{
  --tw-backdrop-blur:blur(16px);
}

.backdrop-blur-xl{
  --tw-backdrop-blur:blur(24px);
}

.backdrop-blur-2xl{
  --tw-backdrop-blur:blur(40px);
}

.backdrop-blur-3xl{
  --tw-backdrop-blur:blur(64px);
}

.backdrop-brightness-0{
  --tw-backdrop-brightness:brightness(0);
}

.backdrop-brightness-50{
  --tw-backdrop-brightness:brightness(.5);
}

.backdrop-brightness-75{
  --tw-backdrop-brightness:brightness(.75);
}

.backdrop-brightness-90{
  --tw-backdrop-brightness:brightness(.9);
}

.backdrop-brightness-95{
  --tw-backdrop-brightness:brightness(.95);
}

.backdrop-brightness-100{
  --tw-backdrop-brightness:brightness(1);
}

.backdrop-brightness-105{
  --tw-backdrop-brightness:brightness(1.05);
}

.backdrop-brightness-110{
  --tw-backdrop-brightness:brightness(1.1);
}

.backdrop-brightness-125{
  --tw-backdrop-brightness:brightness(1.25);
}

.backdrop-brightness-150{
  --tw-backdrop-brightness:brightness(1.5);
}

.backdrop-brightness-200{
  --tw-backdrop-brightness:brightness(2);
}

.backdrop-contrast-0{
  --tw-backdrop-contrast:contrast(0);
}

.backdrop-contrast-50{
  --tw-backdrop-contrast:contrast(.5);
}

.backdrop-contrast-75{
  --tw-backdrop-contrast:contrast(.75);
}

.backdrop-contrast-100{
  --tw-backdrop-contrast:contrast(1);
}

.backdrop-contrast-125{
  --tw-backdrop-contrast:contrast(1.25);
}

.backdrop-contrast-150{
  --tw-backdrop-contrast:contrast(1.5);
}

.backdrop-contrast-200{
  --tw-backdrop-contrast:contrast(2);
}

.backdrop-grayscale-0{
  --tw-backdrop-grayscale:grayscale(0);
}

.backdrop-grayscale{
  --tw-backdrop-grayscale:grayscale(100%);
}

.backdrop-hue-rotate-0{
  --tw-backdrop-hue-rotate:hue-rotate(0deg);
}

.backdrop-hue-rotate-15{
  --tw-backdrop-hue-rotate:hue-rotate(15deg);
}

.backdrop-hue-rotate-30{
  --tw-backdrop-hue-rotate:hue-rotate(30deg);
}

.backdrop-hue-rotate-60{
  --tw-backdrop-hue-rotate:hue-rotate(60deg);
}

.backdrop-hue-rotate-90{
  --tw-backdrop-hue-rotate:hue-rotate(90deg);
}

.backdrop-hue-rotate-180{
  --tw-backdrop-hue-rotate:hue-rotate(180deg);
}

.-backdrop-hue-rotate-180{
  --tw-backdrop-hue-rotate:hue-rotate(-180deg);
}

.-backdrop-hue-rotate-90{
  --tw-backdrop-hue-rotate:hue-rotate(-90deg);
}

.-backdrop-hue-rotate-60{
  --tw-backdrop-hue-rotate:hue-rotate(-60deg);
}

.-backdrop-hue-rotate-30{
  --tw-backdrop-hue-rotate:hue-rotate(-30deg);
}

.-backdrop-hue-rotate-15{
  --tw-backdrop-hue-rotate:hue-rotate(-15deg);
}

.backdrop-invert-0{
  --tw-backdrop-invert:invert(0);
}

.backdrop-invert{
  --tw-backdrop-invert:invert(100%);
}

.backdrop-opacity-0{
  --tw-backdrop-opacity:opacity(0);
}

.backdrop-opacity-5{
  --tw-backdrop-opacity:opacity(0.05);
}

.backdrop-opacity-10{
  --tw-backdrop-opacity:opacity(.1);
}

.backdrop-opacity-20{
  --tw-backdrop-opacity:opacity(.2);
}

.backdrop-opacity-25{
  --tw-backdrop-opacity:opacity(0.25);
}

.backdrop-opacity-30{
  --tw-backdrop-opacity:opacity(.3);
}

.backdrop-opacity-40{
  --tw-backdrop-opacity:opacity(.4);
}

.backdrop-opacity-50{
  --tw-backdrop-opacity:opacity(.5);
}

.backdrop-opacity-60{
  --tw-backdrop-opacity:opacity(.6);
}

.backdrop-opacity-70{
  --tw-backdrop-opacity:opacity(.7);
}

.backdrop-opacity-75{
  --tw-backdrop-opacity:opacity(0.75);
}

.backdrop-opacity-80{
  --tw-backdrop-opacity:opacity(.8);
}

.backdrop-opacity-90{
  --tw-backdrop-opacity:opacity(.9);
}

.backdrop-opacity-95{
  --tw-backdrop-opacity:opacity(0.95);
}

.backdrop-opacity-100{
  --tw-backdrop-opacity:opacity(1);
}

.backdrop-saturate-0{
  --tw-backdrop-saturate:saturate(0);
}

.backdrop-saturate-50{
  --tw-backdrop-saturate:saturate(.5);
}

.backdrop-saturate-100{
  --tw-backdrop-saturate:saturate(1);
}

.backdrop-saturate-150{
  --tw-backdrop-saturate:saturate(1.5);
}

.backdrop-saturate-200{
  --tw-backdrop-saturate:saturate(2);
}

.backdrop-sepia-0{
  --tw-backdrop-sepia:sepia(0);
}

.backdrop-sepia{
  --tw-backdrop-sepia:sepia(100%);
}

.transition-none{
  transition-property:none;
}

.transition-all{
  transition-property:all;
  transition-timing-function:cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration:150ms;
}

.transition{
  transition-property:background-color, border-color, color, fill, stroke, opacity, box-shadow, transform, filter, -webkit-backdrop-filter;
  transition-property:background-color, border-color, color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter;
  transition-property:background-color, border-color, color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter, -webkit-backdrop-filter;
  transition-timing-function:cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration:150ms;
}

.transition-colors{
  transition-property:background-color, border-color, color, fill, stroke;
  transition-timing-function:cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration:150ms;
}

.transition-opacity{
  transition-property:opacity;
  transition-timing-function:cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration:150ms;
}

.transition-shadow{
  transition-property:box-shadow;
  transition-timing-function:cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration:150ms;
}

.transition-transform{
  transition-property:transform;
  transition-timing-function:cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration:150ms;
}

.delay-75{
  transition-delay:75ms;
}

.delay-100{
  transition-delay:100ms;
}

.delay-150{
  transition-delay:150ms;
}

.delay-200{
  transition-delay:200ms;
}

.delay-300{
  transition-delay:300ms;
}

.delay-500{
  transition-delay:500ms;
}

.delay-700{
  transition-delay:700ms;
}

.delay-1000{
  transition-delay:1000ms;
}

.duration-75{
  transition-duration:75ms;
}

.duration-100{
  transition-duration:100ms;
}

.duration-150{
  transition-duration:150ms;
}

.duration-200{
  transition-duration:200ms;
}

.duration-300{
  transition-duration:300ms;
}

.duration-500{
  transition-duration:500ms;
}

.duration-700{
  transition-duration:700ms;
}

.duration-1000{
  transition-duration:1000ms;
}

.ease-linear{
  transition-timing-function:linear;
}

.ease-in{
  transition-timing-function:cubic-bezier(0.4, 0, 1, 1);
}

.ease-out{
  transition-timing-function:cubic-bezier(0, 0, 0.2, 1);
}

.ease-in-out{
  transition-timing-function:cubic-bezier(0.4, 0, 0.2, 1);
}

.action-icon{
  cursor:pointer
}

.nav-text-center-adjusted{
  padding:.6875rem .5rem;
  line-height:1
}

@media (min-width: 360px){
  .xs\:pl-0{
    padding-left:0px;
  }
}

@media (min-width: 600px){
  .sm\:mx-n6{
    margin-left:-1.5rem;
    margin-right:-1.5rem;
  }

  .sm\:mt-0{
    margin-top:0px;
  }

  .sm\:mt-1{
    margin-top:0.25rem;
  }

  .sm\:mt-8{
    margin-top:2rem;
  }

  .sm\:mt-9{
    margin-top:2.25rem;
  }

  .sm\:mt-10{
    margin-top:2.5rem;
  }

  .sm\:mt-16{
    margin-top:4rem;
  }

  .sm\:mr-4{
    margin-right:1rem;
  }

  .sm\:mr-10{
    margin-right:2.5rem;
  }

  .sm\:mb-0{
    margin-bottom:0px;
  }

  .sm\:mb-6{
    margin-bottom:1.5rem;
  }

  .sm\:ml-4{
    margin-left:1rem;
  }

  .sm\:ml-8{
    margin-left:2rem;
  }

  .sm\:ml-10{
    margin-left:2.5rem;
  }

  .sm\:block{
    display:block;
  }

  .sm\:flex{
    display:flex;
  }

  .sm\:hidden{
    display:none;
  }

  .sm\:h-16{
    height:4rem;
  }

  .sm\:w-16{
    width:4rem;
  }

  .sm\:w-32{
    width:8rem;
  }

  .sm\:w-auto{
    width:auto;
  }

  .sm\:w-1\/2{
    width:50%;
  }

  .sm\:w-2\/4{
    width:50%;
  }

  .sm\:w-4\/5{
    width:80%;
  }

  .sm\:w-3\/6{
    width:50%;
  }

  .sm\:w-6\/12{
    width:50%;
  }

  .sm\:flex-row{
    flex-direction:row;
  }

  .sm\:flex-row-reverse{
    flex-direction:row-reverse;
  }

  .sm\:items-end{
    align-items:flex-end;
  }

  .sm\:justify-start{
    justify-content:flex-start;
  }

  .sm\:justify-end{
    justify-content:flex-end;
  }

  .sm\:justify-between{
    justify-content:space-between;
  }

  .sm\:self-center{
    align-self:center;
  }

  .sm\:whitespace-nowrap{
    white-space:nowrap;
  }

  .sm\:p-4{
    padding:1rem;
  }

  .sm\:p-10{
    padding:2.5rem;
  }

  .sm\:px-3{
    padding-left:0.75rem;
    padding-right:0.75rem;
  }

  .sm\:px-4{
    padding-left:1rem;
    padding-right:1rem;
  }

  .sm\:px-6{
    padding-left:1.5rem;
    padding-right:1.5rem;
  }

  .sm\:px-8{
    padding-left:2rem;
    padding-right:2rem;
  }

  .sm\:px-14{
    padding-left:3.5rem;
    padding-right:3.5rem;
  }

  .sm\:px-18{
    padding-left:4.5rem;
    padding-right:4.5rem;
  }

  .sm\:py-12{
    padding-top:3rem;
    padding-bottom:3rem;
  }

  .sm\:pt-2{
    padding-top:0.5rem;
  }

  .sm\:pr-10{
    padding-right:2.5rem;
  }

  .sm\:pb-11{
    padding-bottom:2.75rem;
  }

  .sm\:pb-40{
    padding-bottom:10rem;
  }

  .sm\:pl-4{
    padding-left:1rem;
  }

  .sm\:pl-25{
    padding-left:6.25rem;
  }

  .sm\:text-sm{
    font-size:0.875rem;
    line-height:1.25rem;
  }

  .sm\:text-md{
    font-size:0.9375rem;
  }

  .sm\:font-semibold{
    font-weight:600;
  }
}

@media (min-width: 800px){
}

@media (min-width: 1024px){
  .md\:static{
    position:static;
  }

  .md\:mx-0{
    margin-left:0px;
    margin-right:0px;
  }

  .md\:mt-0{
    margin-top:0px;
  }

  .md\:mt-4{
    margin-top:1rem;
  }

  .md\:mt-8{
    margin-top:2rem;
  }

  .md\:mt-12{
    margin-top:3rem;
  }

  .md\:mt-16{
    margin-top:4rem;
  }

  .md\:mr-4{
    margin-right:1rem;
  }

  .md\:mr-6{
    margin-right:1.5rem;
  }

  .md\:mr-8{
    margin-right:2rem;
  }

  .md\:mr-12{
    margin-right:3rem;
  }

  .md\:mr-16{
    margin-right:4rem;
  }

  .md\:mr-32{
    margin-right:8rem;
  }

  .md\:mb-0{
    margin-bottom:0px;
  }

  .md\:mb-3{
    margin-bottom:0.75rem;
  }

  .md\:mb-6{
    margin-bottom:1.5rem;
  }

  .md\:mb-14{
    margin-bottom:3.5rem;
  }

  .md\:ml-4{
    margin-left:1rem;
  }

  .md\:ml-6{
    margin-left:1.5rem;
  }

  .md\:ml-9{
    margin-left:2.25rem;
  }

  .md\:ml-10{
    margin-left:2.5rem;
  }

  .md\:ml-12{
    margin-left:3rem;
  }

  .md\:block{
    display:block;
  }

  .md\:inline{
    display:inline;
  }

  .md\:flex{
    display:flex;
  }

  .md\:hidden{
    display:none;
  }

  .md\:h-20{
    height:5rem;
  }

  .md\:h-24{
    height:6rem;
  }

  .md\:h-32{
    height:8rem;
  }

  .md\:h-auto{
    height:auto;
  }

  .md\:w-20{
    width:5rem;
  }

  .md\:w-40{
    width:10rem;
  }

  .md\:w-64{
    width:16rem;
  }

  .md\:w-auto{
    width:auto;
  }

  .md\:w-1\/2{
    width:50%;
  }

  .md\:w-1\/3{
    width:33.333333%;
  }

  .md\:w-2\/3{
    width:66.666667%;
  }

  .md\:w-2\/4{
    width:50%;
  }

  .md\:w-3\/4{
    width:75%;
  }

  .md\:w-2\/5{
    width:40%;
  }

  .md\:w-3\/5{
    width:60%;
  }

  .md\:w-2\/6{
    width:33.333333%;
  }

  .md\:w-3\/6{
    width:50%;
  }

  .md\:w-4\/12{
    width:33.333333%;
  }

  .md\:min-w-65\.5{
    min-width:16.375rem;
  }

  .md\:flex-row{
    flex-direction:row;
  }

  .md\:flex-row-reverse{
    flex-direction:row-reverse;
  }

  .md\:flex-col{
    flex-direction:column;
  }

  .md\:items-start{
    align-items:flex-start;
  }

  .md\:items-end{
    align-items:flex-end;
  }

  .md\:items-center{
    align-items:center;
  }

  .md\:justify-start{
    justify-content:flex-start;
  }

  .md\:justify-end{
    justify-content:flex-end;
  }

  .md\:justify-between{
    justify-content:space-between;
  }

  .md\:p-0{
    padding:0px;
  }

  .md\:p-8{
    padding:2rem;
  }

  .md\:p-12{
    padding:3rem;
  }

  .md\:p-16{
    padding:4rem;
  }

  .md\:px-0{
    padding-left:0px;
    padding-right:0px;
  }

  .md\:px-5{
    padding-left:1.25rem;
    padding-right:1.25rem;
  }

  .md\:px-6{
    padding-left:1.5rem;
    padding-right:1.5rem;
  }

  .md\:px-8{
    padding-left:2rem;
    padding-right:2rem;
  }

  .md\:px-10{
    padding-left:2.5rem;
    padding-right:2.5rem;
  }

  .md\:px-12{
    padding-left:3rem;
    padding-right:3rem;
  }

  .md\:px-16{
    padding-left:4rem;
    padding-right:4rem;
  }

  .md\:px-18{
    padding-left:4.5rem;
    padding-right:4.5rem;
  }

  .md\:px-24{
    padding-left:6rem;
    padding-right:6rem;
  }

  .md\:py-10{
    padding-top:2.5rem;
    padding-bottom:2.5rem;
  }

  .md\:pr-0{
    padding-right:0px;
  }

  .md\:pr-6{
    padding-right:1.5rem;
  }

  .md\:pr-10{
    padding-right:2.5rem;
  }

  .md\:pr-12{
    padding-right:3rem;
  }

  .md\:pr-24{
    padding-right:6rem;
  }

  .md\:pr-32{
    padding-right:8rem;
  }

  .md\:pb-8{
    padding-bottom:2rem;
  }

  .md\:pb-14{
    padding-bottom:3.5rem;
  }

  .md\:pb-16{
    padding-bottom:4rem;
  }

  .md\:pb-18{
    padding-bottom:4.5rem;
  }

  .md\:pl-2{
    padding-left:0.5rem;
  }

  .md\:pl-6{
    padding-left:1.5rem;
  }

  .md\:pl-10{
    padding-left:2.5rem;
  }

  .md\:pl-18{
    padding-left:4.5rem;
  }

  .md\:text-left{
    text-align:left;
  }

  .md\:text-xl{
    font-size:1.25rem;
    line-height:1.75rem;
  }

  .md\:text-2xl{
    font-size:1.5rem;
    line-height:2rem;
  }

  .md\:text-3xl{
    font-size:1.875rem;
    line-height:2.25rem;
  }

  .md\:text-4xl{
    font-size:2.25rem;
    line-height:2.5rem;
  }

  .md\:text-5xl{
    font-size:3rem;
    line-height:1;
  }

  .md\:text-2\.5xl{
    font-size:1.75rem;
  }
}

@media (min-width: 1366px){
  .lg\:top-20{
    top:5rem;
  }

  .lg\:my-0{
    margin-top:0px;
    margin-bottom:0px;
  }

  .lg\:mt-8{
    margin-top:2rem;
  }

  .lg\:mr-8{
    margin-right:2rem;
  }

  .lg\:mr-16{
    margin-right:4rem;
  }

  .lg\:mb-0{
    margin-bottom:0px;
  }

  .lg\:mb-6{
    margin-bottom:1.5rem;
  }

  .lg\:ml-16{
    margin-left:4rem;
  }

  .lg\:block{
    display:block;
  }

  .lg\:flex{
    display:flex;
  }

  .lg\:hidden{
    display:none;
  }

  .lg\:h-10{
    height:2.5rem;
  }

  .lg\:h-12{
    height:3rem;
  }

  .lg\:w-10{
    width:2.5rem;
  }

  .lg\:w-58{
    width:14.5rem;
  }

  .lg\:w-3\/6{
    width:50%;
  }

  .lg\:min-w-77\.5{
    min-width:19.375rem;
  }

  .lg\:flex-row{
    flex-direction:row;
  }

  .lg\:justify-start{
    justify-content:flex-start;
  }

  .lg\:justify-center{
    justify-content:center;
  }

  .lg\:p-8{
    padding:2rem;
  }

  .lg\:px-10{
    padding-left:2.5rem;
    padding-right:2.5rem;
  }

  .lg\:px-24{
    padding-left:6rem;
    padding-right:6rem;
  }

  .lg\:px-25{
    padding-left:6.25rem;
    padding-right:6.25rem;
  }

  .lg\:px-25\.5{
    padding-left:6.375rem;
    padding-right:6.375rem;
  }

  .lg\:pt-1{
    padding-top:0.25rem;
  }

  .lg\:pt-10{
    padding-top:2.5rem;
  }

  .lg\:pr-4{
    padding-right:1rem;
  }

  .lg\:pr-10{
    padding-right:2.5rem;
  }

  .lg\:pb-3{
    padding-bottom:0.75rem;
  }

  .lg\:pb-9{
    padding-bottom:2.25rem;
  }

  .lg\:pl-0{
    padding-left:0px;
  }

  .lg\:pl-6{
    padding-left:1.5rem;
  }

  .lg\:text-md{
    font-size:0.9375rem;
  }

  .lg\:text-3\.5xl{
    font-size:2rem;
  }

  .lg\:font-bold{
    font-weight:700;
  }
}

@media (min-width: 1448px){
  .xl\:mr-8{
    margin-right:2rem;
  }

  .xl\:mr-12{
    margin-right:3rem;
  }

  .xl\:mr-48{
    margin-right:12rem;
  }

  .xl\:h-22{
    height:5.5rem;
  }

  .xl\:w-22{
    width:5.5rem;
  }

  .xl\:w-4\/12{
    width:33.333333%;
  }

  .xl\:min-w-85\.5{
    min-width:21.375rem;
  }

  .xl\:p-4{
    padding:1rem;
  }

  .xl\:p-16{
    padding:4rem;
  }

  .xl\:p-22{
    padding:5.5rem;
  }

  .xl\:px-20{
    padding-left:5rem;
    padding-right:5rem;
  }

  .xl\:px-48{
    padding-left:12rem;
    padding-right:12rem;
  }

  .xl\:px-56{
    padding-left:14rem;
    padding-right:14rem;
  }

  .xl\:py-14{
    padding-top:3.5rem;
    padding-bottom:3.5rem;
  }
}

@media (min-width: 1920px){
  .xxl\:w-5\/6{
    width:83.333333%;
  }

  .xxl\:w-3\/12{
    width:25%;
  }
}
@import url(https://p.typekit.net/p.css?s=1&k=hje8qtf&ht=tk&f=9674.9676.24539.24547.24549&a=5531244&app=typekit&e=css);
/*purgecss start ignore*/

@font-face{
  font-family:"pt-serif";

  src:local("PT Serif"),url(https://use.typekit.net/af/740b38/000000000000000000012500/27/l?fvd=n4&primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&v=3) format("woff2"),url(https://use.typekit.net/af/740b38/000000000000000000012500/27/d?fvd=n4&primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&v=3) format("woff"),url(https://use.typekit.net/af/740b38/000000000000000000012500/27/a?fvd=n4&primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&v=3) format("opentype");

  font-display:swap;

  font-style:normal;

  font-weight:400
}

@font-face{
  font-family:"pt-serif";

  src:local("PT Serif"),url(https://use.typekit.net/af/63cd12/0000000000000000000124ff/27/l?fvd=n7&primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&v=3) format("woff2"),url(https://use.typekit.net/af/63cd12/0000000000000000000124ff/27/d?fvd=n7&primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&v=3) format("woff"),url(https://use.typekit.net/af/63cd12/0000000000000000000124ff/27/a?fvd=n7&primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&v=3) format("opentype");

  font-display:swap;

  font-style:normal;

  font-weight:700
}

@font-face{
  font-family:"sofia-pro";

  src:local("Sofia Pro"),url(https://use.typekit.net/af/30420e/00000000000000003b9b1a9e/27/l?fvd=n7&primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&v=3) format("woff2"),url(https://use.typekit.net/af/30420e/00000000000000003b9b1a9e/27/d?fvd=n7&primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&v=3) format("woff"),url(https://use.typekit.net/af/30420e/00000000000000003b9b1a9e/27/a?fvd=n7&primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&v=3) format("opentype");

  font-display:swap;

  font-style:normal;

  font-weight:700
}

@font-face{
  font-family:"sofia-pro";

  src:local("Sofia Pro"),url(https://use.typekit.net/af/5855b2/00000000000000003b9b1a98/27/l?fvd=n4&primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&v=3) format("woff2"),url(https://use.typekit.net/af/5855b2/00000000000000003b9b1a98/27/d?fvd=n4&primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&v=3) format("woff"),url(https://use.typekit.net/af/5855b2/00000000000000003b9b1a98/27/a?fvd=n4&primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&v=3) format("opentype");

  font-display:swap;

  font-style:normal;

  font-weight:400
}

@font-face{
  font-family:"sofia-pro";

  src:local("Sofia Pro"),url(https://use.typekit.net/af/7158ff/00000000000000003b9b1a9c/27/l?fvd=n6&primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&v=3) format("woff2"),url(https://use.typekit.net/af/7158ff/00000000000000003b9b1a9c/27/d?fvd=n6&primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&v=3) format("woff"),url(https://use.typekit.net/af/7158ff/00000000000000003b9b1a9c/27/a?fvd=n6&primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&v=3) format("opentype");

  font-display:swap;

  font-style:normal;

  font-weight:600
}

@font-face{
  font-family:"sofia-pro";

  src:local("Sofia Pro"),url(https://use.typekit.net/af/7158ff/00000000000000003b9b1a9c/27/l?fvd=n6&primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&v=3) format("woff2"),url(https://use.typekit.net/af/7158ff/00000000000000003b9b1a9c/27/d?fvd=n6&primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&v=3) format("woff"),url(https://use.typekit.net/af/7158ff/00000000000000003b9b1a9c/27/a?fvd=n6&primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&v=3) format("opentype");

  font-display:swap;

  font-style:normal;

  font-weight:300
}

.tk-pt-serif{
  font-family:"pt-serif",serif
}

.tk-sofia-pro{
  font-family:"sofia-pro",sans-serif
}

/*purgecss end ignore*/
/*purgecss start ignore*/

:root{
  --color-bluelagoon-100:"#D6E5E3";
  --color-bluelagoon-200:"#A9D2D3";
  --color-bluelagoon-300:"#628C91";
  --color-bluelagoon-350:"#3b828b";
  --color-bluelagoon-400:"#0C646F";
  --color-bluelagoon-500:"#06545e";
  --color-neutral-100:"#F4F4F4";
  --color-neutral-400:"#989998";
  --color-neutral-300:"#D9D9D9";
  --color-neutral-200:"#E6E6E6";
  --color-neutral-500:"#5f5554";
  --color-salmon-500:"#de5952";
  --color-salmon-400:"#FB625A";
  --color-salmon-200:"#fb928d";
  --color-seagreen-400:"#38BBA0";
  --side-bar-width:14rem;
  --header-height:4rem
}

@media(min-width:1366px){
  :root{
    --side-bar-width:16rem;
    --header-height:5rem
  }
}

.skeleton--animation{
  position:relative
}

.skeleton--animation:before{
  content:"";
  position:absolute;
  top:0px;
  right:0px;
  bottom:0px;
  left:0px;
  background:linear-gradient(94deg,#e6e6e6,#d9d9d9,#e6e6e6);
  background-size:200% 200%;
  animation:loadingCardAnimation 1.2s linear infinite reverse
}

@-webkit-keyframes loadingCardAnimation{
  0%{
    background-position-x:0
  }

  to{
    background-position-x:200%
  }
}

@keyframes loadingCardAnimation{
  0%{
    background-position-x:0
  }

  to{
    background-position-x:200%
  }
}

.skeleton--solid{
  --tw-bg-opacity:1;
  background-color:rgba(210, 217, 216, var(--tw-bg-opacity))
}

.program-detail-x-alignment{
  padding-left:1rem;
  padding-right:1rem
}

@media(min-width:600px){
  .program-detail-x-alignment{
    padding-left:1.5rem;
    padding-right:1.5rem
  }
}

@media(min-width:1024px){
  .program-detail-x-alignment{
    padding-left:2rem;
    padding-right:2rem
  }
}

@media(min-width:1366px){
  .program-detail-x-alignment{
    padding-left:4.5rem;
    padding-right:4.5rem
  }
}

@media(min-width:1024px){
  .playlist-detail-part-x-alignment{
    padding-left:2rem;
    padding-right:2rem
  }
}

@media(min-width:1366px){
  .playlist-detail-part-x-alignment{
    padding-left:4.5rem;
    padding-right:4.5rem
  }
}

.playlist-detail-x-alignment{
  padding-left:1rem;
  padding-right:1rem
}

@media(min-width:600px){
  .playlist-detail-x-alignment{
    padding-left:1.5rem;
    padding-right:1.5rem
  }
}

@media(min-width:1024px){
  .playlist-detail-x-alignment{
    padding-left:2rem;
    padding-right:2rem
  }
}

@media(min-width:1366px){
  .playlist-detail-x-alignment{
    padding-left:4.5rem;
    padding-right:4.5rem
  }
}

.app-scroll-bar .os-scrollbar.os-scrollbar-vertical{
  width:.5rem
}

.app-scroll-bar .os-scrollbar.os-scrollbar-vertical .os-scrollbar-track .os-scrollbar-handle{
  background:rgba(0,0,0,.1)
}

.app-scroll-bar .os-scrollbar.os-scrollbar-vertical .os-scrollbar-track .os-scrollbar-handle:hover{
  background:rgba(0,0,0,.2)
}

.input-focus-outline{
  position:relative
}

.input-focus-outline:after{
  position:absolute;
  content:" ";
  border-width:3px;
  top:-3px;
  bottom:-3px;
  left:-3px;
  right:-3px;
  transition:all .1s ease-in-out;
  transform:scale(.99);
  opacity:0;
  pointer-events:none;
  --tw-border-opacity:1;
  border-color:rgba(214, 229, 227, var(--tw-border-opacity));
  border-radius:0.5rem
}

.input-focus-outline.input-focus-outline--focus-active:after,.input-focus-outline.input-focus-outline--has-errors:after,.input-focus-outline.input-focus-outline--hover-active:hover:after{
  opacity:1;
  transform:scale(1)
}

.input-focus-outline.input-focus-outline--has-errors:after{
  --tw-border-opacity:1;
  border-color:rgba(251, 146, 141, var(--tw-border-opacity))
}

.input-focus-outline.input-focus-outline--has-errors:not(.input-focus-outline--focus-active):after{
  opacity:.5
}

.input-disabled{
  cursor:not-allowed;
  filter:grayscale(100%);
  opacity:.75
}

.input-placeholder-color ::-moz-placeholder{
  --tw-text-opacity:1;
  color:rgba(146, 152, 151, var(--tw-text-opacity));
  opacity:1
}

.input-placeholder-color :-ms-input-placeholder{
  --tw-text-opacity:1;
  color:rgba(146, 152, 151, var(--tw-text-opacity));
  opacity:1
}

.input-placeholder-color ::placeholder{
  --tw-text-opacity:1;
  color:rgba(146, 152, 151, var(--tw-text-opacity));
  opacity:1
}

.input-placeholder-color :-ms-input-placeholder{
  --tw-text-opacity:1;
  color:rgba(146, 152, 151, var(--tw-text-opacity))
}

.input-placeholder-color ::-ms-input-placeholder{
  --tw-text-opacity:1;
  color:rgba(146, 152, 151, var(--tw-text-opacity))
}

.field-error-message{
  --tw-text-opacity:1;
  color:rgba(255, 56, 96, var(--tw-text-opacity));
  font-size:0.75rem;
  line-height:1rem;
  min-height:1.5rem
}

.field-error-message ::v-deep a{
  --tw-text-opacity:1;
  color:rgba(12, 100, 111, var(--tw-text-opacity))
}

.gap-emulation{
  --local-col-gap:var(--col-gap,0.5rem);
  --local-row-gap:var(--col-row,0.5rem);
  margin:calc(var(--local-row-gap)*-1) 0 0 calc(var(--local-col-gap)*-1);
  width:calc(100% + var(--local-col-gap))
}

.gap-emulation .gap-emulation-item{
  margin:var(--local-row-gap) 0 0 var(--local-col-gap)
}

.content-page-content-alignment{
  padding-left:1rem;
  padding-right:1rem;
  padding-bottom:5rem
}

@media(min-width:1024px){
  .content-page-content-alignment{
    padding-left:1.5rem;
    padding-right:1.5rem
  }
}

@media(min-width:1366px){
  .content-page-content-alignment{
    padding-left:2.5rem;
    padding-right:2.5rem
  }
}

.content-page-content-alignment .content-pagination{
  margin-top:6rem
}

.content-devider{
  border-bottom-width:1px;
  --tw-border-opacity:1;
  border-color:rgba(244, 244, 244, var(--tw-border-opacity))
}

.description-link ::v-deep a{
  --tw-text-opacity:1;
  color:rgba(12, 100, 111, var(--tw-text-opacity))
}

.description-link ::v-deep a:hover{
  --tw-text-opacity:1;
  color:rgba(98, 140, 145, var(--tw-text-opacity))
}

.description-link ::v-deep a:focus{
  text-decoration:underline
}

.description-link ::v-deep a:focus:after{
  opacity:0
}

.description-list ul{
  margin-top:1rem;
  margin-bottom:1rem;
  margin-left:2rem;
  list-style-type:disc
}

.description-list ul li{
  --tw-text-opacity:1;
  color:rgba(12, 100, 111, var(--tw-text-opacity))
}

.description-list ul li+li{
  margin-top:0.25rem
}

.description-paragraph p{
  margin-bottom:1rem
}

.modal-open{
  overflow:hidden;
  height:95%
}

body.lock-scrollbar{
  overflow-y:scroll!important;
  position:fixed;
  left:0;
  right:0;
  bottom:0
}

/*purgecss end ignore*/
/*purgecss start ignore*/
.nuxt-progress{
  position:fixed;
  top:0;
  left:0;
  right:0;
  height:2px;
  width:0;
  opacity:1;
  transition:width .1s,opacity .4s;
  background-color:#fff;
  z-index:999999
}
.nuxt-progress.nuxt-progress-notransition{
  transition:none
}
.nuxt-progress-failed{
  background-color:red
}

/*purgecss end ignore*/
/*purgecss start ignore*/
.error-page[data-v-9979853c]{
  padding-top:4.5rem;
  min-height:100vh
}
.error-page .img-asset[data-v-9979853c]{
  pointer-events:none;
  bottom:-8rem;
  right:-12rem
}
@media(min-width:1024px){
.error-page[data-v-9979853c]  .fixed-header__left{
    display:none
}
}
.error-page[data-v-9979853c]  .fixed-header__right .primary{
  display:none
}

/*purgecss end ignore*/
/*purgecss start ignore*/
.fixed-header[data-v-69cdf1d0]{
  top:0;
  left:0;
  right:0
}
.fixed-header--is-scrolled[data-v-69cdf1d0]{
  --tw-bg-opacity:1;
  background-color:rgba(255, 255, 255, var(--tw-bg-opacity))
}
.fixed-header--is-top[data-v-69cdf1d0]{
  background-color:transparent
}
.fixed-header__left__header-link[data-v-69cdf1d0]{
  border-color:transparent
}
.fixed-header__left__header-link--border-white[data-v-69cdf1d0]{
  --tw-border-opacity:1;
  border-color:rgba(255, 255, 255, var(--tw-border-opacity))
}
.fixed-header__left__header-link[data-v-69cdf1d0]:hover{
  border-color:#2cbca1;
  -webkit-animation:changeBottomBorderColor-data-v-69cdf1d0 .2s;
          animation:changeBottomBorderColor-data-v-69cdf1d0 .2s
}
.fixed-header .close-menu[data-v-69cdf1d0]{
  --tw-text-opacity:1;
  color:rgba(59, 130, 139, var(--tw-text-opacity))
}
@media(min-width:1024px){
.fixed-header .close-menu[data-v-69cdf1d0]{
    display:none
}
}
.fixed-header .close-menu--rotated[data-v-69cdf1d0]{
  transform:rotate(180deg)
}
@-webkit-keyframes changeBottomBorderColor-data-v-69cdf1d0{
0%{
    border-color:inherit
}
to{
    border-color:#2cbca1
}
}
@keyframes changeBottomBorderColor-data-v-69cdf1d0{
0%{
    border-color:inherit
}
to{
    border-color:#2cbca1
}
}

/*purgecss end ignore*/
/*purgecss start ignore*/
.app-button[data-v-4ca8074d]{
  padding-left:1.5rem;
  padding-right:1.5rem;
  padding-top:0.75rem;
  padding-bottom:0.75rem;
  border-radius:0.25rem
}
.app-button--disabled[data-v-4ca8074d]{
  cursor:not-allowed;
  filter:grayscale(100%);
  opacity:.75
}
.app-button.clean[data-v-4ca8074d]{
  padding:0px
}
.app-button.outline[data-v-4ca8074d], .app-button.outline-light[data-v-4ca8074d], .app-button.primary[data-v-4ca8074d], .app-button.secondary[data-v-4ca8074d]{
  --tw-text-opacity:1;
  color:rgba(255, 255, 255, var(--tw-text-opacity))
}
.app-button.outline[data-v-4ca8074d], .app-button.outline-light[data-v-4ca8074d], .app-button.primary[data-v-4ca8074d], .app-button.secondary[data-v-4ca8074d]{
  border-radius:2rem
}
.app-button.outline[data-v-4ca8074d], .app-button.outline-light[data-v-4ca8074d], .app-button.primary[data-v-4ca8074d], .app-button.secondary[data-v-4ca8074d]{
  font-weight:700
}
.app-button.outline-light[data-v-4ca8074d]:focus:after,.app-button.outline[data-v-4ca8074d]:focus:after,.app-button.primary[data-v-4ca8074d]:focus:after,.app-button.secondary[data-v-4ca8074d]:focus:after{
  opacity:0
}
.app-button.primary[data-v-4ca8074d]{
  --tw-bg-opacity:1;
  background-color:rgba(251, 98, 90, var(--tw-bg-opacity))
}
.app-button.primary[data-v-4ca8074d]:active{
  --tw-bg-opacity:1;
  background-color:rgba(222, 89, 82, var(--tw-bg-opacity))
}
.app-button.primary[data-v-4ca8074d]:not(:active):focus, .app-button.primary[data-v-4ca8074d]:not(:active):hover{
  --tw-bg-opacity:1;
  background-color:rgba(251, 146, 141, var(--tw-bg-opacity))
}
.app-button.outline[data-v-4ca8074d]{
  --tw-border-opacity:1;
  border-color:rgba(12, 100, 111, var(--tw-border-opacity));
  border-width:2px;
  padding-left:1.375rem;
  padding-right:1.375rem;
  padding-top:0.625rem;
  padding-bottom:0.625rem
}
.app-button.outline[data-v-4ca8074d]:not(:active):focus{
  --tw-text-opacity:1;
  color:rgba(59, 130, 139, var(--tw-text-opacity));
  --tw-border-opacity:1;
  border-color:rgba(59, 130, 139, var(--tw-border-opacity))
}
.app-button.outline-light[data-v-4ca8074d]{
  --tw-text-opacity:1;
  color:rgba(56, 187, 160, var(--tw-text-opacity));
  --tw-border-opacity:1;
  border-color:rgba(214, 229, 227, var(--tw-border-opacity));
  border-width:2px
}
.app-button.outline-light[data-v-4ca8074d]:active{
  filter:brightness(85%)
}
.app-button.outline-light[data-v-4ca8074d]:hover{
  --tw-border-opacity:1;
  border-color:rgba(169, 210, 211, var(--tw-border-opacity))
}
.app-button.secondary[data-v-4ca8074d]{
  --tw-bg-opacity:1;
  background-color:rgba(12, 100, 111, var(--tw-bg-opacity))
}
.app-button.secondary[data-v-4ca8074d]:active{
  --tw-bg-opacity:1;
  background-color:rgba(6, 84, 94, var(--tw-bg-opacity))
}
.app-button.secondary[data-v-4ca8074d]:not(:active):focus, .app-button.secondary[data-v-4ca8074d]:not(:active):hover{
  --tw-bg-opacity:1;
  background-color:rgba(59, 130, 139, var(--tw-bg-opacity))
}
.app-button.clear[data-v-4ca8074d], .app-button.filter[data-v-4ca8074d], .app-button.outline[data-v-4ca8074d]{
  --tw-text-opacity:1;
  color:rgba(12, 100, 111, var(--tw-text-opacity))
}
.app-button.clear[data-v-4ca8074d], .app-button.filter[data-v-4ca8074d], .app-button.outline[data-v-4ca8074d]{
  font-weight:700
}
.app-button.clear[data-v-4ca8074d]:active, .app-button.filter[data-v-4ca8074d]:active, .app-button.outline[data-v-4ca8074d]:active{
  --tw-text-opacity:1;
  color:rgba(6, 84, 94, var(--tw-text-opacity))
}
.app-button.clear[data-v-4ca8074d]:active, .app-button.filter[data-v-4ca8074d]:active, .app-button.outline[data-v-4ca8074d]:active{
  --tw-border-opacity:1;
  border-color:rgba(6, 84, 94, var(--tw-border-opacity))
}
.app-button.clear[data-v-4ca8074d]:not(:active):hover, .app-button.filter[data-v-4ca8074d]:not(:active):hover, .app-button.outline[data-v-4ca8074d]:not(:active):hover{
  --tw-text-opacity:1;
  color:rgba(59, 130, 139, var(--tw-text-opacity))
}
.app-button.clear[data-v-4ca8074d]:not(:active):hover, .app-button.filter[data-v-4ca8074d]:not(:active):hover, .app-button.outline[data-v-4ca8074d]:not(:active):hover{
  --tw-border-opacity:1;
  border-color:rgba(59, 130, 139, var(--tw-border-opacity))
}
.app-button.filter[data-v-4ca8074d]{
  font-size:0.9375rem;
  padding-left:0.25rem;
  padding-right:0.25rem;
  line-height:1.6
}
.app-button.btn-rounded[data-v-4ca8074d], .app-button.btn-rounded[data-v-4ca8074d]:after{
  border-radius:2rem
}
.app-button.slim[data-v-4ca8074d]{
  padding-top:0.375rem;
  padding-bottom:0.375rem
}

/*purgecss end ignore*/
/*purgecss start ignore*/
.app-button.fab[data-v-b567ff52]{
  display:inline-flex;
  border-radius:9999px;
  align-items:center;
  justify-content:center;
  padding:0px
}
.app-button.fab[data-v-b567ff52]:focus:after{
  border-radius:9999px;
  top:-6px;
  bottom:-6px;
  left:-6px;
  right:-6px
}
.app-button.fab--nav[data-v-b567ff52]{
  --tw-text-opacity:1;
  color:rgba(52, 61, 60, var(--tw-text-opacity))
}
.app-button.fab--nav--active[data-v-b567ff52]{
  --tw-bg-opacity:1;
  background-color:rgba(227, 230, 229, var(--tw-bg-opacity))
}
.app-button.fab--nav--active.nav-lite[data-v-b567ff52], .app-button.fab--nav[data-v-b567ff52]:hover{
  --tw-bg-opacity:1;
  background-color:rgba(245, 247, 247, var(--tw-bg-opacity))
}
.app-button.fab--nav[data-v-b567ff52]:active{
  --tw-bg-opacity:1;
  background-color:rgba(227, 230, 229, var(--tw-bg-opacity))
}
.app-button.fab--nav--profile[data-v-b567ff52]{
  --tw-bg-opacity:1;
  background-color:rgba(214, 229, 227, var(--tw-bg-opacity));
  --tw-text-opacity:1;
  color:rgba(12, 100, 111, var(--tw-text-opacity))
}
.app-button.fab--nav--profile[data-v-b567ff52]:hover{
  opacity:.7
}
.app-button.fab--nav--profile--active[data-v-b567ff52]{
  --tw-bg-opacity:1;
  background-color:rgba(214, 229, 227, var(--tw-bg-opacity));
  --tw-text-opacity:1;
  color:rgba(12, 100, 111, var(--tw-text-opacity));
  opacity:.7
}
.app-button.fab--bg-image[data-v-b567ff52]{
  background-size:cover;
  background-position:center
}
.app-button.fab__text[data-v-b567ff52]{
  font-weight:700
}
.app-button.fab.text-primary[data-v-b567ff52]{
  --tw-text-opacity:1;
  color:rgba(6, 84, 94, var(--tw-text-opacity))
}

/*purgecss end ignore*/
/*purgecss start ignore*/
.text-with-icon[data-v-1f3a449e]{
  display:inline-flex;
  align-items:baseline
}
.text-with-icon__text[data-v-1f3a449e]{
  display:inline-flex
}
.text-with-icon--icon-only[data-v-1f3a449e], .text-with-icon.centered-text[data-v-1f3a449e]{
  align-items:center
}
.text-with-icon .text-with-icon__icon[data-v-1f3a449e]{
  display:inline-flex;
  align-self:center
}
.text-with-icon .text-with-icon__icon--action[data-v-1f3a449e]{
  cursor:pointer
}

/*purgecss end ignore*/
/*purgecss start ignore*/
.error-page__content__left[data-v-0dee20e6]{
  align-items:center
}
@media(min-width:1024px){
.error-page__content__left[data-v-0dee20e6]{
    align-items:flex-start
}
}
.error-page__content__error-item-wrapper[data-v-0dee20e6]{
  display:grid;
  flex-wrap:wrap;
  grid-gap:.5rem
}
@media(min-width:600px){
.error-page__content__error-item-wrapper[data-v-0dee20e6]{
    grid-template-columns:1fr 1fr
}
}
@media(min-width:1024px){
.error-page__content__error-item-wrapper[data-v-0dee20e6]{
    grid-template-columns:1fr 1fr 1fr
}
}
@media(min-width:1366px){
.error-page__content__error-item-wrapper[data-v-0dee20e6]{
    grid-gap:2rem 1rem
}
}
.error-page__content__error-item-wrapper .error-item[data-v-0dee20e6]{
  border-radius:0.25rem;
  padding:2rem;
  height:10rem;
  border:.5px solid #3b828b;
  min-width:14rem;
  width:100%
}
@media(min-width:1024px){
.error-page__content__error-item-wrapper .error-item[data-v-0dee20e6]{
    width:14rem;
    height:12rem
}
}
@media(min-width:1366px){
.error-page__content__error-item-wrapper .error-item[data-v-0dee20e6]{
    width:25%
}
}

/*purgecss end ignore*/</style>
</head>
<body>
<noscript data-n-head="ssr" data-hid="gtm-noscript" data-pbody="true"><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-T9S2ST&" height="0" width="0" style="display:none;visibility:hidden" title="gtm"></iframe></noscript><div data-server-rendered="true" id="__nuxt"><div id="__layout"><div><div class="error-page h-full w-full bg-bluelagoon-100 flex flex-col items-center justify-center px-8 md:px-16 relative overflow-hidden" data-v-9979853c><div class="fixed-header fixed z-40 h-20 p-8 md:p-12 bg-white flex w-full justify-between items-center absolute" data-v-69cdf1d0 data-v-9979853c><a href="/" class="h-12 lg:h-12 md:mr-16 xl:mr-48 flex-shrink-0 nuxt-link-active" data-v-69cdf1d0><div class="img-wrapper h-full" data-v-69cdf1d0><img src="/n_static/images/svg/logo/logo-flower.svg" alt="LOGO_FLOWER" class="object-contain w-auto h-full"></div></a> <nav class="fixed-header__left flex flex-grow items-center" data-v-69cdf1d0><a href="/classes/browse_all?page=1" class="fixed-header__left__header-link font-semibold text-bluelagoon-400 hidden md:flex flex-shrink-0 mr-6 xl:mr-12 border-b-2" data-v-69cdf1d0>
Classes
</a><a href="/programs/browse_all?page=1" class="fixed-header__left__header-link font-semibold text-bluelagoon-400 hidden md:flex flex-shrink-0 mr-6 xl:mr-12 border-b-2" data-v-69cdf1d0>
Programs
</a><a href="/teachers?tab=all" class="fixed-header__left__header-link font-semibold text-bluelagoon-400 hidden md:flex flex-shrink-0 mr-6 xl:mr-12 border-b-2" data-v-69cdf1d0>
Teachers
</a><a href="/articles/browse_all" class="fixed-header__left__header-link font-semibold text-bluelagoon-400 hidden md:flex flex-shrink-0 mr-6 xl:mr-12 border-b-2" data-v-69cdf1d0>
Articles
</a><a href="/resources/yoga-poses" class="fixed-header__left__header-link font-semibold text-bluelagoon-400 hidden md:flex flex-shrink-0 mr-6 xl:mr-12 border-b-2" data-v-69cdf1d0>
Resources
</a> <a href="https://www.ekhart-academy.com" target="_blank" class="fixed-header__left__header-link font-semibold text-bluelagoon-400 hidden md:flex flex-shrink-0 mr-6 xl:mr-12 border-b-2" data-v-69cdf1d0>
Academy
</a></nav> <button class="app-button primary md:hidden flex-shrink-0" style="display:none;" data-v-4ca8074d data-v-69cdf1d0>
Try for free
</button> <div class="fixed-header__right flex flex-grow justify-end items-center" data-v-69cdf1d0><button class="app-button primary hidden md:flex mr-4 flex-shrink-0" data-v-4ca8074d data-v-69cdf1d0>
Join us
</button> <button class="app-button secondary hidden md:flex flex-shrink-0" data-v-4ca8074d data-v-69cdf1d0>
Sign in
</button></div> <div class="md:hidden flex items-center" data-v-69cdf1d0><button class="app-button app-button fab menu close-menu flex-shrink-0 md:hidden close-menu--rotated" style="height:2rem;width:2rem;background-image:none;" data-v-4ca8074d data-v-b567ff52 data-v-69cdf1d0><div class="text-with-icon fab__icon" style="font-size:2rem;" data-v-1f3a449e data-v-b567ff52><div class="app-icon inline-flex text-with-icon__icon" style="margin-right:0px;" data-v-1f3a449e> <i class="inline-block"></i></div> <span class="text-with-icon__text" style="display:;" data-v-1f3a449e></span> <div class="app-icon inline-flex text-with-icon__icon" style="display:none;margin-left:0px;" data-v-1f3a449e> <i class="inline-block"></i></div></div></button></div></div>  <div class="error-page__content flex flex-col md:flex-row lg:justify-center" data-v-0dee20e6 data-v-9979853c><div class="error-page__content__left flex flex-col mb-8 lg:mb-0 md:justify-start" data-v-0dee20e6><h1 class="text-3xl font-bold text-bluelagoon-500 mb-4 lg:mb-6 md:text-5xl" data-v-0dee20e6>
Breathe in.
<br data-v-0dee20e6>
Breathe out.
</h1> <p class="md:text-xl text-center md:text-left" data-v-0dee20e6>
404 - page not found <br data-v-0dee20e6>
Sorry, we can't find the page you're looking for.
</p> <button class="app-button secondary mt-8 md:mt-16 w-64" data-v-4ca8074d data-v-0dee20e6><a href="/" class="nuxt-link-active" data-v-0dee20e6> Back to homepage </a></button></div> <div class="error-page__content__error-item-wrapper justify-center mb-4 md:mb-0 lg:justify-start lg:w-3/6 md:ml-6 lg:ml-16" data-v-0dee20e6><div class="error-item" data-v-0dee20e6><a href="/classes/browse_all?page=1" data-v-0dee20e6><h2 class="font-bold text-2xl text-bluelagoon-500 mb-4" data-v-0dee20e6>
Classes
</h2> <p class="font-heading text-bluelagoon-500" data-v-0dee20e6>
Browse our yoga and meditation classes
</p></a></div><div class="error-item" data-v-0dee20e6><a href="/programs/browse_all?page=1" data-v-0dee20e6><h2 class="font-bold text-2xl text-bluelagoon-500 mb-4" data-v-0dee20e6>
Programs
</h2> <p class="font-heading text-bluelagoon-500" data-v-0dee20e6>
Follow one of or guided programs
</p></a></div><div class="error-item" data-v-0dee20e6><a href="/playlists/browse_all?page=1" data-v-0dee20e6><h2 class="font-bold text-2xl text-bluelagoon-500 mb-4" data-v-0dee20e6>
Playlists
</h2> <p class="font-heading text-bluelagoon-500" data-v-0dee20e6>
Organise your favourite classes
</p></a></div><div class="error-item" data-v-0dee20e6><a href="/articles/browse_all" data-v-0dee20e6><h2 class="font-bold text-2xl text-bluelagoon-500 mb-4" data-v-0dee20e6>
Articles
</h2> <p class="font-heading text-bluelagoon-500" data-v-0dee20e6>
Learn more about yoga and wellbeing
</p></a></div><div class="error-item" data-v-0dee20e6><a href="/resources/styles" data-v-0dee20e6><h2 class="font-bold text-2xl text-bluelagoon-500 mb-4" data-v-0dee20e6>
Styles
</h2> <p class="font-heading text-bluelagoon-500" data-v-0dee20e6>
Explore our different yoga styles
</p></a></div><div class="error-item" data-v-0dee20e6><a href="/teachers?tab=all" data-v-0dee20e6><h2 class="font-bold text-2xl text-bluelagoon-500 mb-4" data-v-0dee20e6>
Teachers
</h2> <p class="font-heading text-bluelagoon-500" data-v-0dee20e6>
Get to know our teachers
</p></a></div></div></div>  <img src="/n_static/images/partial_logo_bottom.png" class="img-asset absolute" data-v-9979853c></div></div></div></div><script>window.__NUXT__=(function(a,b,c,d,e,f,g,h,i,j){return {layout:"error-layout",data:[],fetch:{},error:{statusCode:404,path:"\u002Fxmlrpc.php",message:"This page could not be found"},state:{contentIsLoading:c,contentFiltersAreLoading:c,isClientFetchActive:d,shouldFetchList:d,shouldFetchDetail:d,displayDetailHeader:d,showRelogPopup:d,previousPage:a,envConfig:{},ipAddress:" 172.16.1.6",detailHeader:{config:{headerTitle:a}},globalNotificationState:{list:[]},globalSideBarState:{sideBarDisabled:d,sideBarToggled:d},publicHeader:{dto:{description:a,title:a,rootRouteTitle:a}},workshops:{pageList:{"1":{pageNumber:b,data:[]}},featured:[]},userPreferences:{class:[],playlist:[],program:[],teacher:[],resource:[],style:[]},userNotifications:{list:[],unread:e},teachers:{list:[]},resources:{pageList:{"1":{pageNumber:b,data:[]}},resourcesCategories:[]},programs:{pageList:{"1":{pageNumber:b,data:[]}},detail:{dto:{},dateOfLastFetch:a}},playlists:{pageList:{"1":{pageNumber:b,data:[]}},detail:{dto:{},dateOfLastFetch:a},draft:{draft:{id:a,title:a}},owned:{list:[]}},contentPageState:{noResultsConfig:{hide:c},networkErrorConfig:{hide:c}},contentPageFilterState:{articleFilterState:{filters:[],slugs:[],route:"\u002Farticles",appliedFilters:{pageNumber:b},paginationConfig:{previousButtonText:a,nextButtonText:a,selectedPage:b,maxPageButtonCount:f,pagesTotal:g,skeletonState:c},numberOfResults:e},classFilterState:{filters:[],slugs:[],route:"\u002Fclasses",appliedFilters:{pageNumber:b,tab:"recommended"},paginationConfig:{previousButtonText:a,nextButtonText:a,selectedPage:b,maxPageButtonCount:f,pagesTotal:g,skeletonState:c},numberOfResults:e},playlistFilterState:{filters:[],slugs:[],route:"\u002Fplaylists",appliedFilters:{pageNumber:b,tab:i},paginationConfig:{previousButtonText:a,nextButtonText:a,selectedPage:b,maxPageButtonCount:f,pagesTotal:g,skeletonState:c},numberOfResults:e},programFilterState:{filters:[],slugs:[],route:"\u002Fprograms",appliedFilters:{pageNumber:b,tab:i},paginationConfig:{previousButtonText:a,nextButtonText:a,selectedPage:b,maxPageButtonCount:f,pagesTotal:g,skeletonState:c},numberOfResults:e},resourceFilterState:{filters:[],route:"\u002Fresources",appliedFilters:{pageNumber:b,tab:i},paginationConfig:{previousButtonText:a,nextButtonText:a,selectedPage:b,maxPageButtonCount:f,pagesTotal:g,skeletonState:c}},workshopFilterState:{filters:[],slugs:[],route:"\u002Fworkshops",appliedFilters:{pageNumber:b},paginationConfig:{previousButtonText:a,nextButtonText:a,selectedPage:b,maxPageButtonCount:f,pagesTotal:g,skeletonState:c},numberOfResults:e}},classes:{pageList:{"1":{pageNumber:b,data:[]}},detail:{dto:{},dateOfLastFetch:a,sessionId:a}},bodyScroll:{activeElements:[]},articles:{pageList:{"1":{pageNumber:b,data:[]}}},i18n:{routeParams:{}},auth:{user:j,loggedIn:d,strategy:"customStrategy"}},serverRendered:c,routePath:"\u002Fxmlrpc.php",config:{env:"production",baseUrl:h,baseURL:h,staticFileCdn:"https:\u002F\u002Fblobs.ekhartyoga.com",mainApiUrl:"https:\u002F\u002Fzeroapi.ekhartyoga.com",diagnosticServiceUrl:"https:\u002F\u002Fdiagnostic.ekhartyoga.com\u002Fapi\u002FLogEvent",userPreferencesUrl:"https:\u002F\u002Fpreferences.ekhartyoga.com",identityProviderUrl:"https:\u002F\u002Flogin.ekhartyoga.com",commentSystemApi:"https:\u002F\u002Fcomments.ekhartyoga.com",wpApiUrl:h,liveChatUrl:"https:\u002F\u002Fekhart-prod-livechat.azurewebsites.net",vixyPartnerUserId:114,vixyServiceUrl:"https:\u002F\u002Fplatform.vixyvideo.com\u002F",vixyPlayerId:23452430,legacyUrl:h,googleAnalytics:{id:"UA-32736029-2"},gtm:{id:"GTM-T9S2ST",debug:d},recaptcha:{hideBadge:c,siteKey:"6LfkfuAeAAAAAMz_F8p5bDGzDXAGbQkOv4s3rIPX",version:3},oauthStrategyOptions:{redirect_uri:"https:\u002F\u002Fekhartyoga.com\u002Fcallback",client_id:"ey_user_platform",access_token_endpoint:"https:\u002F\u002Flogin.ekhartyoga.com\u002Fconnect\u002Ftoken",client_secret:void 0,authorization_endpoint:"https:\u002F\u002Flogin.ekhartyoga.com\u002Fconnect\u002Fauthorize",logout_endpoint:"https:\u002F\u002Flogin.ekhartyoga.com\u002Fconnect\u002Fendsession",userinfo_endpoint:"https:\u002F\u002Fzeroapi.ekhartyoga.com\u002Fapi\u002Fservices\u002Fapp\u002FUser\u002FGetCurrentLoggedInUser",scope:["openid","profile","email","ey_claims","ekhart_yoga_api.user"]},_app:{basePath:"\u002F",assetsPath:"\u002F_nuxt\u002F",cdnURL:j}}}}("",1,true,false,0,5,10,"https:\u002F\u002Fekhartyoga.com","browse_all",null));</script><script src="/_nuxt/ef48e06.js" defer></script><script src="/_nuxt/bcdd310.js" defer></script><script src="/_nuxt/1ec39af.js" defer></script><script src="/_nuxt/137b030.js" defer></script><script src="/_nuxt/ade32dc.js" defer></script><script src="/_nuxt/41a73cb.js" defer></script><script src="/_nuxt/be836d4.js" defer></script><script src="/_nuxt/12b27ac.js" defer></script><script src="/_nuxt/1c52e08.js" defer></script><script src="/_nuxt/a1d819d.js" defer></script><script src="/_nuxt/fa6a6ae.js" defer></script><script src="/_nuxt/7357468.js" defer></script><script src="/_nuxt/bbfd7f2.js" defer></script><script src="/_nuxt/df9e5eb.js" defer></script><script src="/_nuxt/8375dbb.js" defer></script><script src="/_nuxt/55e6e37.js" defer></script><script src="/_nuxt/367ff8d.js" defer></script><script src="/_nuxt/b7c46cc.js" defer></script><script src="/_nuxt/7274f18.js" defer></script><script src="/_nuxt/694b7c1.js" defer></script><script src="/_nuxt/ede6a2d.js" defer></script><script src="/_nuxt/94e65fa.js" defer></script><script src="/_nuxt/0d89912.js" defer></script><script src="/_nuxt/dfe5f9a.js" defer></script><script src="/_nuxt/b0bfff8.js" defer></script><script src="/_nuxt/91a963e.js" defer></script><script src="/_nuxt/f33595c.js" defer></script><script src="/_nuxt/82f26f3.js" defer></script><script src="/_nuxt/20e998b.js" defer></script><script src="/_nuxt/8c6e603.js" defer></script><script src="/_nuxt/09a7806.js" defer></script><script src="/_nuxt/62bcec4.js" defer></script><script src="/_nuxt/a861b6b.js" defer></script><script src="/_nuxt/20c9ecd.js" defer></script><script src="/_nuxt/1297cea.js" defer></script><script src="/_nuxt/8a7f781.js" defer></script><script src="/_nuxt/00b4ab9.js" defer></script><script src="/_nuxt/a551473.js" defer></script><script src="/_nuxt/2750c7d.js" defer></script><script src="/_nuxt/481b206.js" defer></script><script src="/_nuxt/206d9b4.js" defer></script><script src="/_nuxt/33f2ccc.js" defer></script><script src="/_nuxt/be0d710.js" defer></script><script src="/_nuxt/88c85de.js" defer></script><script src="/_nuxt/15e01b8.js" defer></script><script src="/_nuxt/39f7507.js" defer></script><script src="/_nuxt/32ea36e.js" defer></script><script src="/_nuxt/5d6b486.js" defer></script><script src="/_nuxt/06c58e1.js" defer></script><script src="/_nuxt/d36613f.js" defer></script><script src="/_nuxt/9a61419.js" defer></script><script src="/_nuxt/bc1fc9b.js" defer></script><script src="/_nuxt/9586224.js" defer></script><script src="/_nuxt/64e313b.js" defer></script><script src="/_nuxt/cf5641b.js" defer></script><script src="/_nuxt/a76628a.js" defer></script><script src="/_nuxt/63c3b86.js" defer></script><script src="/_nuxt/0516d77.js" defer></script><script src="/_nuxt/84d68fc.js" defer></script><script src="/_nuxt/d10a263.js" defer></script><script src="/_nuxt/4a072c4.js" defer></script><script src="/_nuxt/073ce04.js" defer></script><script src="/_nuxt/0958670.js" defer></script><script src="/_nuxt/999a138.js" defer></script><script src="/_nuxt/e697b11.js" defer></script><script src="/_nuxt/49264ac.js" defer></script><script src="/_nuxt/52cde23.js" defer></script><script src="/_nuxt/4a0997c.js" defer></script><script src="/_nuxt/e1454e5.js" defer></script><script src="/_nuxt/472609a.js" defer></script><script src="/_nuxt/030d4c4.js" defer></script><script src="/_nuxt/d57d9dd.js" defer></script><script src="/_nuxt/d7d2170.js" defer></script><script src="/_nuxt/44c9964.js" defer></script><script src="/_nuxt/fc3e4ce.js" defer></script><script src="/_nuxt/684cdbb.js" defer></script><script src="/_nuxt/b5bec54.js" defer></script><script src="/_nuxt/faa09e3.js" defer></script><script src="/_nuxt/bb5325f.js" defer></script><script src="/_nuxt/5bc3be5.js" defer></script><script src="/_nuxt/c1dfbe6.js" defer></script><script src="/_nuxt/2871dc9.js" defer></script><script src="/_nuxt/8758cad.js" defer></script><script src="/_nuxt/00576a9.js" defer></script><script src="/_nuxt/9353561.js" defer></script><script src="/_nuxt/f9dd55b.js" defer></script><script src="/_nuxt/4939c82.js" defer></script><script src="/_nuxt/98ccea3.js" defer></script><script src="/_nuxt/4ad5612.js" defer></script>
</body>
</html>
